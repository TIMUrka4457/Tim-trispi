package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io/ioutil"
    "net/http"
    "time"
)

type AIClient struct {
    Endpoint string
    Timeout  time.Duration
    client   *http.Client
}

type NetworkOptimizationRequest struct {
    PeerCount     int                    `json:"peer_count"`
    MessageRate   float64                `json:"message_rate"`
    Latency       float64                `json:"latency"`
    NetworkStats  map[string]interface{} `json:"network_stats"`
}

type NetworkOptimizationResponse struct {
    OptimalPeerCount int     `json:"optimal_peer_count"`
    RecommendedTTL   int     `json:"recommended_ttl"`
    Priority         string  `json:"priority"`
    Confidence       float64 `json:"confidence"`
}

func NewAIClient(endpoint string) *AIClient {
    return &AIClient{
        Endpoint: endpoint,
        Timeout:  5 * time.Second,
        client: &http.Client{
            Timeout: 5 * time.Second,
        },
    }
}

func (c *AIClient) OptimizeNetwork(req NetworkOptimizationRequest) (*NetworkOptimizationResponse, error) {
    url := fmt.Sprintf("%s/network_optimization", c.Endpoint)
    reqBytes, err := json.Marshal(req)
    if err != nil {
        return nil, err
    }

    resp, err := c.client.Post(url, "application/json", bytes.NewBuffer(reqBytes))
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    if resp.StatusCode != http.StatusOK {
        return nil, fmt.Errorf("AI service returned status: %d", resp.StatusCode)
    }

    body, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        return nil, err
    }

    var optimizationResp NetworkOptimizationResponse
    if err := json.Unmarshal(body, &optimizationResp); err != nil {
        return nil, err
    }

    return &optimizationResp, nil
}

func (c *AIClient) AnalyzeNetworkAnomaly(networkData map[string]interface{}) (bool, error) {
    url := fmt.Sprintf("%s/network_anomaly", c.Endpoint)
    reqBytes, err := json.Marshal(networkData)
    if err != nil {
        return false, err
    }

    resp, err := c.client.Post(url, "application/json", bytes.NewBuffer(reqBytes))
    if err != nil {
        return false, err
    }
    defer resp.Body.Close()

    var result map[string]interface{}
    if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
        return false, err
    }

    anomalous, ok := result["is_anomalous"].(bool)
    if !ok {
        return false, fmt.Errorf("invalid response format")
    }

    return anomalous, nil
}
