package p2p

import (
    "time"
    "net"
)

const (
    MessageTypePing          = "ping"
    MessageTypePong          = "pong"
    MessageTypeBlock         = "block"
    MessageTypeTransaction   = "transaction"
    MessageTypePeerDiscovery = "peer_discovery"
    MessageTypeSync          = "sync"
)

type Message struct {
    Type      string                 `json:"type"`
    From      string                 `json:"from"`
    To        string                 `json:"to,omitempty"`
    Timestamp time.Time              `json:"timestamp"`
    Data      map[string]interface{} `json:"data"`
    peer      *Peer                  `json:"-"` // Internal use only
}

type Peer struct {
    ID       string    `json:"id"`
    Address  string    `json:"address"`
    Conn     net.Conn  `json:"-"`
    LastSeen time.Time `json:"last_seen"`
}
