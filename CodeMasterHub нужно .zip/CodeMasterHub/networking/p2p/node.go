package p2p

import (
    "bufio"
    "context"
    "encoding/json"
    "fmt"
    "net"
    "strings"
    "sync"
    "time"

    "github.com/google/uuid"
    "github.com/sirupsen/logrus"
)

type Node struct {
    ID          string
    Port        string
    AIEndpoint  string
    Peers       *PeerManager
    Messages    chan Message
    ctx         context.Context
    cancel      context.CancelFunc
    listener    net.Listener
    wg          sync.WaitGroup
    logger      *logrus.Logger
}

func NewNode(port, aiEndpoint string) (*Node, error) {
    ctx, cancel := context.WithCancel(context.Background())
    
    logger := logrus.New()
    logger.SetLevel(logrus.InfoLevel)

    node := &Node{
        ID:         uuid.New().String(),
        Port:       port,
        AIEndpoint: aiEndpoint,
        Peers:      NewPeerManager(),
        Messages:   make(chan Message, 1000),
        ctx:        ctx,
        cancel:     cancel,
        logger:     logger,
    }

    return node, nil
}

func (n *Node) Start() error {
    address := fmt.Sprintf("0.0.0.0:%s", n.Port)
    listener, err := net.Listen("tcp", address)
    if err != nil {
        return fmt.Errorf("failed to listen on %s: %v", address, err)
    }
    
    n.listener = listener
    n.logger.Infof("🌐 P2P Node %s listening on %s", n.ID[:8], address)

    // Start message processor
    n.wg.Add(1)
    go n.processMessages()

    // Accept connections
    for {
        select {
        case <-n.ctx.Done():
            return nil
        default:
            conn, err := listener.Accept()
            if err != nil {
                if n.ctx.Err() != nil {
                    return nil
                }
                n.logger.Errorf("Failed to accept connection: %v", err)
                continue
            }

            n.wg.Add(1)
            go n.handleConnection(conn)
        }
    }
}

func (n *Node) handleConnection(conn net.Conn) {
    defer n.wg.Done()
    defer conn.Close()

    scanner := bufio.NewScanner(conn)
    peer := &Peer{
        ID:      "",
        Address: conn.RemoteAddr().String(),
        Conn:    conn,
        LastSeen: time.Now(),
    }

    n.logger.Infof("📞 New connection from %s", peer.Address)

    for scanner.Scan() {
        select {
        case <-n.ctx.Done():
            return
        default:
            line := scanner.Text()
            var msg Message
            if err := json.Unmarshal([]byte(line), &msg); err != nil {
                n.logger.Errorf("Failed to parse message: %v", err)
                continue
            }

            // Update peer info
            if peer.ID == "" && msg.From != "" {
                peer.ID = msg.From
                n.Peers.AddPeer(peer)
            }

            msg.peer = peer
            select {
            case n.Messages <- msg:
            case <-n.ctx.Done():
                return
            default:
                n.logger.Warn("Message queue full, dropping message")
            }
        }
    }

    if peer.ID != "" {
        n.Peers.RemovePeer(peer.ID)
        n.logger.Infof("📴 Peer %s disconnected", peer.ID[:8])
    }
}

func (n *Node) processMessages() {
    defer n.wg.Done()

    for {
        select {
        case <-n.ctx.Done():
            return
        case msg := <-n.Messages:
            n.handleMessage(msg)
        }
    }
}

func (n *Node) handleMessage(msg Message) {
    switch msg.Type {
    case MessageTypePing:
        n.handlePing(msg)
    case MessageTypePong:
        n.handlePong(msg)
    case MessageTypeBlock:
        n.handleBlock(msg)
    case MessageTypeTransaction:
        n.handleTransaction(msg)
    case MessageTypePeerDiscovery:
        n.handlePeerDiscovery(msg)
    default:
        n.logger.Warnf("Unknown message type: %s", msg.Type)
    }
}

func (n *Node) handlePing(msg Message) {
    pong := Message{
        Type:      MessageTypePong,
        From:      n.ID,
        To:        msg.From,
        Timestamp: time.Now(),
        Data:      map[string]interface{}{"pong": "pong"},
    }
    
    n.sendMessage(msg.peer, pong)
}

func (n *Node) handlePong(msg Message) {
    n.logger.Debugf("Received pong from %s", msg.From[:8])
    if peer := n.Peers.GetPeer(msg.From); peer != nil {
        peer.LastSeen = time.Now()
    }
}

func (n *Node) handleBlock(msg Message) {
    n.logger.Infof("📦 Received block from %s", msg.From[:8])
    
    // Forward to blockchain core for processing
    // In a real implementation, this would interface with the Rust core
    
    // Broadcast to other peers (excluding sender)
    n.broadcastMessage(msg, msg.From)
}

func (n *Node) handleTransaction(msg Message) {
    n.logger.Infof("💰 Received transaction from %s", msg.From[:8])
    
    // AI-powered fraud detection would happen here
    // For now, just broadcast
    n.broadcastMessage(msg, msg.From)
}

func (n *Node) handlePeerDiscovery(msg Message) {
    if peers, ok := msg.Data["peers"].([]interface{}); ok {
        n.logger.Infof("🔍 Discovered %d peers from %s", len(peers), msg.From[:8])
        
        for _, p := range peers {
            if peerAddr, ok := p.(string); ok {
                go n.connectToPeer(peerAddr)
            }
        }
    }
}

func (n *Node) sendMessage(peer *Peer, msg Message) error {
    data, err := json.Marshal(msg)
    if err != nil {
        return err
    }

    _, err = fmt.Fprintf(peer.Conn, "%s\n", string(data))
    return err
}

func (n *Node) broadcastMessage(msg Message, excludeID string) {
    peers := n.Peers.GetAllPeers()
    for _, peer := range peers {
        if peer.ID != excludeID {
            if err := n.sendMessage(peer, msg); err != nil {
                n.logger.Errorf("Failed to send message to %s: %v", peer.ID[:8], err)
            }
        }
    }
}

func (n *Node) ConnectToSeedPeers(seedPeers string) {
    peers := strings.Split(seedPeers, ",")
    for _, peerAddr := range peers {
        peerAddr = strings.TrimSpace(peerAddr)
        if peerAddr != "" {
            go n.connectToPeer(peerAddr)
        }
    }
}

func (n *Node) connectToPeer(address string) {
    n.logger.Infof("🔗 Connecting to peer: %s", address)
    
    conn, err := net.DialTimeout("tcp", address, 10*time.Second)
    if err != nil {
        n.logger.Errorf("Failed to connect to %s: %v", address, err)
        return
    }

    // Send ping to establish connection
    ping := Message{
        Type:      MessageTypePing,
        From:      n.ID,
        Timestamp: time.Now(),
        Data:      map[string]interface{}{"ping": "ping"},
    }

    data, _ := json.Marshal(ping)
    fmt.Fprintf(conn, "%s\n", string(data))

    // Handle this connection like any incoming connection
    n.wg.Add(1)
    go n.handleConnection(conn)
}

func (n *Node) StartPeerDiscovery() {
    ticker := time.NewTicker(30 * time.Second)
    defer ticker.Stop()

    for {
        select {
        case <-n.ctx.Done():
            return
        case <-ticker.C:
            n.discoverPeers()
        }
    }
}

func (n *Node) discoverPeers() {
    peers := n.Peers.GetAllPeers()
    if len(peers) == 0 {
        return
    }

    peerAddresses := make([]string, 0, len(peers))
    for _, peer := range peers {
        peerAddresses = append(peerAddresses, peer.Address)
    }

    discoveryMsg := Message{
        Type:      MessageTypePeerDiscovery,
        From:      n.ID,
        Timestamp: time.Now(),
        Data: map[string]interface{}{
            "peers": peerAddresses,
        },
    }

    n.broadcastMessage(discoveryMsg, "")
}

func (n *Node) StartNetworkOptimization() {
    // AI-powered network optimization
    ticker := time.NewTicker(60 * time.Second)
    defer ticker.Stop()

    for {
        select {
        case <-n.ctx.Done():
            return
        case <-ticker.C:
            n.optimizeNetwork()
        }
    }
}

func (n *Node) optimizeNetwork() {
    // This would integrate with the AI backend to optimize network performance
    n.logger.Debug("🧠 Running AI network optimization...")
    
    // Collect network metrics
    peerCount := n.Peers.GetPeerCount()
    
    n.logger.Debugf("Network stats - Peers: %d", peerCount)
    
    // In a real implementation, this would call the AI backend
    // to get optimization recommendations
}

func (n *Node) Stop() {
    n.logger.Info("🛑 Stopping P2P node...")
    
    n.cancel()
    
    if n.listener != nil {
        n.listener.Close()
    }

    // Close all peer connections
    peers := n.Peers.GetAllPeers()
    for _, peer := range peers {
        peer.Conn.Close()
    }

    n.wg.Wait()
    n.logger.Info("✅ P2P node stopped")
}
