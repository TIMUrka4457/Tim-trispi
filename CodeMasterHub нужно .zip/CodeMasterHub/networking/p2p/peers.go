package p2p

import (
    "sync"
    "time"
)

type PeerManager struct {
    peers map[string]*Peer
    mutex sync.RWMutex
}

func NewPeerManager() *PeerManager {
    return &PeerManager{
        peers: make(map[string]*Peer),
    }
}

func (pm *PeerManager) AddPeer(peer *Peer) {
    pm.mutex.Lock()
    defer pm.mutex.Unlock()
    
    peer.LastSeen = time.Now()
    pm.peers[peer.ID] = peer
}

func (pm *PeerManager) RemovePeer(peerID string) {
    pm.mutex.Lock()
    defer pm.mutex.Unlock()
    
    if peer, exists := pm.peers[peerID]; exists {
        peer.Conn.Close()
        delete(pm.peers, peerID)
    }
}

func (pm *PeerManager) GetPeer(peerID string) *Peer {
    pm.mutex.RLock()
    defer pm.mutex.RUnlock()
    
    return pm.peers[peerID]
}

func (pm *PeerManager) GetAllPeers() []*Peer {
    pm.mutex.RLock()
    defer pm.mutex.RUnlock()
    
    peers := make([]*Peer, 0, len(pm.peers))
    for _, peer := range pm.peers {
        peers = append(peers, peer)
    }
    
    return peers
}

func (pm *PeerManager) GetPeerCount() int {
    pm.mutex.RLock()
    defer pm.mutex.RUnlock()
    
    return len(pm.peers)
}

func (pm *PeerManager) CleanupStale(maxAge time.Duration) {
    pm.mutex.Lock()
    defer pm.mutex.Unlock()
    
    now := time.Now()
    for id, peer := range pm.peers {
        if now.Sub(peer.LastSeen) > maxAge {
            peer.Conn.Close()
            delete(pm.peers, id)
        }
    }
}

func (pm *PeerManager) GetActivePeers(maxAge time.Duration) []*Peer {
    pm.mutex.RLock()
    defer pm.mutex.RUnlock()
    
    now := time.Now()
    activePeers := make([]*Peer, 0)
    
    for _, peer := range pm.peers {
        if now.Sub(peer.LastSeen) <= maxAge {
            activePeers = append(activePeers, peer)
        }
    }
    
    return activePeers
}
