package main

import (
    "flag"
    "log"
    "os"
    "os/signal"
    "syscall"
    
    "trispi-networking/p2p"
    
    "github.com/sirupsen/logrus"
)

func main() {
    var (
        port = flag.String("port", "4000", "P2P listening port")
        aiEndpoint = flag.String("ai", "http://localhost:8000/api/ai", "AI backend endpoint")
        seedPeers = flag.String("peers", "", "Comma-separated list of seed peers")
    )
    flag.Parse()

    // Setup logging
    logrus.SetLevel(logrus.InfoLevel)
    logrus.SetFormatter(&logrus.TextFormatter{
        FullTimestamp: true,
    })

    log.Printf("🚀 Starting TRISPI P2P Network Node on port %s", *port)
    log.Printf("🧠 AI Backend: %s", *aiEndpoint)

    // Create P2P node
    node, err := p2p.NewNode(*port, *aiEndpoint)
    if err != nil {
        log.Fatalf("Failed to create P2P node: %v", err)
    }

    // Connect to seed peers if provided
    if *seedPeers != "" {
        node.ConnectToSeedPeers(*seedPeers)
    }

    // Start the node
    go func() {
        if err := node.Start(); err != nil {
            log.Fatalf("P2P node failed: %v", err)
        }
    }()

    // Start peer discovery
    go node.StartPeerDiscovery()

    // Start AI-powered network optimization
    go node.StartNetworkOptimization()

    log.Println("✅ TRISPI P2P Node started successfully")

    // Wait for interrupt signal
    c := make(chan os.Signal, 1)
    signal.Notify(c, os.Interrupt, syscall.SIGTERM)
    <-c

    log.Println("🛑 Shutting down TRISPI P2P Node...")
    node.Stop()
}
