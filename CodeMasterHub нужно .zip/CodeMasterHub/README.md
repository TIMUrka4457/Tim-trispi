# TRISPI Blockchain - Multi-Language AI-Powered Blockchain Platform

A comprehensive blockchain platform built with multiple programming languages, featuring AI-powered optimization, advanced security, and seamless integration across components.

## 🏗️ Architecture

The TRISPI blockchain consists of several interconnected components:

- **Rust Core**: High-performance blockchain core with consensus mechanism
- **Go Networking**: P2P networking layer for distributed communication
- **Python AI Backend**: Machine learning models for optimization and security
- **Solidity Contracts**: Smart contracts for token, staking, DAO, and security
- **TypeScript Wallet**: Frontend wallet interface with AI features

## 🚀 Quick Start

### Prerequisites

- Docker & Docker Compose
- Git
- At least 8GB RAM and 20GB disk space

### Environment Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd trispi-blockchain
   ```

2. **Environment Configuration**
   ```bash
   # Copy environment template
   cp .env.example .env
   
   # Edit environment variables
   nano .env
   ```

3. **Start the entire stack**
   ```bash
   # Start all services
   docker-compose up -d
   
   # Check service status
   docker-compose ps
   
   # View logs
   docker-compose logs -f
   ```

### Individual Component Setup

#### Rust Blockchain Core

```bash
cd blockchain-core

# Install dependencies
cargo build --release

# Run the blockchain node
cargo run -- --port 3030 --ai-endpoint http://localhost:8000/api/ai
