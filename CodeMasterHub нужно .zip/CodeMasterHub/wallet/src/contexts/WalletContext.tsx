import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { ethers } from 'ethers';
import detectEthereumProvider from '@metamask/detect-provider';
import { WalletState, WalletAction } from '../types/wallet';
import { walletService } from '../services/walletService';

interface WalletContextType extends WalletState {
  connect: () => Promise<void>;
  disconnect: () => void;
  sendTransaction: (to: string, amount: string) => Promise<string>;
  switchNetwork: (chainId: string) => Promise<void>;
  refreshBalance: () => Promise<void>;
}

const initialState: WalletState = {
  isConnected: false,
  address: null,
  balance: '0',
  network: null,
  provider: null,
  signer: null,
  isLoading: false,
  error: null,
};

function walletReducer(state: WalletState, action: WalletAction): WalletState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload, error: null };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'SET_CONNECTED':
      return {
        ...state,
        isConnected: true,
        address: action.payload.address,
        provider: action.payload.provider,
        signer: action.payload.signer,
        network: action.payload.network,
        isLoading: false,
        error: null,
      };
    case 'SET_DISCONNECTED':
      return {
        ...initialState,
      };
    case 'SET_BALANCE':
      return { ...state, balance: action.payload };
    case 'SET_NETWORK':
      return { ...state, network: action.payload };
    default:
      return state;
  }
}

const WalletContext = createContext<WalletContextType | null>(null);

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(walletReducer, initialState);

  // Initialize wallet connection on mount
  useEffect(() => {
    const initializeWallet = async () => {
      try {
        const provider = await detectEthereumProvider({ silent: true });
        if (provider && (window as any).ethereum?.selectedAddress) {
          await connect();
        }
      } catch (error) {
        console.error('Failed to initialize wallet:', error);
      }
    };

    initializeWallet();
  }, []);

  // Listen for account changes
  useEffect(() => {
    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        disconnect();
      } else if (accounts[0] !== state.address) {
        // Account changed, reconnect
        connect();
      }
    };

    const handleChainChanged = () => {
      // Reload the page when chain changes
      window.location.reload();
    };

    if ((window as any).ethereum) {
      (window as any).ethereum.on('accountsChanged', handleAccountsChanged);
      (window as any).ethereum.on('chainChanged', handleChainChanged);

      return () => {
        (window as any).ethereum.removeListener('accountsChanged', handleAccountsChanged);
        (window as any).ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, [state.address]);

  const connect = async (): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });

      const provider = await detectEthereumProvider();
      if (!provider) {
        throw new Error('MetaMask not detected. Please install MetaMask.');
      }

      // Request account access
      const accounts = await (window as any).ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (accounts.length === 0) {
        throw new Error('No accounts found. Please connect your wallet.');
      }

      const ethersProvider = new ethers.BrowserProvider((window as any).ethereum);
      const signer = await ethersProvider.getSigner();
      const address = await signer.getAddress();
      const network = await ethersProvider.getNetwork();

      dispatch({
        type: 'SET_CONNECTED',
        payload: {
          address,
          provider: ethersProvider,
          signer,
          network: {
            chainId: Number(network.chainId),
            name: network.name,
          },
        },
      });

      // Fetch initial balance
      await refreshBalance(ethersProvider, address);
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const disconnect = (): void => {
    dispatch({ type: 'SET_DISCONNECTED' });
  };

  const sendTransaction = async (to: string, amount: string): Promise<string> => {
    if (!state.signer) {
      throw new Error('Wallet not connected');
    }

    try {
      dispatch({ type: 'SET_LOADING', payload: true });

      const tx = await walletService.sendTransaction(state.signer, to, amount);
      
      // Refresh balance after transaction
      if (state.provider && state.address) {
        await refreshBalance(state.provider, state.address);
      }

      dispatch({ type: 'SET_LOADING', payload: false });
      return tx.hash;
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  const switchNetwork = async (chainId: string): Promise<void> => {
    try {
      await (window as any).ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId }],
      });
    } catch (error: any) {
      // If the network doesn't exist, add it
      if (error.code === 4902) {
        // Add network logic here for custom networks
        throw new Error('Network not found. Please add the network manually.');
      }
      throw error;
    }
  };

  const refreshBalance = async (
    provider?: ethers.Provider,
    address?: string
  ): Promise<void> => {
    const currentProvider = provider || state.provider;
    const currentAddress = address || state.address;

    if (!currentProvider || !currentAddress) {
      return;
    }

    try {
      const balance = await walletService.getBalance(currentProvider, currentAddress);
      dispatch({ type: 'SET_BALANCE', payload: balance });
    } catch (error) {
      console.error('Failed to refresh balance:', error);
    }
  };

  const contextValue: WalletContextType = {
    ...state,
    connect,
    disconnect,
    sendTransaction,
    switchNetwork,
    refreshBalance: () => refreshBalance(),
  };

  return (
    <WalletContext.Provider value={contextValue}>
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = (): WalletContextType => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
