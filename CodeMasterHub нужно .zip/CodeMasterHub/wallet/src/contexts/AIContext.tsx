import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { AIState, AIAction, AIFeatures } from '../types/ai';
import { aiService } from '../services/aiService';

interface AIContextType extends AIState {
  refreshAI: () => Promise<void>;
  updateFeeSuggestion: (networkStats: any) => Promise<void>;
  checkTransactionSecurity: (txData: string) => Promise<boolean>;
  getPortfolioAdvice: (token: string) => Promise<any>;
  analyzeTransaction: (txHash: string) => Promise<any>;
}

const initialState: AIState = {
  isConnected: false,
  features: {
    feeSuggestion: null,
    securityAlert: null,
    portfolioAdvice: null,
    transactionExplanation: null,
    fraudDetection: null,
  },
  lastUpdate: null,
  isLoading: false,
  error: null,
};

function aiReducer(state: AIState, action: AIAction): AIState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload, error: null };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'SET_CONNECTED':
      return { ...state, isConnected: action.payload, error: null };
    case 'UPDATE_FEATURES':
      return {
        ...state,
        features: { ...state.features, ...action.payload },
        lastUpdate: new Date(),
        isLoading: false,
      };
    case 'UPDATE_FEE_SUGGESTION':
      return {
        ...state,
        features: { ...state.features, feeSuggestion: action.payload },
        lastUpdate: new Date(),
      };
    case 'UPDATE_SECURITY_ALERT':
      return {
        ...state,
        features: { ...state.features, securityAlert: action.payload },
        lastUpdate: new Date(),
      };
    case 'UPDATE_PORTFOLIO_ADVICE':
      return {
        ...state,
        features: { ...state.features, portfolioAdvice: action.payload },
        lastUpdate: new Date(),
      };
    case 'UPDATE_TRANSACTION_EXPLANATION':
      return {
        ...state,
        features: { ...state.features, transactionExplanation: action.payload },
        lastUpdate: new Date(),
      };
    default:
      return state;
  }
}

const AIContext = createContext<AIContextType | null>(null);

export const AIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(aiReducer, initialState);

  // Initialize AI connection
  useEffect(() => {
    const initializeAI = async () => {
      try {
        const isConnected = await aiService.checkConnection();
        dispatch({ type: 'SET_CONNECTED', payload: isConnected });
        
        if (isConnected) {
          await refreshAI();
        }
      } catch (error) {
        console.error('Failed to initialize AI:', error);
        dispatch({ type: 'SET_CONNECTED', payload: false });
      }
    };

    initializeAI();
  }, []);

  // Periodic AI updates
  useEffect(() => {
    const interval = setInterval(async () => {
      if (state.isConnected) {
        await refreshAI();
      }
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [state.isConnected]);

  const refreshAI = async (): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });

      // Check AI service health
      const isConnected = await aiService.checkConnection();
      dispatch({ type: 'SET_CONNECTED', payload: isConnected });

      if (!isConnected) {
        dispatch({ type: 'SET_ERROR', payload: 'AI service is not available' });
        return;
      }

      // Get default fee suggestion
      const feeSuggestion = await aiService.getFeeSuggestion({
        mode: 'eco',
        networkLoad: 0.5,
        txCount: 100,
        avgTps: 1000,
        blockTime: 10,
        mempoolSize: 50,
      });

      dispatch({ type: 'UPDATE_FEE_SUGGESTION', payload: feeSuggestion });
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message });
    }
  };

  const updateFeeSuggestion = async (networkStats: any): Promise<void> => {
    try {
      const feeSuggestion = await aiService.getFeeSuggestion(networkStats);
      dispatch({ type: 'UPDATE_FEE_SUGGESTION', payload: feeSuggestion });
    } catch (error: any) {
      console.error('Failed to update fee suggestion:', error);
    }
  };

  const checkTransactionSecurity = async (txData: string): Promise<boolean> => {
    try {
      const result = await aiService.checkTransactionSecurity(txData, []);
      dispatch({ type: 'UPDATE_SECURITY_ALERT', payload: result });
      return result.isSafe;
    } catch (error: any) {
      console.error('Failed to check transaction security:', error);
      return true; // Default to safe if check fails
    }
  };

  const getPortfolioAdvice = async (token: string): Promise<any> => {
    try {
      const advice = await aiService.getPortfolioAdvice(token);
      dispatch({ type: 'UPDATE_PORTFOLIO_ADVICE', payload: advice });
      return advice;
    } catch (error: any) {
      console.error('Failed to get portfolio advice:', error);
      return null;
    }
  };

  const analyzeTransaction = async (txHash: string): Promise<any> => {
    try {
      const explanation = await aiService.explainTransaction(txHash);
      dispatch({ type: 'UPDATE_TRANSACTION_EXPLANATION', payload: explanation });
      return explanation;
    } catch (error: any) {
      console.error('Failed to analyze transaction:', error);
      return null;
    }
  };

  const contextValue: AIContextType = {
    ...state,
    refreshAI,
    updateFeeSuggestion,
    checkTransactionSecurity,
    getPortfolioAdvice,
    analyzeTransaction,
  };

  return (
    <AIContext.Provider value={contextValue}>
      {children}
    </AIContext.Provider>
  );
};

export const useAI = (): AIContextType => {
  const context = useContext(AIContext);
  if (!context) {
    throw new Error('useAI must be used within an AIProvider');
  }
  return context;
};
