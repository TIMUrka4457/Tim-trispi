import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useWallet } from './hooks/useWallet';
import { useAI } from './hooks/useAI';
import Dashboard from './components/Dashboard';
import TransactionHistory from './components/TransactionHistory';
import AIInsights from './components/AIInsights';
import SecurityStatus from './components/SecurityStatus';
import { Wallet, Brain, Shield, History, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

const App: React.FC = () => {
  const { isConnected, connect, disconnect, address, balance } = useWallet();
  const { aiStatus, refreshAI } = useAI();
  const [activeTab, setActiveTab] = React.useState('dashboard');

  const handleConnect = async () => {
    try {
      await connect();
      toast.success('Wallet connected successfully!');
    } catch (error) {
      toast.error('Failed to connect wallet');
      console.error('Connection error:', error);
    }
  };

  const handleDisconnect = () => {
    disconnect();
    toast.success('Wallet disconnected');
  };

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Wallet },
    { id: 'history', label: 'History', icon: History },
    { id: 'ai-insights', label: 'AI Insights', icon: Brain },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <header className="bg-gray-800/50 backdrop-blur-md border-b border-gray-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">T</span>
              </div>
              <h1 className="text-xl font-bold text-white">TRISPI Wallet</h1>
            </div>

            {/* AI Status Indicator */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${aiStatus.isConnected ? 'bg-green-400' : 'bg-red-400'}`} />
                <span className="text-sm text-gray-300">
                  AI {aiStatus.isConnected ? 'Online' : 'Offline'}
                </span>
              </div>

              {/* Wallet Connection */}
              {isConnected ? (
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <div className="text-sm text-gray-300">
                      {address?.slice(0, 6)}...{address?.slice(-4)}
                    </div>
                    <div className="text-xs text-gray-400">
                      {balance} TRI
                    </div>
                  </div>
                  <button
                    onClick={handleDisconnect}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                  >
                    Disconnect
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleConnect}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Connect Wallet
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {!isConnected ? (
        /* Welcome Screen */
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-md mx-auto px-6"
          >
            <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-8">
              <Wallet className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">
              Welcome to TRISPI Wallet
            </h2>
            <p className="text-gray-300 mb-8">
              Experience the future of blockchain with AI-powered insights, 
              advanced security, and seamless transactions.
            </p>
            <button
              onClick={handleConnect}
              className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-lg font-medium"
            >
              Connect Your Wallet
            </button>
          </motion.div>
        </div>
      ) : (
        /* Main Application */
        <div className="flex">
          {/* Sidebar Navigation */}
          <nav className="w-64 bg-gray-800/30 backdrop-blur-md border-r border-gray-700/50 min-h-[calc(100vh-4rem)]">
            <div className="p-4 space-y-2">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                      activeTab === item.id
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-300 hover:bg-gray-700/50 hover:text-white'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </nav>

          {/* Main Content */}
          <main className="flex-1 p-6">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && <Dashboard />}
              {activeTab === 'history' && <TransactionHistory />}
              {activeTab === 'ai-insights' && <AIInsights />}
              {activeTab === 'security' && <SecurityStatus />}
            </motion.div>
          </main>
        </div>
      )}
    </div>
  );
};

export default App;
