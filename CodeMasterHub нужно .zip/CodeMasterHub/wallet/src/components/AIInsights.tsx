import React, { useState, useEffect } from 'react';
import { useAI } from '../hooks/useAI';
import { useWallet } from '../hooks/useWallet';
import { Brain, TrendingUp, Shield, Zap, AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const AIInsights: React.FC = () => {
  const { features, refreshAI, isLoading, isConnected, error } = useAI();
  const { address, provider } = useWallet();
  const [gasData, setGasData] = useState<any>(null);
  const [portfolioData, setPortfolioData] = useState<any>(null);
  const [securityScore, setSecurityScore] = useState<number>(95);

  useEffect(() => {
    if (isConnected) {
      loadAIData();
    }
  }, [isConnected, address]);

  const loadAIData = async () => {
    try {
      // Simulate loading portfolio and gas data
      setGasData({
        historical: [
          { time: '1h', price: 20, predicted: 22 },
          { time: '2h', price: 25, predicted: 24 },
          { time: '3h', price: 18, predicted: 19 },
          { time: '4h', price: 30, predicted: 28 },
          { time: '5h', price: 22, predicted: 21 },
          { time: '6h', price: 15, predicted: 16 },
        ]
      });

      setPortfolioData({
        recommendations: [
          { token: 'TRI', action: 'HOLD', confidence: 0.85, reason: 'Strong fundamentals and growing ecosystem' },
          { token: 'ETH', action: 'BUY', confidence: 0.92, reason: 'Expected price increase after upcoming upgrade' },
          { token: 'BTC', action: 'HOLD', confidence: 0.78, reason: 'Consolidation phase, wait for breakout' },
        ]
      });
    } catch (error) {
      console.error('Failed to load AI data:', error);
    }
  };

  const gasChartData = {
    labels: gasData?.historical?.map((d: any) => d.time) || [],
    datasets: [
      {
        label: 'Actual Gas Price',
        data: gasData?.historical?.map((d: any) => d.price) || [],
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.4,
      },
      {
        label: 'AI Predicted',
        data: gasData?.historical?.map((d: any) => d.predicted) || [],
        borderColor: 'rgb(168, 85, 247)',
        backgroundColor: 'rgba(168, 85, 247, 0.1)',
        borderDash: [5, 5],
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: '#9CA3AF',
        },
      },
      title: {
        display: true,
        text: 'Gas Price Prediction',
        color: '#F3F4F6',
      },
    },
    scales: {
      x: {
        ticks: { color: '#9CA3AF' },
        grid: { color: '#374151' },
      },
      y: {
        ticks: { color: '#9CA3AF' },
        grid: { color: '#374151' },
      },
    },
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'BUY': return 'text-green-400';
      case 'SELL': return 'text-red-400';
      case 'HOLD': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getActionBg = (action: string) => {
    switch (action) {
      case 'BUY': return 'bg-green-400/10 border-green-400/20';
      case 'SELL': return 'bg-red-400/10 border-red-400/20';
      case 'HOLD': return 'bg-blue-400/10 border-blue-400/20';
      default: return 'bg-gray-400/10 border-gray-400/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Insights</h1>
          <p className="text-gray-400">
            AI-powered analytics for smarter trading decisions
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${
            isConnected ? 'bg-green-400/10 text-green-400' : 'bg-red-400/10 text-red-400'
          }`}>
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`} />
            <span className="text-sm">AI {isConnected ? 'Online' : 'Offline'}</span>
          </div>
          <button
            onClick={refreshAI}
            disabled={isLoading}
            className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-400/10 border border-red-400/20 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <span className="text-red-400 font-medium">AI Service Error</span>
          </div>
          <p className="text-red-300 text-sm mt-1">{error}</p>
        </div>
      )}

      {/* AI Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-400/10 rounded-lg">
                <Brain className="w-5 h-5 text-purple-400" />
              </div>
              <span className="text-white font-medium">AI Analysis</span>
            </div>
            <CheckCircle className="w-5 h-5 text-green-400" />
          </div>
          <div className="text-2xl font-bold text-white mb-1">Active</div>
          <div className="text-gray-400 text-sm">Running continuous analysis</div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-400/10 rounded-lg">
                <Shield className="w-5 h-5 text-green-400" />
              </div>
              <span className="text-white font-medium">Security Score</span>
            </div>
          </div>
          <div className="text-2xl font-bold text-green-400 mb-1">{securityScore}%</div>
          <div className="text-gray-400 text-sm">Excellent security rating</div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-yellow-400/10 rounded-lg">
                <Zap className="w-5 h-5 text-yellow-400" />
              </div>
              <span className="text-white font-medium">Gas Savings</span>
            </div>
          </div>
          <div className="text-2xl font-bold text-yellow-400 mb-1">12.3%</div>
          <div className="text-gray-400 text-sm">Average savings this month</div>
        </motion.div>
      </div>

      {/* Gas Price Analysis */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Gas Price Intelligence</h3>
          <Zap className="w-5 h-5 text-yellow-400" />
        </div>

        {features.feeSuggestion && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-green-400 text-sm font-medium">Eco Mode</div>
              <div className="text-white text-lg font-bold">
                {features.feeSuggestion.modes?.eco?.toFixed(4) || 'N/A'} ETH
              </div>
              <div className="text-gray-400 text-xs">~5-10 minutes</div>
            </div>
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-blue-400 text-sm font-medium">Standard</div>
              <div className="text-white text-lg font-bold">
                {features.feeSuggestion.modes?.standard?.toFixed(4) || 'N/A'} ETH
              </div>
              <div className="text-gray-400 text-xs">~2-3 minutes</div>
            </div>
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-yellow-400 text-sm font-medium">Fast</div>
              <div className="text-white text-lg font-bold">
                {features.feeSuggestion.modes?.fast?.toFixed(4) || 'N/A'} ETH
              </div>
              <div className="text-gray-400 text-xs">~30 seconds</div>
            </div>
          </div>
        )}

        {gasData && (
          <div className="h-64">
            <Line data={gasChartData} options={chartOptions} />
          </div>
        )}
      </motion.div>

      {/* Portfolio Recommendations */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Portfolio Recommendations</h3>
          <TrendingUp className="w-5 h-5 text-blue-400" />
        </div>

        {portfolioData?.recommendations ? (
          <div className="space-y-4">
            {portfolioData.recommendations.map((rec: any, index: number) => (
              <motion.div
                key={rec.token}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index }}
                className={`border rounded-lg p-4 ${getActionBg(rec.action)}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-white font-medium">{rec.token}</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getActionColor(rec.action)}`}>
                      {rec.action}
                    </span>
                  </div>
                  <div className="text-white font-medium">
                    {(rec.confidence * 100).toFixed(1)}% confidence
                  </div>
                </div>
                <p className="text-gray-300 text-sm">{rec.reason}</p>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <TrendingUp className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">No portfolio recommendations available</p>
            <p className="text-gray-500 text-sm mt-1">
              Add some tokens to your portfolio to get AI-powered insights
            </p>
          </div>
        )}
      </motion.div>

      {/* Security Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Security Analysis</h3>
          <Shield className="w-5 h-5 text-green-400" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-white font-medium mb-3">Threat Detection</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Malicious Addresses</span>
                <span className="text-green-400">0 detected</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Suspicious Transactions</span>
                <span className="text-green-400">0 flagged</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Scam Contracts</span>
                <span className="text-green-400">Protected</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-white font-medium mb-3">Protection Status</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">MEV Protection</span>
                <span className="text-green-400">Active</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Front-run Detection</span>
                <span className="text-green-400">Enabled</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Sandwich Protection</span>
                <span className="text-green-400">Active</span>
              </div>
            </div>
          </div>
        </div>

        {features.securityAlert && (
          <div className="mt-6 p-4 bg-yellow-400/10 border border-yellow-400/20 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-400 font-medium">Security Alert</span>
            </div>
            <p className="text-yellow-300 text-sm">
              Risk Score: {(features.securityAlert.riskScore * 100).toFixed(1)}%
            </p>
            <div className="mt-2">
              {features.securityAlert.reasons.map((reason: string, index: number) => (
                <div key={index} className="text-yellow-200 text-xs">• {reason}</div>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default AIInsights;
