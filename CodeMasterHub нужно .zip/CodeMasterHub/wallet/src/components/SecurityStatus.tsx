import React, { useState, useEffect } from 'react';
import { useWallet } from '../hooks/useWallet';
import { useAI } from '../hooks/useAI';
import { Shield, AlertTriangle, CheckCircle, XCircle, Eye, Lock, Zap, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';

interface SecurityMetric {
  label: string;
  status: 'excellent' | 'good' | 'warning' | 'danger';
  value: string;
  description: string;
}

interface ThreatAlert {
  id: string;
  type: 'malware' | 'phishing' | 'suspicious' | 'mev';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  timestamp: Date;
  resolved: boolean;
}

const SecurityStatus: React.FC = () => {
  const { address, provider } = useWallet();
  const { checkTransactionSecurity, isConnected } = useAI();
  const [securityScore, setSecurityScore] = useState<number>(95);
  const [scanning, setScanning] = useState<boolean>(false);
  const [lastScan, setLastScan] = useState<Date | null>(null);
  const [threats, setThreats] = useState<ThreatAlert[]>([]);
  
  const securityMetrics: SecurityMetric[] = [
    {
      label: 'Wallet Security',
      status: 'excellent',
      value: '95%',
      description: 'Your wallet has excellent security practices',
    },
    {
      label: 'Address Reputation',
      status: 'excellent',
      value: 'Clean',
      description: 'No malicious activity detected',
    },
    {
      label: 'Transaction Safety',
      status: 'good',
      value: '98%',
      description: 'Most transactions are safe',
    },
    {
      label: 'AI Protection',
      status: isConnected ? 'excellent' : 'warning',
      value: isConnected ? 'Active' : 'Offline',
      description: isConnected ? 'AI threat detection is running' : 'AI service is offline',
    },
  ];

  useEffect(() => {
    if (address) {
      performSecurityScan();
    }
  }, [address]);

  const performSecurityScan = async () => {
    setScanning(true);
    
    try {
      // Simulate security scanning
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate some sample threats for demonstration
      const sampleThreats: ThreatAlert[] = [
        {
          id: '1',
          type: 'phishing',
          severity: 'medium',
          title: 'Suspicious website interaction',
          description: 'Detected interaction with a potentially malicious website. Exercise caution.',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
          resolved: false,
        },
      ];
      
      setThreats(sampleThreats);
      setLastScan(new Date());
      
      // Calculate security score based on threats
      const threatScore = sampleThreats.reduce((score, threat) => {
        if (threat.resolved) return score;
        switch (threat.severity) {
          case 'critical': return score - 20;
          case 'high': return score - 10;
          case 'medium': return score - 5;
          case 'low': return score - 2;
          default: return score;
        }
      }, 100);
      
      setSecurityScore(Math.max(0, threatScore));
    } catch (error) {
      console.error('Security scan failed:', error);
    } finally {
      setScanning(false);
    }
  };

  const getStatusIcon = (status: SecurityMetric['status']) => {
    switch (status) {
      case 'excellent':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'good':
        return <CheckCircle className="w-5 h-5 text-blue-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'danger':
        return <XCircle className="w-5 h-5 text-red-400" />;
    }
  };

  const getStatusColor = (status: SecurityMetric['status']) => {
    switch (status) {
      case 'excellent':
        return 'border-green-400/20 bg-green-400/10';
      case 'good':
        return 'border-blue-400/20 bg-blue-400/10';
      case 'warning':
        return 'border-yellow-400/20 bg-yellow-400/10';
      case 'danger':
        return 'border-red-400/20 bg-red-400/10';
    }
  };

  const getThreatColor = (severity: ThreatAlert['severity']) => {
    switch (severity) {
      case 'critical':
        return 'border-red-500/30 bg-red-500/10';
      case 'high':
        return 'border-red-400/30 bg-red-400/10';
      case 'medium':
        return 'border-yellow-400/30 bg-yellow-400/10';
      case 'low':
        return 'border-blue-400/30 bg-blue-400/10';
    }
  };

  const getThreatIcon = (type: ThreatAlert['type']) => {
    switch (type) {
      case 'malware':
        return <XCircle className="w-4 h-4" />;
      case 'phishing':
        return <Eye className="w-4 h-4" />;
      case 'suspicious':
        return <AlertTriangle className="w-4 h-4" />;
      case 'mev':
        return <Zap className="w-4 h-4" />;
    }
  };

  const resolveAlert = (alertId: string) => {
    setThreats(prev => 
      prev.map(threat => 
        threat.id === alertId ? { ...threat, resolved: true } : threat
      )
    );
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-400';
    if (score >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreDescription = (score: number) => {
    if (score >= 90) return 'Excellent';
    if (score >= 70) return 'Good';
    if (score >= 50) return 'Fair';
    return 'Poor';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Security Status</h1>
          <p className="text-gray-400">
            AI-powered security monitoring and threat detection
          </p>
        </div>
        <button
          onClick={performSecurityScan}
          disabled={scanning}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${scanning ? 'animate-spin' : ''}`} />
          <span>Scan</span>
        </button>
      </div>

      {/* Security Score */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative w-24 h-24">
              <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="rgba(156, 163, 175, 0.2)"
                  strokeWidth="2"
                />
                <path
                  d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke={securityScore >= 90 ? '#10B981' : securityScore >= 70 ? '#F59E0B' : '#EF4444'}
                  strokeWidth="2"
                  strokeDasharray={`${securityScore}, 100`}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <Shield className={`w-8 h-8 ${getScoreColor(securityScore)}`} />
              </div>
            </div>
          </div>
          <div className={`text-3xl font-bold ${getScoreColor(securityScore)}`}>
            {securityScore}%
          </div>
          <div className="text-gray-400 text-sm mt-1">
            {getScoreDescription(securityScore)} Security Score
          </div>
          {lastScan && (
            <div className="text-gray-500 text-xs mt-2">
              Last scan: {lastScan.toLocaleTimeString()}
            </div>
          )}
        </div>
      </motion.div>

      {/* Security Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {securityMetrics.map((metric, index) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`border rounded-xl p-4 ${getStatusColor(metric.status)}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-white font-medium">{metric.label}</span>
              {getStatusIcon(metric.status)}
            </div>
            <div className="text-lg font-bold text-white mb-1">{metric.value}</div>
            <div className="text-gray-400 text-sm">{metric.description}</div>
          </motion.div>
        ))}
      </div>

      {/* Threat Alerts */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Threat Alerts</h3>
          <span className="text-gray-400 text-sm">
            {threats.filter(t => !t.resolved).length} active alerts
          </span>
        </div>

        {threats.length === 0 ? (
          <div className="text-center py-8">
            <Shield className="w-12 h-12 text-green-400 mx-auto mb-3" />
            <h4 className="text-green-400 font-medium mb-2">All Clear!</h4>
            <p className="text-gray-400 text-sm">No security threats detected</p>
          </div>
        ) : (
          <div className="space-y-3">
            {threats.map((threat, index) => (
              <motion.div
                key={threat.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`border rounded-lg p-4 ${getThreatColor(threat.severity)} ${
                  threat.resolved ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${getThreatColor(threat.severity)}`}>
                      {getThreatIcon(threat.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-white font-medium">{threat.title}</h4>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          threat.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                          threat.severity === 'high' ? 'bg-red-400/20 text-red-400' :
                          threat.severity === 'medium' ? 'bg-yellow-400/20 text-yellow-400' :
                          'bg-blue-400/20 text-blue-400'
                        }`}>
                          {threat.severity.toUpperCase()}
                        </span>
                        {threat.resolved && (
                          <span className="px-2 py-1 rounded text-xs font-medium bg-green-400/20 text-green-400">
                            RESOLVED
                          </span>
                        )}
                      </div>
                      <p className="text-gray-300 text-sm mt-1">{threat.description}</p>
                      <div className="text-gray-500 text-xs mt-2">
                        {threat.timestamp.toLocaleString()}
                      </div>
                    </div>
                  </div>
                  {!threat.resolved && (
                    <button
                      onClick={() => resolveAlert(threat.id)}
                      className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-xs rounded transition-colors"
                    >
                      Resolve
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Security Recommendations */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Security Recommendations</h3>
        
        <div className="space-y-3">
          {[
            {
              icon: <Lock className="w-4 h-4" />,
              text: 'Enable hardware wallet for maximum security',
              status: 'recommended',
            },
            {
              icon: <Eye className="w-4 h-4" />,
              text: 'Review all transaction details before signing',
              status: 'active',
            },
            {
              icon: <Shield className="w-4 h-4" />,
              text: 'Keep your wallet software updated',
              status: 'active',
            },
            {
              icon: <AlertTriangle className="w-4 h-4" />,
              text: 'Be cautious of suspicious links and websites',
              status: 'active',
            },
          ].map((rec, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                rec.status === 'active' ? 'bg-green-400/10 text-green-400' : 'bg-gray-400/10 text-gray-400'
              }`}>
                {rec.icon}
              </div>
              <span className="text-gray-300 text-sm">{rec.text}</span>
              {rec.status === 'active' && (
                <CheckCircle className="w-4 h-4 text-green-400" />
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Protection Features */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Active Protection Features</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { name: 'MEV Protection', status: true, description: 'Protects against front-running' },
            { name: 'Sandwich Attack Prevention', status: true, description: 'Blocks sandwich attacks' },
            { name: 'Malicious Contract Detection', status: true, description: 'Scans contracts for threats' },
            { name: 'Phishing Protection', status: isConnected, description: 'Warns about malicious sites' },
            { name: 'Transaction Simulation', status: true, description: 'Previews transaction effects' },
            { name: 'Real-time Threat Intelligence', status: isConnected, description: 'AI-powered threat detection' },
          ].map((feature, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
              <div>
                <div className="text-white font-medium text-sm">{feature.name}</div>
                <div className="text-gray-400 text-xs">{feature.description}</div>
              </div>
              <div className={`w-2 h-2 rounded-full ${
                feature.status ? 'bg-green-400' : 'bg-red-400'
              }`} />
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default SecurityStatus;
