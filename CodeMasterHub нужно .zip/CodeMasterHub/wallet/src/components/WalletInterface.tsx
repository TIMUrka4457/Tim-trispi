import React, { useState, useEffect } from 'react';
import { useWallet } from '../hooks/useWallet';
import { useAI } from '../hooks/useAI';
import { trispiWallet } from '../wallet';
import { aiClient } from '../ai/client';
import { aiFeatureManager } from '../ai/features';
import { 
  Send, 
  QrCode, 
  Copy, 
  ExternalLink, 
  Shield, 
  Zap, 
  TrendingUp,
  Settings,
  Eye,
  EyeOff,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import QRCode from 'qrcode.react';

interface WalletInterfaceProps {
  className?: string;
}

const WalletInterface: React.FC<WalletInterfaceProps> = ({ className = '' }) => {
  const { isConnected, address, balance } = useWallet();
  const { features, isLoading: aiLoading } = useAI();
  
  // Local state
  const [activeTab, setActiveTab] = useState<'send' | 'receive' | 'stake' | 'history'>('send');
  const [showBalance, setShowBalance] = useState(true);
  const [sendForm, setSendForm] = useState({
    to: '',
    amount: '',
    gasMode: 'standard' as 'eco' | 'standard' | 'fast' | 'priority',
  });
  const [loading, setLoading] = useState(false);
  const [qrCodeVisible, setQrCodeVisible] = useState(false);
  const [aiInsights, setAIInsights] = useState<any>(null);
  const [securityStatus, setSecurityStatus] = useState<any>(null);

  // Effects
  useEffect(() => {
    if (isConnected && address) {
      loadAIInsights();
      loadSecurityStatus();
    }
  }, [isConnected, address]);

  // Load AI insights
  const loadAIInsights = async () => {
    try {
      const [gasPrice, portfolioAnalysis] = await Promise.all([
        aiClient.getGasPrices(),
        address ? aiClient.analyzePortfolio({
          address,
          tokens: [
            { address: 'eth', balance: balance, symbol: 'ETH' },
            { address: 'trispi', balance: '0', symbol: 'TRI' }
          ],
          timeframe: '7d'
        }) : null
      ]);

      setAIInsights({
        gasPrices: gasPrice.data,
        portfolio: portfolioAnalysis?.data,
      });
    } catch (error) {
      console.error('Failed to load AI insights:', error);
    }
  };

  // Load security status
  const loadSecurityStatus = async () => {
    try {
      if (address) {
        const analysis = await trispiWallet.getSecurityAnalysis();
        setSecurityStatus(analysis);
      }
    } catch (error) {
      console.error('Failed to load security status:', error);
    }
  };

  // Handle send transaction
  const handleSend = async () => {
    if (!sendForm.to || !sendForm.amount) {
      toast.error('Please fill in all fields');
      return;
    }

    if (!trispiWallet.isValidAddress(sendForm.to)) {
      toast.error('Invalid recipient address');
      return;
    }

    try {
      setLoading(true);

      // AI security check
      const securityCheck = await aiClient.analyzeSecurity({
        transactionData: JSON.stringify({
          from: address,
          to: sendForm.to,
          amount: sendForm.amount,
        }),
        senderHistory: [],
        value: sendForm.amount,
      });

      if (securityCheck.data && !securityCheck.data.isSafe) {
        const proceed = window.confirm(
          `Security warning: ${securityCheck.data.reasons.join(', ')}. Do you want to proceed?`
        );
        if (!proceed) {
          setLoading(false);
          return;
        }
      }

      // Send transaction
      const result = await trispiWallet.sendTransaction(sendForm.to, sendForm.amount);
      
      toast.success(`Transaction sent! Hash: ${result.hash.slice(0, 10)}...`);
      setSendForm({ to: '', amount: '', gasMode: 'standard' });
      
      // Refresh balance
      setTimeout(() => {
        window.location.reload();
      }, 2000);

    } catch (error: any) {
      console.error('Send transaction failed:', error);
      toast.error(error.message || 'Transaction failed');
    } finally {
      setLoading(false);
    }
  };

  // Copy address to clipboard
  const copyAddress = async () => {
    if (address) {
      try {
        await navigator.clipboard.writeText(address);
        toast.success('Address copied to clipboard');
      } catch {
        toast.error('Failed to copy address');
      }
    }
  };

  // Format balance display
  const formatBalance = (bal: string) => {
    const num = parseFloat(bal);
    if (num === 0) return '0.0000';
    if (num < 0.0001) return '< 0.0001';
    return num.toFixed(4);
  };

  // Get security status color
  const getSecurityColor = (score: number) => {
    if (score >= 90) return 'text-green-400';
    if (score >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (!isConnected) {
    return (
      <div className={`bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 ${className}`}>
        <div className="text-center">
          <Shield className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-400 mb-2">Wallet Not Connected</h3>
          <p className="text-gray-500">Please connect your wallet to access the interface</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl ${className}`}>
      {/* Header */}
      <div className="p-6 border-b border-gray-700/50">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-xl">T</span>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">TRISPI Wallet</h2>
              <p className="text-gray-400 text-sm">
                {address?.slice(0, 6)}...{address?.slice(-4)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowBalance(!showBalance)}
              className="p-2 text-gray-400 hover:text-white transition-colors"
            >
              {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            </button>
            <button
              onClick={copyAddress}
              className="p-2 text-gray-400 hover:text-white transition-colors"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Balance */}
        <div className="text-center">
          <div className="text-3xl font-bold text-white mb-2">
            {showBalance ? `${formatBalance(balance)} ETH` : '••••••••'}
          </div>
          {aiInsights?.portfolio && (
            <div className="text-gray-400 text-sm">
              ≈ ${(parseFloat(balance) * 2000).toFixed(2)} USD
            </div>
          )}
        </div>

        {/* AI Status Bar */}
        {features.feeSuggestion && (
          <div className="mt-4 p-3 bg-blue-400/10 border border-blue-400/20 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Brain className="w-4 h-4 text-blue-400" />
                <span className="text-blue-400 text-sm font-medium">AI Optimization Active</span>
              </div>
              <div className="text-blue-300 text-xs">
                Gas saved: {features.feeSuggestion.modes?.eco ? 
                  ((features.feeSuggestion.suggested - features.feeSuggestion.modes.eco) * 100).toFixed(1) : '0'}%
              </div>
            </div>
          </div>
        )}

        {/* Security Status */}
        {securityStatus && (
          <div className="mt-2 flex items-center justify-between text-sm">
            <div className="flex items-center space-x-2">
              <Shield className={`w-4 h-4 ${getSecurityColor(securityStatus.riskScore)}`} />
              <span className="text-gray-400">Security Score:</span>
              <span className={getSecurityColor(securityStatus.riskScore)}>
                {(100 - securityStatus.riskScore).toFixed(0)}%
              </span>
            </div>
            {securityStatus.isSafe ? (
              <CheckCircle className="w-4 h-4 text-green-400" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
            )}
          </div>
        )}
      </div>

      {/* Tab Navigation */}
      <div className="flex border-b border-gray-700/50">
        {[
          { id: 'send', label: 'Send', icon: Send },
          { id: 'receive', label: 'Receive', icon: QrCode },
          { id: 'stake', label: 'Stake', icon: TrendingUp },
          { id: 'history', label: 'History', icon: ExternalLink },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-600/20 text-blue-400 border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700/30'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="p-6">
        <AnimatePresence mode="wait">
          {activeTab === 'send' && (
            <motion.div
              key="send"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <div>
                <label className="block text-gray-400 text-sm font-medium mb-2">
                  Recipient Address
                </label>
                <input
                  type="text"
                  value={sendForm.to}
                  onChange={(e) => setSendForm({ ...sendForm, to: e.target.value })}
                  placeholder="0x..."
                  className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-400 text-sm font-medium mb-2">
                  Amount (ETH)
                </label>
                <input
                  type="number"
                  value={sendForm.amount}
                  onChange={(e) => setSendForm({ ...sendForm, amount: e.target.value })}
                  placeholder="0.0"
                  step="0.0001"
                  className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                />
                <div className="mt-1 text-xs text-gray-500">
                  Available: {formatBalance(balance)} ETH
                </div>
              </div>

              {/* Gas Mode Selection */}
              {aiInsights?.gasPrices && (
                <div>
                  <label className="block text-gray-400 text-sm font-medium mb-2">
                    Gas Fee Mode
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { mode: 'eco', label: 'Eco', time: '~10 min' },
                      { mode: 'standard', label: 'Standard', time: '~3 min' },
                      { mode: 'fast', label: 'Fast', time: '~1 min' },
                      { mode: 'priority', label: 'Priority', time: '~30 sec' },
                    ].map((option) => (
                      <button
                        key={option.mode}
                        onClick={() => setSendForm({ ...sendForm, gasMode: option.mode as any })}
                        className={`p-3 rounded-lg border text-center transition-colors ${
                          sendForm.gasMode === option.mode
                            ? 'border-blue-500 bg-blue-500/10 text-blue-400'
                            : 'border-gray-600 bg-gray-700/30 text-gray-300 hover:border-gray-500'
                        }`}
                      >
                        <div className="font-medium text-sm">{option.label}</div>
                        <div className="text-xs opacity-75">{option.time}</div>
                        <div className="text-xs mt-1">
                          {aiInsights.gasPrices[option.mode]?.toFixed(4)} ETH
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                onClick={handleSend}
                disabled={loading || !sendForm.to || !sendForm.amount}
                className="w-full flex items-center justify-center space-x-2 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:opacity-50 text-white rounded-lg transition-colors"
              >
                {loading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                <span>{loading ? 'Sending...' : 'Send Transaction'}</span>
              </button>

              {/* AI Security Notice */}
              {aiFeatureManager.isFeatureEnabled('security-scanning') && (
                <div className="p-3 bg-green-400/10 border border-green-400/20 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-4 h-4 text-green-400" />
                    <span className="text-green-400 text-sm">
                      AI security scanning enabled
                    </span>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'receive' && (
            <motion.div
              key="receive"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center space-y-4"
            >
              <h3 className="text-lg font-semibold text-white">Receive Funds</h3>
              
              {address && (
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <div className="p-4 bg-white rounded-lg">
                      <QRCode
                        value={address}
                        size={200}
                        level="M"
                        includeMargin
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-400 text-sm font-medium mb-2">
                      Your Address
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={address}
                        readOnly
                        className="flex-1 px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-lg text-white"
                      />
                      <button
                        onClick={copyAddress}
                        className="p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="p-4 bg-yellow-400/10 border border-yellow-400/20 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5" />
                      <div className="text-yellow-300 text-sm">
                        <p className="font-medium">Security Notice</p>
                        <p>Only send ETH and ERC-20 tokens to this address. Sending other assets may result in permanent loss.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'stake' && (
            <motion.div
              key="stake"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-semibold text-white">Staking</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: 'Flexible', apy: '5%', lockup: 'None', min: '100 TRI' },
                  { name: 'Standard', apy: '8%', lockup: '30 days', min: '1,000 TRI' },
                  { name: 'Premium', apy: '12%', lockup: '90 days', min: '5,000 TRI' },
                  { name: 'Validator', apy: '20%', lockup: '365 days', min: '10,000 TRI' },
                ].map((pool, index) => (
                  <div
                    key={index}
                    className="p-4 bg-gray-700/30 border border-gray-600/50 rounded-lg hover:border-blue-500/50 transition-colors cursor-pointer"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <h4 className="font-semibold text-white">{pool.name}</h4>
                      <span className="text-green-400 font-bold">{pool.apy}</span>
                    </div>
                    <div className="space-y-2 text-sm text-gray-400">
                      <div className="flex justify-between">
                        <span>Lockup:</span>
                        <span>{pool.lockup}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Minimum:</span>
                        <span>{pool.min}</span>
                      </div>
                    </div>
                    <button className="w-full mt-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors">
                      Stake Now
                    </button>
                  </div>
                ))}
              </div>

              {aiFeatureManager.isFeatureEnabled('validator-selection') && (
                <div className="p-4 bg-purple-400/10 border border-purple-400/20 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Brain className="w-4 h-4 text-purple-400" />
                    <span className="text-purple-400 font-medium">AI Validator Selection</span>
                  </div>
                  <p className="text-purple-300 text-sm">
                    Let AI select the best validators based on performance, trust score, and your risk tolerance.
                  </p>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Transaction History</h3>
                <button className="text-blue-400 hover:text-blue-300 text-sm">
                  View All
                </button>
              </div>
              
              <div className="space-y-3">
                {/* Placeholder for recent transactions */}
                <div className="text-center py-8 text-gray-400">
                  <ExternalLink className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No recent transactions</p>
                  <p className="text-sm">Your transaction history will appear here</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-700/50">
        <div className="flex justify-between items-center text-xs text-gray-500">
          <span>TRISPI Wallet v1.0.0</span>
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>Connected</span>
            </span>
            <button className="text-gray-400 hover:text-white">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletInterface;
