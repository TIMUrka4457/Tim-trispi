import React, { useState, useEffect } from 'react';
import { useWallet } from '../hooks/useWallet';
import { useAI } from '../hooks/useAI';
import { ArrowUpRight, ArrowDownLeft, Clock, ExternalLink, Brain, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { walletService } from '../services/walletService';
import { formatDistanceToNow } from 'date-fns';

interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  blockNumber: number;
  gasUsed: string;
  type?: 'sent' | 'received';
  aiAnalysis?: any;
}

const TransactionHistory: React.FC = () => {
  const { provider, address } = useWallet();
  const { analyzeTransaction } = useAI();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [analyzingTx, setAnalyzingTx] = useState<string | null>(null);

  useEffect(() => {
    loadTransactions();
  }, [provider, address]);

  const loadTransactions = async () => {
    if (!provider || !address) return;

    try {
      setLoading(true);
      const txHistory = await walletService.getTransactionHistory(provider, address);
      
      const processedTxs = txHistory.map((tx) => ({
        ...tx,
        type: tx.from.toLowerCase() === address.toLowerCase() ? 'sent' as const : 'received' as const,
      }));

      setTransactions(processedTxs);
    } catch (error) {
      console.error('Failed to load transaction history:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeTransaction = async (tx: Transaction) => {
    try {
      setAnalyzingTx(tx.hash);
      const analysis = await analyzeTransaction(tx.hash);
      
      setTransactions(prev =>
        prev.map(t =>
          t.hash === tx.hash ? { ...t, aiAnalysis: analysis } : t
        )
      );
    } catch (error) {
      console.error('Failed to analyze transaction:', error);
    } finally {
      setAnalyzingTx(null);
    }
  };

  const getTransactionIcon = (type: 'sent' | 'received') => {
    return type === 'sent' ? (
      <ArrowUpRight className="w-4 h-4 text-red-400" />
    ) : (
      <ArrowDownLeft className="w-4 h-4 text-green-400" />
    );
  };

  const getTransactionColor = (type: 'sent' | 'received') => {
    return type === 'sent' ? 'text-red-400' : 'text-green-400';
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Transaction History</h1>
        </div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="bg-gray-800/50 rounded-xl p-4">
              <div className="animate-pulse space-y-3">
                <div className="h-4 bg-gray-700/50 rounded w-3/4" />
                <div className="h-3 bg-gray-700/50 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Transaction History</h1>
          <p className="text-gray-400">
            {transactions.length} transactions found
          </p>
        </div>
        <button
          onClick={loadTransactions}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          Refresh
        </button>
      </div>

      {/* Transactions List */}
      {transactions.length === 0 ? (
        <div className="text-center py-12">
          <Clock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-400 mb-2">No Transactions Found</h3>
          <p className="text-gray-500">Your transaction history will appear here once you start using the wallet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {transactions.map((tx, index) => (
            <motion.div
              key={tx.hash}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:bg-gray-800/70 transition-all cursor-pointer"
              onClick={() => setSelectedTx(tx)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${
                    tx.type === 'sent' ? 'bg-red-400/10' : 'bg-green-400/10'
                  }`}>
                    {getTransactionIcon(tx.type!)}
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-white font-medium">
                        {tx.type === 'sent' ? 'Sent' : 'Received'}
                      </span>
                      {tx.aiAnalysis && (
                        <div className="flex items-center space-x-1 text-xs text-blue-400">
                          <Brain className="w-3 h-3" />
                          <span>AI Analyzed</span>
                        </div>
                      )}
                    </div>
                    <div className="text-gray-400 text-sm">
                      {tx.type === 'sent' ? 'To' : 'From'}: {walletService.formatAddress(
                        tx.type === 'sent' ? tx.to : tx.from
                      )}
                    </div>
                    <div className="text-gray-500 text-xs">
                      {formatDistanceToNow(new Date(tx.timestamp * 1000), { addSuffix: true })}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className={`text-lg font-semibold ${getTransactionColor(tx.type!)}`}>
                    {tx.type === 'sent' ? '-' : '+'}{walletService.formatAmount(tx.value)} ETH
                  </div>
                  <div className="text-gray-400 text-sm">
                    Gas: {parseFloat(tx.gasUsed).toLocaleString()}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {!tx.aiAnalysis && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAnalyzeTransaction(tx);
                      }}
                      disabled={analyzingTx === tx.hash}
                      className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors disabled:opacity-50"
                      title="Analyze with AI"
                    >
                      {analyzingTx === tx.hash ? (
                        <div className="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Brain className="w-4 h-4" />
                      )}
                    </button>
                  )}
                  
                  <a
                    href={`https://etherscan.io/tx/${tx.hash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="p-2 text-gray-400 hover:text-white transition-colors"
                    title="View on Etherscan"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {tx.aiAnalysis && (
                <div className="mt-4 p-4 bg-blue-400/10 border border-blue-400/20 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Brain className="w-4 h-4 text-blue-400" />
                    <span className="text-blue-400 font-medium">AI Analysis</span>
                  </div>
                  <p className="text-gray-300 text-sm">{tx.aiAnalysis.explanation}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-gray-400">
                      Category: {tx.aiAnalysis.category}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      tx.aiAnalysis.risk === 'Low' ? 'bg-green-400/20 text-green-400' :
                      tx.aiAnalysis.risk === 'Medium' ? 'bg-yellow-400/20 text-yellow-400' :
                      'bg-red-400/20 text-red-400'
                    }`}>
                      Risk: {tx.aiAnalysis.risk}
                    </span>
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}

      {/* Transaction Detail Modal */}
      {selectedTx && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gray-800 border border-gray-700 rounded-xl p-6 max-w-md w-full mx-4"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Transaction Details</h3>
              <button
                onClick={() => setSelectedTx(null)}
                className="text-gray-400 hover:text-white"
              >
                ×
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-gray-400 text-sm">Hash</label>
                <div className="text-white font-mono text-sm break-all">
                  {selectedTx.hash}
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-sm">Amount</label>
                <div className={`text-lg font-semibold ${getTransactionColor(selectedTx.type!)}`}>
                  {selectedTx.type === 'sent' ? '-' : '+'}{selectedTx.value} ETH
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-sm">
                  {selectedTx.type === 'sent' ? 'To' : 'From'}
                </label>
                <div className="text-white font-mono text-sm break-all">
                  {selectedTx.type === 'sent' ? selectedTx.to : selectedTx.from}
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-sm">Block Number</label>
                <div className="text-white">{selectedTx.blockNumber.toLocaleString()}</div>
              </div>

              <div>
                <label className="text-gray-400 text-sm">Gas Used</label>
                <div className="text-white">{parseFloat(selectedTx.gasUsed).toLocaleString()}</div>
              </div>

              <div>
                <label className="text-gray-400 text-sm">Timestamp</label>
                <div className="text-white">
                  {new Date(selectedTx.timestamp * 1000).toLocaleString()}
                </div>
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <a
                href={`https://etherscan.io/tx/${selectedTx.hash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-center"
              >
                View on Etherscan
              </a>
              <button
                onClick={() => setSelectedTx(null)}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default TransactionHistory;
