import React from 'react';
import { useWallet } from '../hooks/useWallet';
import { useAI } from '../hooks/useAI';
import { TrendingUp, Shield, Zap, Activity, DollarSign, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const Dashboard: React.FC = () => {
  const { balance, address } = useWallet();
  const { features, isLoading: aiLoading } = useAI();

  const stats = [
    {
      label: 'Total Balance',
      value: `${parseFloat(balance).toFixed(4)} TRI`,
      icon: DollarSign,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
    },
    {
      label: 'AI Trust Score',
      value: '95%',
      icon: Shield,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
    },
    {
      label: 'Gas Optimization',
      value: '12% Saved',
      icon: Zap,
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
    },
    {
      label: 'Network Status',
      value: 'Optimal',
      icon: Activity,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-400/10',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400">Welcome back to your TRISPI wallet</p>
        </div>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <Eye className="w-4 h-4" />
          <span>Address: {address?.slice(0, 10)}...{address?.slice(-8)}</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">{stat.label}</p>
                  <p className="text-white text-xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* AI Insights Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gas Fee Suggestions */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">AI Gas Optimization</h3>
            <Zap className="w-5 h-5 text-yellow-400" />
          </div>
          
          {aiLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-4 bg-gray-700/50 rounded animate-pulse" />
              ))}
            </div>
          ) : features.feeSuggestion ? (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Recommended Fee:</span>
                <span className="text-green-400 font-medium">
                  {features.feeSuggestion.suggested.toFixed(6)} ETH
                </span>
              </div>
              <div className="text-sm text-gray-400">
                {features.feeSuggestion.reason}
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                <div className="bg-gray-700/30 rounded-lg p-3 text-center">
                  <div className="text-xs text-gray-400">Eco</div>
                  <div className="text-green-400 font-medium">
                    {features.feeSuggestion.modes?.eco?.toFixed(4) || 'N/A'}
                  </div>
                </div>
                <div className="bg-gray-700/30 rounded-lg p-3 text-center">
                  <div className="text-xs text-gray-400">Fast</div>
                  <div className="text-yellow-400 font-medium">
                    {features.feeSuggestion.modes?.fast?.toFixed(4) || 'N/A'}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-gray-400 text-sm">No gas optimization data available</div>
          )}
        </motion.div>

        {/* Security Status */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Security Status</h3>
            <Shield className="w-5 h-5 text-green-400" />
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Wallet Security:</span>
              <span className="text-green-400 font-medium">Excellent</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-400">AI Threat Detection:</span>
              <span className="text-green-400 font-medium">Active</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Transaction Scanning:</span>
              <span className="text-green-400 font-medium">Enabled</span>
            </div>
            
            {features.securityAlert && (
              <div className="mt-4 p-3 bg-yellow-400/10 border border-yellow-400/20 rounded-lg">
                <div className="text-yellow-400 text-sm font-medium">Security Alert</div>
                <div className="text-yellow-300 text-xs mt-1">
                  Risk Score: {(features.securityAlert.riskScore * 100).toFixed(1)}%
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Portfolio Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Portfolio AI Insights</h3>
          <TrendingUp className="w-5 h-5 text-blue-400" />
        </div>
        
        {features.portfolioAdvice ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Recommended Action:</span>
              <span className={`font-medium ${
                features.portfolioAdvice.action === 'hold' ? 'text-blue-400' :
                features.portfolioAdvice.action === 'buy' ? 'text-green-400' :
                'text-red-400'
              }`}>
                {features.portfolioAdvice.action.toUpperCase()}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Confidence:</span>
              <span className="text-white font-medium">
                {(features.portfolioAdvice.confidence * 100).toFixed(1)}%
              </span>
            </div>
            
            <div className="text-sm text-gray-400 mt-3">
              {features.portfolioAdvice.reasoning}
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <TrendingUp className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">No portfolio data available</p>
            <p className="text-gray-500 text-sm mt-1">
              Make some transactions to get AI-powered insights
            </p>
          </div>
        )}
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Send', action: 'send', color: 'blue' },
            { label: 'Receive', action: 'receive', color: 'green' },
            { label: 'Stake', action: 'stake', color: 'purple' },
            { label: 'Swap', action: 'swap', color: 'orange' },
          ].map((item) => (
            <button
              key={item.action}
              className={`p-4 rounded-lg border border-gray-600/50 hover:border-${item.color}-400/50 
                         bg-gray-700/30 hover:bg-${item.color}-400/10 transition-all duration-200
                         text-gray-300 hover:text-${item.color}-400`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
