import { ethers } from 'ethers';
import { aiService } from './services/aiService';
import { formatAddress, formatAmount } from './utils/formatting';

export class TRISPIWallet {
  private provider: ethers.Provider | null = null;
  private signer: ethers.Signer | null = null;
  private address: string | null = null;
  private network: ethers.Network | null = null;
  private isConnected: boolean = false;

  // Contract addresses and ABIs
  private readonly contracts = {
    TRISPI_TOKEN: {
      address: process.env.REACT_APP_TRISPI_TOKEN_ADDRESS || '',
      abi: [
        'function balanceOf(address owner) view returns (uint256)',
        'function transfer(address to, uint256 amount) returns (bool)',
        'function approve(address spender, uint256 amount) returns (bool)',
        'function allowance(address owner, address spender) view returns (uint256)',
        'function getAITrustScore(address user) view returns (uint256)',
        'function isAIValidated(address user) view returns (bool)',
        'function getStakingInfo(address user) view returns (uint256, uint256, uint256)',
        'function calculatePendingRewards(address user) view returns (uint256)',
        'function decimals() view returns (uint8)',
        'function symbol() view returns (string)',
        'function name() view returns (string)',
      ],
    },
    STAKING: {
      address: process.env.REACT_APP_STAKING_ADDRESS || '',
      abi: [
        'function stake(uint256 poolId, uint256 amount)',
        'function unstake(uint256 poolId, uint256 amount)',
        'function claimRewards(uint256 poolId)',
        'function claimAllRewards()',
        'function getUserStakeInfo(address user, uint256 poolId) view returns (uint256, uint256, uint256, uint256, uint256, bool)',
        'function getUserActivePools(address user) view returns (uint256[])',
        'function getPoolInfo(uint256 poolId) view returns (string, uint256, uint256, uint256, uint256, uint256, uint256, bool)',
        'function getTotalStaked() view returns (uint256)',
      ],
    },
    DAO: {
      address: process.env.REACT_APP_DAO_ADDRESS || '',
      abi: [
        'function createProposal(string title, string description, bytes callData, address target, uint256 value, uint8 proposalType) returns (uint256)',
        'function castVote(uint256 proposalId, uint8 choice, string reason)',
        'function executeProposal(uint256 proposalId)',
        'function delegate(address delegatee)',
        'function getProposal(uint256 proposalId) view returns (address, string, string, uint256, uint256, uint256, uint256, uint256, bool, bool, uint256, bool)',
        'function getVote(uint256 proposalId, address voter) view returns (uint8, uint256, uint256, string)',
        'function getMemberInfo(address member) view returns (uint256, uint256, uint256, uint256, uint256, uint256, bool, uint256)',
        'function getActiveProposals() view returns (uint256[])',
      ],
    },
    SECURITY: {
      address: process.env.REACT_APP_SECURITY_ADDRESS || '',
      abi: [
        'function analyzeTransaction(address from, address to, uint256 value, bytes callData, uint256 gasUsed) returns (bool, uint256)',
        'function getAddressRisk(address addr) view returns (uint256, uint256, uint256, bool, bool, uint256, uint256)',
        'function isAddressSafe(address addr) view returns (bool)',
        'function getSecurityStatus() view returns (uint8, bool, uint256, uint256)',
        'function currentSecurityLevel() view returns (uint8)',
      ],
    },
  };

  // Initialize wallet
  async initialize(): Promise<void> {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      this.provider = new ethers.BrowserProvider((window as any).ethereum);
    } else {
      throw new Error('MetaMask or compatible wallet not found');
    }
  }

  // Connect wallet
  async connect(): Promise<void> {
    if (!this.provider) {
      await this.initialize();
    }

    try {
      // Request account access
      const accounts = await (window as any).ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      this.signer = await this.provider!.getSigner();
      this.address = await this.signer.getAddress();
      this.network = await this.provider!.getNetwork();
      this.isConnected = true;

      // Set up event listeners
      this.setupEventListeners();

      console.log('Wallet connected:', formatAddress(this.address));
    } catch (error: any) {
      console.error('Failed to connect wallet:', error);
      throw new Error(`Connection failed: ${error.message}`);
    }
  }

  // Disconnect wallet
  disconnect(): void {
    this.provider = null;
    this.signer = null;
    this.address = null;
    this.network = null;
    this.isConnected = false;
    this.removeEventListeners();
  }

  // Get wallet info
  getWalletInfo() {
    return {
      isConnected: this.isConnected,
      address: this.address,
      network: this.network ? {
        chainId: Number(this.network.chainId),
        name: this.network.name,
      } : null,
    };
  }

  // Get balances
  async getBalances(): Promise<{
    eth: string;
    trispi: string;
    usd: number;
  }> {
    if (!this.provider || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const [ethBalance, trispiBalance] = await Promise.all([
        this.provider.getBalance(this.address),
        this.getTRISPIBalance(),
      ]);

      return {
        eth: ethers.formatEther(ethBalance),
        trispi: trispiBalance,
        usd: 0, // Would integrate with price API
      };
    } catch (error) {
      console.error('Failed to get balances:', error);
      throw error;
    }
  }

  // Get TRISPI token balance
  async getTRISPIBalance(): Promise<string> {
    if (!this.signer || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.TRISPI_TOKEN.address,
        this.contracts.TRISPI_TOKEN.abi,
        this.signer
      );

      const balance = await contract.balanceOf(this.address);
      const decimals = await contract.decimals();
      
      return ethers.formatUnits(balance, decimals);
    } catch (error) {
      console.error('Failed to get TRISPI balance:', error);
      return '0';
    }
  }

  // Send transaction with AI analysis
  async sendTransaction(to: string, amount: string, data?: string): Promise<{
    hash: string;
    aiAnalysis: any;
  }> {
    if (!this.signer || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      // AI security check before sending
      const isSecure = await aiService.checkTransactionSecurity(
        JSON.stringify({ from: this.address, to, amount, data: data || '0x' }),
        []
      );

      if (!isSecure.isSafe && isSecure.riskScore > 0.7) {
        throw new Error(`High risk transaction detected: ${isSecure.reasons.join(', ')}`);
      }

      // Estimate gas with AI optimization
      const gasEstimate = await this.provider!.estimateGas({
        from: this.address,
        to,
        value: ethers.parseEther(amount),
        data: data || '0x',
      });

      // Get AI-optimized gas price
      const aiGasPrice = await aiService.getRecommendedGasPrice();
      const gasPrice = ethers.parseUnits(aiGasPrice.standard.toString(), 'gwei');

      // Send transaction
      const tx = await this.signer.sendTransaction({
        to,
        value: ethers.parseEther(amount),
        data: data || '0x',
        gasLimit: gasEstimate,
        gasPrice,
      });

      console.log('Transaction sent:', tx.hash);

      return {
        hash: tx.hash,
        aiAnalysis: isSecure,
      };
    } catch (error: any) {
      console.error('Transaction failed:', error);
      throw new Error(`Transaction failed: ${error.message}`);
    }
  }

  // Send TRISPI tokens
  async sendTRISPI(to: string, amount: string): Promise<string> {
    if (!this.signer || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.TRISPI_TOKEN.address,
        this.contracts.TRISPI_TOKEN.abi,
        this.signer
      );

      const decimals = await contract.decimals();
      const parsedAmount = ethers.parseUnits(amount, decimals);

      // AI security check
      const isSecure = await aiService.checkTransactionSecurity(
        JSON.stringify({ 
          from: this.address, 
          to, 
          amount: parsedAmount.toString(),
          token: this.contracts.TRISPI_TOKEN.address 
        }),
        []
      );

      if (!isSecure.isSafe && isSecure.riskScore > 0.7) {
        throw new Error(`High risk token transfer detected: ${isSecure.reasons.join(', ')}`);
      }

      const tx = await contract.transfer(to, parsedAmount);
      console.log('TRISPI transfer sent:', tx.hash);
      
      return tx.hash;
    } catch (error: any) {
      console.error('TRISPI transfer failed:', error);
      throw new Error(`TRISPI transfer failed: ${error.message}`);
    }
  }

  // Staking operations
  async stake(poolId: number, amount: string): Promise<string> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }

    try {
      const stakingContract = new ethers.Contract(
        this.contracts.STAKING.address,
        this.contracts.STAKING.abi,
        this.signer
      );

      const tokenContract = new ethers.Contract(
        this.contracts.TRISPI_TOKEN.address,
        this.contracts.TRISPI_TOKEN.abi,
        this.signer
      );

      const decimals = await tokenContract.decimals();
      const parsedAmount = ethers.parseUnits(amount, decimals);

      // Check allowance and approve if necessary
      const allowance = await tokenContract.allowance(this.address, this.contracts.STAKING.address);
      if (allowance < parsedAmount) {
        const approveTx = await tokenContract.approve(this.contracts.STAKING.address, parsedAmount);
        await approveTx.wait();
      }

      // Stake tokens
      const tx = await stakingContract.stake(poolId, parsedAmount);
      console.log('Staking transaction sent:', tx.hash);
      
      return tx.hash;
    } catch (error: any) {
      console.error('Staking failed:', error);
      throw new Error(`Staking failed: ${error.message}`);
    }
  }

  async unstake(poolId: number, amount: string): Promise<string> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.STAKING.address,
        this.contracts.STAKING.abi,
        this.signer
      );

      const tokenContract = new ethers.Contract(
        this.contracts.TRISPI_TOKEN.address,
        this.contracts.TRISPI_TOKEN.abi,
        this.signer
      );

      const decimals = await tokenContract.decimals();
      const parsedAmount = ethers.parseUnits(amount, decimals);

      const tx = await contract.unstake(poolId, parsedAmount);
      console.log('Unstaking transaction sent:', tx.hash);
      
      return tx.hash;
    } catch (error: any) {
      console.error('Unstaking failed:', error);
      throw new Error(`Unstaking failed: ${error.message}`);
    }
  }

  async claimRewards(poolId?: number): Promise<string> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.STAKING.address,
        this.contracts.STAKING.abi,
        this.signer
      );

      const tx = poolId !== undefined 
        ? await contract.claimRewards(poolId)
        : await contract.claimAllRewards();
        
      console.log('Claim rewards transaction sent:', tx.hash);
      return tx.hash;
    } catch (error: any) {
      console.error('Claim rewards failed:', error);
      throw new Error(`Claim rewards failed: ${error.message}`);
    }
  }

  // Get staking info
  async getStakingInfo(): Promise<any> {
    if (!this.signer || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.STAKING.address,
        this.contracts.STAKING.abi,
        this.signer
      );

      const activePools = await contract.getUserActivePools(this.address);
      const stakingInfo = [];

      for (const poolId of activePools) {
        const [staked, rewards, lastStake, pendingRewards, aiMultiplier, isValidator] = 
          await contract.getUserStakeInfo(this.address, poolId);
        
        const [name, minimumStake, lockupPeriod, baseAPY, totalStaked, currentStakers, maxStakers, active] =
          await contract.getPoolInfo(poolId);

        stakingInfo.push({
          poolId: poolId.toString(),
          name,
          staked: ethers.formatEther(staked),
          rewards: ethers.formatEther(rewards),
          pendingRewards: ethers.formatEther(pendingRewards),
          lastStake: new Date(Number(lastStake) * 1000),
          aiMultiplier: Number(aiMultiplier),
          isValidator,
          poolInfo: {
            minimumStake: ethers.formatEther(minimumStake),
            lockupPeriod: Number(lockupPeriod),
            baseAPY: Number(baseAPY) / 100,
            totalStaked: ethers.formatEther(totalStaked),
            currentStakers: Number(currentStakers),
            maxStakers: Number(maxStakers),
            active,
          },
        });
      }

      return stakingInfo;
    } catch (error: any) {
      console.error('Failed to get staking info:', error);
      throw error;
    }
  }

  // AI-powered features
  async getAITrustScore(): Promise<number> {
    if (!this.signer || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.TRISPI_TOKEN.address,
        this.contracts.TRISPI_TOKEN.abi,
        this.signer
      );

      const score = await contract.getAITrustScore(this.address);
      return Number(score) / 10; // Convert from basis points to percentage
    } catch (error) {
      console.error('Failed to get AI trust score:', error);
      return 50; // Default score
    }
  }

  async getSecurityAnalysis(): Promise<any> {
    if (!this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const contract = new ethers.Contract(
        this.contracts.SECURITY.address,
        this.contracts.SECURITY.abi,
        this.signer
      );

      const [riskScore, lastUpdate, flagCount, isBlacklisted, isWhitelisted, totalTx, suspiciousTx] =
        await contract.getAddressRisk(this.address);

      const isSafe = await contract.isAddressSafe(this.address);
      const [securityLevel, circuitBreakerActive, totalAlerts, resolvedAlerts] =
        await contract.getSecurityStatus();

      return {
        riskScore: Number(riskScore) / 10,
        lastUpdate: new Date(Number(lastUpdate) * 1000),
        flagCount: Number(flagCount),
        isBlacklisted,
        isWhitelisted,
        totalTransactions: Number(totalTx),
        suspiciousTransactions: Number(suspiciousTx),
        isSafe,
        networkSecurity: {
          level: Number(securityLevel),
          circuitBreakerActive,
          totalAlerts: Number(totalAlerts),
          resolvedAlerts: Number(resolvedAlerts),
        },
      };
    } catch (error) {
      console.error('Failed to get security analysis:', error);
      return {
        riskScore: 0,
        isSafe: true,
        networkSecurity: { level: 0, circuitBreakerActive: false },
      };
    }
  }

  // Transaction history
  async getTransactionHistory(limit: number = 50): Promise<any[]> {
    if (!this.provider || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      // Get recent blocks to scan for transactions
      const currentBlock = await this.provider.getBlockNumber();
      const transactions = [];
      
      // Scan last 1000 blocks or until we have enough transactions
      for (let i = 0; i < 1000 && transactions.length < limit; i++) {
        const blockNumber = currentBlock - i;
        try {
          const block = await this.provider.getBlock(blockNumber, true);
          if (block && block.transactions) {
            for (const tx of block.transactions) {
              if (typeof tx === 'object' && 
                  (tx.from?.toLowerCase() === this.address.toLowerCase() || 
                   tx.to?.toLowerCase() === this.address.toLowerCase())) {
                
                const receipt = await this.provider.getTransactionReceipt(tx.hash);
                
                transactions.push({
                  hash: tx.hash,
                  from: tx.from,
                  to: tx.to,
                  value: ethers.formatEther(tx.value || 0),
                  gasUsed: receipt?.gasUsed?.toString() || '0',
                  gasPrice: tx.gasPrice ? ethers.formatUnits(tx.gasPrice, 'gwei') : '0',
                  timestamp: block.timestamp,
                  blockNumber: block.number,
                  status: receipt?.status === 1 ? 'confirmed' : 'failed',
                  type: tx.from?.toLowerCase() === this.address.toLowerCase() ? 'sent' : 'received',
                });

                if (transactions.length >= limit) break;
              }
            }
          }
        } catch (blockError) {
          // Skip blocks that can't be fetched
          continue;
        }
      }

      return transactions.sort((a, b) => b.timestamp - a.timestamp);
    } catch (error) {
      console.error('Failed to get transaction history:', error);
      return [];
    }
  }

  // Event listeners
  private setupEventListeners(): void {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      (window as any).ethereum.on('accountsChanged', this.handleAccountsChanged.bind(this));
      (window as any).ethereum.on('chainChanged', this.handleChainChanged.bind(this));
      (window as any).ethereum.on('disconnect', this.handleDisconnect.bind(this));
    }
  }

  private removeEventListeners(): void {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      (window as any).ethereum.removeListener('accountsChanged', this.handleAccountsChanged);
      (window as any).ethereum.removeListener('chainChanged', this.handleChainChanged);
      (window as any).ethereum.removeListener('disconnect', this.handleDisconnect);
    }
  }

  private handleAccountsChanged(accounts: string[]): void {
    if (accounts.length === 0) {
      this.disconnect();
    } else if (accounts[0] !== this.address) {
      // Account changed, reconnect
      this.connect().catch(console.error);
    }
  }

  private handleChainChanged(chainId: string): void {
    // Reload the page when chain changes to avoid state issues
    window.location.reload();
  }

  private handleDisconnect(): void {
    this.disconnect();
  }

  // Utility methods
  formatAddress(address: string): string {
    return formatAddress(address);
  }

  formatAmount(amount: string, decimals: number = 4): string {
    return formatAmount(amount, decimals);
  }

  isValidAddress(address: string): boolean {
    return ethers.isAddress(address);
  }

  async estimateGas(to: string, value: string, data?: string): Promise<string> {
    if (!this.provider || !this.address) {
      throw new Error('Wallet not connected');
    }

    try {
      const gasLimit = await this.provider.estimateGas({
        from: this.address,
        to,
        value: ethers.parseEther(value),
        data: data || '0x',
      });

      return gasLimit.toString();
    } catch (error) {
      console.error('Gas estimation failed:', error);
      return '21000'; // Default gas limit
    }
  }
}

// Export singleton instance
export const trispiWallet = new TRISPIWallet();
