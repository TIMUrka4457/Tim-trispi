export interface AIWalletFeature {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  config?: any;
}

export interface AIFeeSuggestionConfig {
  mode: 'eco' | 'standard' | 'fast' | 'priority';
  autoUpdate: boolean;
  updateInterval: number; // milliseconds
  riskTolerance: 'low' | 'medium' | 'high';
}

export interface AISecurityConfig {
  realTimeScanning: boolean;
  threatThreshold: number; // 0-1
  autoBlock: boolean;
  notifications: boolean;
  scanHistoricalTx: boolean;
}

export interface AIPortfolioConfig {
  trackingEnabled: boolean;
  riskAnalysis: boolean;
  rebalanceAlerts: boolean;
  yieldOptimization: boolean;
  diversificationAdvice: boolean;
}

export interface AITransactionConfig {
  explainAll: boolean;
  riskAnalysis: boolean;
  gasOptimization: boolean;
  mevProtection: boolean;
  sandwichProtection: boolean;
}

export interface AIValidatorConfig {
  autoSelection: boolean;
  performanceTracking: boolean;
  trustScoreThreshold: number;
  diversificationStrategy: 'random' | 'performance' | 'trust' | 'balanced';
}

export interface AINetworkConfig {
  optimizationEnabled: boolean;
  peerSelection: boolean;
  loadBalancing: boolean;
  anomalyDetection: boolean;
}

export class AIFeatureManager {
  private features: Map<string, AIWalletFeature> = new Map();
  private configs: Map<string, any> = new Map();

  constructor() {
    this.initializeFeatures();
  }

  private initializeFeatures(): void {
    const defaultFeatures: AIWalletFeature[] = [
      {
        id: 'fee-optimization',
        name: 'Smart Fee Optimization',
        description: 'AI-powered gas fee optimization for transactions',
        enabled: true,
        config: {
          mode: 'standard',
          autoUpdate: true,
          updateInterval: 30000,
          riskTolerance: 'medium',
        } as AIFeeSuggestionConfig,
      },
      {
        id: 'security-scanning',
        name: 'AI Security Scanner',
        description: 'Real-time threat detection and transaction analysis',
        enabled: true,
        config: {
          realTimeScanning: true,
          threatThreshold: 0.7,
          autoBlock: false,
          notifications: true,
          scanHistoricalTx: true,
        } as AISecurityConfig,
      },
      {
        id: 'portfolio-analytics',
        name: 'Portfolio Intelligence',
        description: 'AI-driven portfolio analysis and optimization',
        enabled: true,
        config: {
          trackingEnabled: true,
          riskAnalysis: true,
          rebalanceAlerts: true,
          yieldOptimization: true,
          diversificationAdvice: true,
        } as AIPortfolioConfig,
      },
      {
        id: 'transaction-explanation',
        name: 'Transaction Explainer',
        description: 'AI explanations for complex transactions',
        enabled: true,
        config: {
          explainAll: false,
          riskAnalysis: true,
          gasOptimization: true,
          mevProtection: true,
          sandwichProtection: true,
        } as AITransactionConfig,
      },
      {
        id: 'validator-selection',
        name: 'Smart Validator Selection',
        description: 'AI-optimized validator selection for staking',
        enabled: true,
        config: {
          autoSelection: false,
          performanceTracking: true,
          trustScoreThreshold: 0.8,
          diversificationStrategy: 'balanced',
        } as AIValidatorConfig,
      },
      {
        id: 'network-optimization',
        name: 'Network Optimization',
        description: 'AI-powered network performance optimization',
        enabled: true,
        config: {
          optimizationEnabled: true,
          peerSelection: true,
          loadBalancing: true,
          anomalyDetection: true,
        } as AINetworkConfig,
      },
    ];

    defaultFeatures.forEach(feature => {
      this.features.set(feature.id, feature);
      if (feature.config) {
        this.configs.set(feature.id, feature.config);
      }
    });
  }

  // Feature management
  getFeature(id: string): AIWalletFeature | undefined {
    return this.features.get(id);
  }

  getAllFeatures(): AIWalletFeature[] {
    return Array.from(this.features.values());
  }

  getEnabledFeatures(): AIWalletFeature[] {
    return Array.from(this.features.values()).filter(f => f.enabled);
  }

  enableFeature(id: string): boolean {
    const feature = this.features.get(id);
    if (feature) {
      feature.enabled = true;
      this.features.set(id, feature);
      this.saveToStorage();
      return true;
    }
    return false;
  }

  disableFeature(id: string): boolean {
    const feature = this.features.get(id);
    if (feature) {
      feature.enabled = false;
      this.features.set(id, feature);
      this.saveToStorage();
      return true;
    }
    return false;
  }

  // Configuration management
  getConfig<T>(featureId: string): T | undefined {
    return this.configs.get(featureId) as T;
  }

  updateConfig<T>(featureId: string, config: Partial<T>): boolean {
    const existingConfig = this.configs.get(featureId);
    if (existingConfig) {
      const updatedConfig = { ...existingConfig, ...config };
      this.configs.set(featureId, updatedConfig);
      this.saveToStorage();
      return true;
    }
    return false;
  }

  // Specific feature helpers
  getFeeOptimizationConfig(): AIFeeSuggestionConfig {
    return this.getConfig<AIFeeSuggestionConfig>('fee-optimization') || {
      mode: 'standard',
      autoUpdate: true,
      updateInterval: 30000,
      riskTolerance: 'medium',
    };
  }

  getSecurityConfig(): AISecurityConfig {
    return this.getConfig<AISecurityConfig>('security-scanning') || {
      realTimeScanning: true,
      threatThreshold: 0.7,
      autoBlock: false,
      notifications: true,
      scanHistoricalTx: true,
    };
  }

  getPortfolioConfig(): AIPortfolioConfig {
    return this.getConfig<AIPortfolioConfig>('portfolio-analytics') || {
      trackingEnabled: true,
      riskAnalysis: true,
      rebalanceAlerts: true,
      yieldOptimization: true,
      diversificationAdvice: true,
    };
  }

  getTransactionConfig(): AITransactionConfig {
    return this.getConfig<AITransactionConfig>('transaction-explanation') || {
      explainAll: false,
      riskAnalysis: true,
      gasOptimization: true,
      mevProtection: true,
      sandwichProtection: true,
    };
  }

  getValidatorConfig(): AIValidatorConfig {
    return this.getConfig<AIValidatorConfig>('validator-selection') || {
      autoSelection: false,
      performanceTracking: true,
      trustScoreThreshold: 0.8,
      diversificationStrategy: 'balanced',
    };
  }

  getNetworkConfig(): AINetworkConfig {
    return this.getConfig<AINetworkConfig>('network-optimization') || {
      optimizationEnabled: true,
      peerSelection: true,
      loadBalancing: true,
      anomalyDetection: true,
    };
  }

  // Feature status checks
  isFeatureEnabled(id: string): boolean {
    const feature = this.features.get(id);
    return feature ? feature.enabled : false;
  }

  shouldAutoOptimizeFees(): boolean {
    const config = this.getFeeOptimizationConfig();
    return this.isFeatureEnabled('fee-optimization') && config.autoUpdate;
  }

  shouldScanTransactions(): boolean {
    const config = this.getSecurityConfig();
    return this.isFeatureEnabled('security-scanning') && config.realTimeScanning;
  }

  shouldExplainTransaction(riskScore?: number): boolean {
    const config = this.getTransactionConfig();
    const feature = this.isFeatureEnabled('transaction-explanation');
    
    if (!feature) return false;
    if (config.explainAll) return true;
    if (riskScore && riskScore > 0.5) return true;
    
    return false;
  }

  shouldAutoSelectValidator(): boolean {
    const config = this.getValidatorConfig();
    return this.isFeatureEnabled('validator-selection') && config.autoSelection;
  }

  // AI model preferences
  getModelPreferences(): {
    gasOptimization: string;
    securityScanning: string;
    portfolioAnalysis: string;
    transactionExplanation: string;
  } {
    return {
      gasOptimization: 'random-forest',
      securityScanning: 'isolation-forest',
      portfolioAnalysis: 'ensemble',
      transactionExplanation: 'transformer',
    };
  }

  // Privacy settings
  getPrivacySettings(): {
    shareAnalytics: boolean;
    anonymizeData: boolean;
    localProcessing: boolean;
    dataRetention: number; // days
  } {
    return {
      shareAnalytics: false,
      anonymizeData: true,
      localProcessing: true,
      dataRetention: 30,
    };
  }

  updatePrivacySettings(settings: Partial<{
    shareAnalytics: boolean;
    anonymizeData: boolean;
    localProcessing: boolean;
    dataRetention: number;
  }>): void {
    const currentSettings = this.getPrivacySettings();
    const updatedSettings = { ...currentSettings, ...settings };
    
    localStorage.setItem('trispi_ai_privacy', JSON.stringify(updatedSettings));
  }

  // Notification preferences
  getNotificationSettings(): {
    securityAlerts: boolean;
    gasPriceAlerts: boolean;
    portfolioAlerts: boolean;
    stakingAlerts: boolean;
    governanceAlerts: boolean;
  } {
    const saved = localStorage.getItem('trispi_ai_notifications');
    if (saved) {
      return JSON.parse(saved);
    }
    
    return {
      securityAlerts: true,
      gasPriceAlerts: true,
      portfolioAlerts: true,
      stakingAlerts: true,
      governanceAlerts: false,
    };
  }

  updateNotificationSettings(settings: Partial<{
    securityAlerts: boolean;
    gasPriceAlerts: boolean;
    portfolioAlerts: boolean;
    stakingAlerts: boolean;
    governanceAlerts: boolean;
  }>): void {
    const currentSettings = this.getNotificationSettings();
    const updatedSettings = { ...currentSettings, ...settings };
    
    localStorage.setItem('trispi_ai_notifications', JSON.stringify(updatedSettings));
  }

  // Performance metrics
  getPerformanceMetrics(): {
    gasSavings: number;
    threatsBlocked: number;
    portfolioGains: number;
    uptime: number;
  } {
    const saved = localStorage.getItem('trispi_ai_metrics');
    if (saved) {
      return JSON.parse(saved);
    }
    
    return {
      gasSavings: 0,
      threatsBlocked: 0,
      portfolioGains: 0,
      uptime: 100,
    };
  }

  updatePerformanceMetrics(metrics: Partial<{
    gasSavings: number;
    threatsBlocked: number;
    portfolioGains: number;
    uptime: number;
  }>): void {
    const currentMetrics = this.getPerformanceMetrics();
    const updatedMetrics = { ...currentMetrics, ...metrics };
    
    localStorage.setItem('trispi_ai_metrics', JSON.stringify(updatedMetrics));
  }

  // Storage management
  private saveToStorage(): void {
    const featuresData = {
      features: Array.from(this.features.entries()),
      configs: Array.from(this.configs.entries()),
    };
    
    localStorage.setItem('trispi_ai_features', JSON.stringify(featuresData));
  }

  loadFromStorage(): void {
    try {
      const saved = localStorage.getItem('trispi_ai_features');
      if (saved) {
        const data = JSON.parse(saved);
        
        if (data.features) {
          this.features = new Map(data.features);
        }
        
        if (data.configs) {
          this.configs = new Map(data.configs);
        }
      }
    } catch (error) {
      console.warn('Failed to load AI features from storage:', error);
    }
  }

  // Reset to defaults
  resetToDefaults(): void {
    this.features.clear();
    this.configs.clear();
    this.initializeFeatures();
    this.saveToStorage();
  }

  // Export/Import configuration
  exportConfiguration(): string {
    return JSON.stringify({
      features: Array.from(this.features.entries()),
      configs: Array.from(this.configs.entries()),
      privacy: this.getPrivacySettings(),
      notifications: this.getNotificationSettings(),
      metrics: this.getPerformanceMetrics(),
    });
  }

  importConfiguration(configString: string): boolean {
    try {
      const config = JSON.parse(configString);
      
      if (config.features) {
        this.features = new Map(config.features);
      }
      
      if (config.configs) {
        this.configs = new Map(config.configs);
      }
      
      if (config.privacy) {
        this.updatePrivacySettings(config.privacy);
      }
      
      if (config.notifications) {
        this.updateNotificationSettings(config.notifications);
      }
      
      if (config.metrics) {
        this.updatePerformanceMetrics(config.metrics);
      }
      
      this.saveToStorage();
      return true;
    } catch (error) {
      console.error('Failed to import configuration:', error);
      return false;
    }
  }
}

// Export singleton instance
export const aiFeatureManager = new AIFeatureManager();
