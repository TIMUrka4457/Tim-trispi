import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { aiFeatureManager } from './features';

export interface AIClientConfig {
  baseURL: string;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
  apiKey?: string;
}

export interface AIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: number;
  requestId: string;
}

export interface GasOptimizationRequest {
  networkLoad: number;
  txCount: number;
  avgTps: number;
  blockTime: number;
  mempoolSize: number;
  priority: 'eco' | 'standard' | 'fast' | 'priority';
}

export interface SecurityAnalysisRequest {
  transactionData: string;
  senderHistory: string[];
  contractAddress?: string;
  methodSignature?: string;
  value: string;
}

export interface PortfolioAnalysisRequest {
  address: string;
  tokens: Array<{
    address: string;
    balance: string;
    symbol: string;
  }>;
  timeframe: '1d' | '7d' | '30d' | '90d';
}

export interface ValidatorAnalysisRequest {
  validators: Array<{
    address: string;
    stake: string;
    uptime: number;
    performance: number;
  }>;
  stakingAmount: string;
  strategy: 'performance' | 'safety' | 'yield' | 'balanced';
}

export class AIClient {
  private client: AxiosInstance;
  private config: AIClientConfig;
  private requestCounter: number = 0;

  constructor(config: Partial<AIClientConfig> = {}) {
    this.config = {
      baseURL: process.env.REACT_APP_AI_BACKEND_URL || 'http://localhost:8000',
      timeout: 10000,
      retryAttempts: 3,
      retryDelay: 1000,
      ...config,
    };

    this.client = axios.create({
      baseURL: this.config.baseURL,
      timeout: this.config.timeout,
      headers: {
        'Content-Type': 'application/json',
        ...(this.config.apiKey && { 'Authorization': `Bearer ${this.config.apiKey}` }),
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors(): void {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        config.headers['X-Request-ID'] = this.generateRequestId();
        config.headers['X-Client-Version'] = '1.0.0';
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;
        
        if (error.response?.status >= 500 && !originalRequest._retry) {
          originalRequest._retry = true;
          originalRequest._retryCount = (originalRequest._retryCount || 0) + 1;
          
          if (originalRequest._retryCount <= this.config.retryAttempts) {
            await this.delay(this.config.retryDelay * originalRequest._retryCount);
            return this.client(originalRequest);
          }
        }
        
        return Promise.reject(error);
      }
    );
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${++this.requestCounter}`;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async makeRequest<T>(
    method: 'GET' | 'POST' | 'PUT' | 'DELETE',
    endpoint: string,
    data?: any
  ): Promise<AIResponse<T>> {
    try {
      const response: AxiosResponse = await this.client.request({
        method: method.toLowerCase(),
        url: endpoint,
        data,
      });

      return {
        success: true,
        data: response.data,
        timestamp: Date.now(),
        requestId: response.headers['x-request-id'] || 'unknown',
      };
    } catch (error: any) {
      console.error(`AI Client Error [${endpoint}]:`, error);
      
      return {
        success: false,
        error: error.response?.data?.detail || error.message || 'Unknown error',
        timestamp: Date.now(),
        requestId: error.config?.headers?.['X-Request-ID'] || 'unknown',
      };
    }
  }

  // Health check
  async healthCheck(): Promise<boolean> {
    try {
      const response = await this.makeRequest<{ status: string }>('GET', '/health');
      return response.success && response.data?.status === 'healthy';
    } catch {
      return false;
    }
  }

  // Gas optimization
  async optimizeGasFee(request: GasOptimizationRequest): Promise<AIResponse<{
    recommendedGasFee: number;
    feeModes: Record<string, number>;
    confidence: number;
    reasoning: string;
    savings: number;
  }>> {
    if (!aiFeatureManager.isFeatureEnabled('fee-optimization')) {
      return {
        success: false,
        error: 'Gas optimization feature is disabled',
        timestamp: Date.now(),
        requestId: 'disabled',
      };
    }

    return this.makeRequest('POST', '/api/ai/gas_fee', {
      network_load: request.networkLoad,
      tx_count: request.txCount,
      avg_tps: request.avgTps,
      block_time: request.blockTime,
      mempool_size: request.mempoolSize,
      priority: request.priority,
    });
  }

  // Security analysis
  async analyzeSecurity(request: SecurityAnalysisRequest): Promise<AIResponse<{
    isSafe: boolean;
    riskScore: number;
    reasons: string[];
    confidence: number;
    recommendations: string[];
  }>> {
    if (!aiFeatureManager.isFeatureEnabled('security-scanning')) {
      return {
        success: false,
        error: 'Security scanning feature is disabled',
        timestamp: Date.now(),
        requestId: 'disabled',
      };
    }

    return this.makeRequest('POST', '/api/ai/fraud_detection', {
      transaction_data: request.transactionData,
      sender_history: request.senderHistory,
      contract_address: request.contractAddress,
      method_signature: request.methodSignature,
      value: request.value,
    });
  }

  // Portfolio analysis
  async analyzePortfolio(request: PortfolioAnalysisRequest): Promise<AIResponse<{
    riskScore: number;
    diversificationScore: number;
    recommendations: Array<{
      action: 'buy' | 'sell' | 'hold' | 'rebalance';
      token: string;
      reason: string;
      confidence: number;
    }>;
    projectedReturn: number;
    volatility: number;
  }>> {
    if (!aiFeatureManager.isFeatureEnabled('portfolio-analytics')) {
      return {
        success: false,
        error: 'Portfolio analytics feature is disabled',
        timestamp: Date.now(),
        requestId: 'disabled',
      };
    }

    return this.makeRequest('POST', '/api/ai/portfolio_analysis', {
      address: request.address,
      tokens: request.tokens,
      timeframe: request.timeframe,
    });
  }

  // Validator selection
  async selectValidators(request: ValidatorAnalysisRequest): Promise<AIResponse<{
    selectedValidators: Array<{
      address: string;
      allocationPercentage: number;
      expectedReturn: number;
      riskScore: number;
      reason: string;
    }>;
    strategy: string;
    confidence: number;
    expectedAPY: number;
  }>> {
    if (!aiFeatureManager.isFeatureEnabled('validator-selection')) {
      return {
        success: false,
        error: 'Validator selection feature is disabled',
        timestamp: Date.now(),
        requestId: 'disabled',
      };
    }

    return this.makeRequest('POST', '/api/ai/validator_selection', {
      validators: request.validators.map(v => ({
        address: v.address,
        stake_amount: v.stake,
        uptime: v.uptime,
        response_time: 100 - v.performance, // Convert performance to response time
        missed_blocks: Math.max(0, (100 - v.uptime) / 10),
        slashing_events: 0,
        reports: 0,
      })),
      staking_amount: request.stakingAmount,
      strategy: request.strategy,
    });
  }

  // Transaction explanation
  async explainTransaction(txHash: string): Promise<AIResponse<{
    explanation: string;
    simplifiedExplanation: string;
    riskLevel: 'low' | 'medium' | 'high';
    category: string;
    gasCost: number;
    tips: string[];
  }>> {
    if (!aiFeatureManager.isFeatureEnabled('transaction-explanation')) {
      return {
        success: false,
        error: 'Transaction explanation feature is disabled',
        timestamp: Date.now(),
        requestId: 'disabled',
      };
    }

    return this.makeRequest('POST', '/api/ai/tx_explanation', {
      tx_hash: txHash,
    });
  }

  // Network optimization
  async optimizeNetwork(networkData: {
    peerCount: number;
    messageRate: number;
    latency: number;
    errorRate: number;
  }): Promise<AIResponse<{
    optimalPeerCount: number;
    recommendedTTL: number;
    priority: string;
    confidence: number;
    recommendations: string[];
  }>> {
    if (!aiFeatureManager.isFeatureEnabled('network-optimization')) {
      return {
        success: false,
        error: 'Network optimization feature is disabled',
        timestamp: Date.now(),
        requestId: 'disabled',
      };
    }

    return this.makeRequest('POST', '/api/ai/network_optimization', networkData);
  }

  // Block validation
  async validateBlock(blockData: {
    index: number;
    transactionCount: number;
    validator: string;
    gasFee: number;
    timestamp: number;
  }): Promise<AIResponse<{
    isValid: boolean;
    confidence: number;
    reasons: string[];
    recommendation: string;
  }>> {
    return this.makeRequest('POST', '/api/ai/block_validation', blockData);
  }

  // Anomaly detection
  async detectAnomalies(networkData: any): Promise<AIResponse<{
    isAnomalous: boolean;
    anomalyScore: number;
    detectedAnomalies: string[];
    severity: 'low' | 'medium' | 'high' | 'critical';
  }>> {
    return this.makeRequest('POST', '/api/ai/network_anomaly', networkData);
  }

  // Real-time gas prices
  async getGasPrices(): Promise<AIResponse<{
    slow: number;
    standard: number;
    fast: number;
    instant: number;
    prediction: {
      nextHour: number;
      next24Hours: number;
      trend: 'up' | 'down' | 'stable';
    };
  }>> {
    return this.makeRequest('GET', '/api/ai/gas_prices');
  }

  // Market insights
  async getMarketInsights(tokens: string[]): Promise<AIResponse<{
    insights: Array<{
      token: string;
      sentiment: 'bullish' | 'bearish' | 'neutral';
      confidence: number;
      priceTarget?: number;
      timeframe?: string;
      factors: string[];
    }>;
  }>> {
    return this.makeRequest('POST', '/api/ai/market_insights', { tokens });
  }

  // AI model metrics
  async getModelMetrics(): Promise<AIResponse<{
    models: Array<{
      name: string;
      accuracy: number;
      latency: number;
      uptime: number;
      lastUpdate: string;
    }>;
    overall: {
      accuracy: number;
      uptime: number;
      totalPredictions: number;
    };
  }>> {
    return this.makeRequest('GET', '/api/ai/metrics');
  }

  // Configuration methods
  updateConfig(newConfig: Partial<AIClientConfig>): void {
    this.config = { ...this.config, ...newConfig };
    
    // Update axios defaults
    this.client.defaults.baseURL = this.config.baseURL;
    this.client.defaults.timeout = this.config.timeout;
    
    if (this.config.apiKey) {
      this.client.defaults.headers.common['Authorization'] = `Bearer ${this.config.apiKey}`;
    }
  }

  getConfig(): AIClientConfig {
    return { ...this.config };
  }

  // Cache management
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  private getCacheKey(method: string, endpoint: string, data?: any): string {
    return `${method}:${endpoint}:${JSON.stringify(data)}`;
  }

  private getCachedResponse<T>(key: string): T | null {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < cached.ttl) {
      return cached.data;
    }
    this.cache.delete(key);
    return null;
  }

  private setCachedResponse(key: string, data: any, ttl: number = 60000): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl,
    });
  }

  clearCache(): void {
    this.cache.clear();
  }

  // Statistics
  getStatistics(): {
    totalRequests: number;
    successRate: number;
    averageResponseTime: number;
    cacheHitRate: number;
  } {
    // This would be implemented with proper tracking
    return {
      totalRequests: this.requestCounter,
      successRate: 0.95,
      averageResponseTime: 250,
      cacheHitRate: 0.3,
    };
  }
}

// Export singleton instance
export const aiClient = new AIClient();
