import { ethers } from 'ethers';

class WalletService {
  private readonly TRISPI_TOKEN_ADDRESS = '0x...'; // Replace with actual contract address
  private readonly TRISPI_ABI = [
    // Basic ERC20 ABI
    'function balanceOf(address owner) view returns (uint256)',
    'function transfer(address to, uint256 amount) returns (bool)',
    'function approve(address spender, uint256 amount) returns (bool)',
    'function allowance(address owner, address spender) view returns (uint256)',
  ];

  async getBalance(provider: ethers.Provider, address: string): Promise<string> {
    try {
      // Get ETH balance
      const ethBalance = await provider.getBalance(address);
      
      // For now, return ETH balance. In production, you'd also get TRISPI token balance
      return ethers.formatEther(ethBalance);
    } catch (error) {
      console.error('Error getting balance:', error);
      return '0';
    }
  }

  async getTRISPIBalance(provider: ethers.Provider, address: string): Promise<string> {
    try {
      const contract = new ethers.Contract(this.TRISPI_TOKEN_ADDRESS, this.TRISPI_ABI, provider);
      const balance = await contract.balanceOf(address);
      return ethers.formatEther(balance);
    } catch (error) {
      console.error('Error getting TRISPI balance:', error);
      return '0';
    }
  }

  async sendTransaction(
    signer: ethers.Signer,
    to: string,
    amount: string
  ): Promise<ethers.TransactionResponse> {
    try {
      const tx = await signer.sendTransaction({
        to,
        value: ethers.parseEther(amount),
        gasLimit: 21000,
      });

      return tx;
    } catch (error) {
      console.error('Error sending transaction:', error);
      throw error;
    }
  }

  async sendTRISPITransaction(
    signer: ethers.Signer,
    to: string,
    amount: string
  ): Promise<ethers.TransactionResponse> {
    try {
      const contract = new ethers.Contract(this.TRISPI_TOKEN_ADDRESS, this.TRISPI_ABI, signer);
      const tx = await contract.transfer(to, ethers.parseEther(amount));
      return tx;
    } catch (error) {
      console.error('Error sending TRISPI transaction:', error);
      throw error;
    }
  }

  async getTransactionHistory(
    provider: ethers.Provider,
    address: string,
    fromBlock: number = 0
  ): Promise<any[]> {
    try {
      // Get transaction history from provider
      // This is simplified - in production you'd use a service like Etherscan API
      const currentBlock = await provider.getBlockNumber();
      const transactions = [];

      // Scan recent blocks for transactions involving this address
      const scanBlocks = Math.min(1000, currentBlock - fromBlock);
      for (let i = 0; i < scanBlocks; i++) {
        const blockNumber = currentBlock - i;
        try {
          const block = await provider.getBlock(blockNumber, true);
          if (block && block.transactions) {
            for (const tx of block.transactions) {
              if (typeof tx === 'object' && (tx.from === address || tx.to === address)) {
                transactions.push({
                  hash: tx.hash,
                  from: tx.from,
                  to: tx.to,
                  value: ethers.formatEther(tx.value || 0),
                  timestamp: block.timestamp,
                  blockNumber: block.number,
                  gasUsed: tx.gasLimit?.toString() || '0',
                });
              }
            }
          }
        } catch (blockError) {
          // Skip blocks that can't be fetched
          continue;
        }
      }

      return transactions.sort((a, b) => b.timestamp - a.timestamp);
    } catch (error) {
      console.error('Error getting transaction history:', error);
      return [];
    }
  }

  async estimateGasFee(
    provider: ethers.Provider,
    to: string,
    value: string,
    data?: string
  ): Promise<{ gasLimit: string; gasPrice: string; totalFee: string }> {
    try {
      const gasLimit = await provider.estimateGas({
        to,
        value: ethers.parseEther(value),
        data: data || '0x',
      });

      const feeData = await provider.getFeeData();
      const gasPrice = feeData.gasPrice || ethers.parseUnits('20', 'gwei');
      
      const totalFee = gasLimit * gasPrice;

      return {
        gasLimit: gasLimit.toString(),
        gasPrice: ethers.formatUnits(gasPrice, 'gwei'),
        totalFee: ethers.formatEther(totalFee),
      };
    } catch (error) {
      console.error('Error estimating gas fee:', error);
      return {
        gasLimit: '21000',
        gasPrice: '20',
        totalFee: '0.00042',
      };
    }
  }

  async getNetworkStats(provider: ethers.Provider): Promise<any> {
    try {
      const [blockNumber, feeData, block] = await Promise.all([
        provider.getBlockNumber(),
        provider.getFeeData(),
        provider.getBlock('latest'),
      ]);

      return {
        blockNumber,
        gasPrice: feeData.gasPrice ? ethers.formatUnits(feeData.gasPrice, 'gwei') : '0',
        blockTime: block?.timestamp || Date.now() / 1000,
        difficulty: '0', // ETH 2.0 doesn't have difficulty
      };
    } catch (error) {
      console.error('Error getting network stats:', error);
      return {
        blockNumber: 0,
        gasPrice: '0',
        blockTime: Date.now() / 1000,
        difficulty: '0',
      };
    }
  }

  formatAddress(address: string): string {
    if (!address) return '';
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  }

  formatAmount(amount: string, decimals: number = 4): string {
    const num = parseFloat(amount);
    return num.toFixed(decimals);
  }

  validateAddress(address: string): boolean {
    return ethers.isAddress(address);
  }

  validateAmount(amount: string): boolean {
    try {
      const parsed = ethers.parseEther(amount);
      return parsed > 0;
    } catch {
      return false;
    }
  }
}

export const walletService = new WalletService();
