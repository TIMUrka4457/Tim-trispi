import axios from 'axios';
import { AIFeeSuggestion, AISecurityCheck, AIPortfolioAdvice, AITransactionExplanation } from '../types/ai';

class AIService {
  private readonly baseURL: string;
  private readonly timeout: number = 5000;

  constructor() {
    this.baseURL = process.env.AI_BACKEND_URL || 'http://localhost:8000/api/ai';
  }

  private async request<T>(endpoint: string, data?: any): Promise<T> {
    try {
      const response = await axios.post(`${this.baseURL}${endpoint}`, data, {
        timeout: this.timeout,
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error: any) {
      console.error(`AI Service error for ${endpoint}:`, error);
      if (error.response?.status === 404) {
        throw new Error('AI service endpoint not found');
      } else if (error.code === 'ECONNREFUSED') {
        throw new Error('AI service is not available');
      } else if (error.code === 'ECONNABORTED') {
        throw new Error('AI service request timeout');
      }
      throw new Error(error.response?.data?.detail || 'AI service error');
    }
  }

  async checkConnection(): Promise<boolean> {
    try {
      await axios.get(`${this.baseURL.replace('/api/ai', '')}/health`, {
        timeout: 2000,
      });
      return true;
    } catch {
      return false;
    }
  }

  async getFeeSuggestion(params: {
    mode?: string;
    networkLoad: number;
    txCount: number;
    avgTps: number;
    blockTime: number;
    mempoolSize: number;
  }): Promise<AIFeeSuggestion> {
    const response = await this.request<{
      recommended_gas_fee: number;
      fee_modes: Record<string, number>;
      confidence: number;
      reasoning: string;
    }>('/gas_fee', {
      network_load: params.networkLoad,
      tx_count: params.txCount,
      avg_tps: params.avgTps,
      block_time: params.blockTime,
      mempool_size: params.mempoolSize,
    });

    return {
      mode: params.mode || 'standard',
      suggested: response.recommended_gas_fee,
      reason: response.reasoning,
      confidence: response.confidence,
      modes: response.fee_modes,
    };
  }

  async checkTransactionSecurity(
    transactionData: string,
    senderHistory: string[]
  ): Promise<AISecurityCheck> {
    const response = await this.request<{
      is_safe: boolean;
      risk_score: number;
      reasons: string[];
      confidence: number;
    }>('/fraud_detection', {
      transaction_data: transactionData,
      sender_history: senderHistory,
      network_patterns: {},
    });

    return {
      isSafe: response.is_safe,
      riskScore: response.risk_score,
      reasons: response.reasons,
      confidence: response.confidence,
    };
  }

  async getPortfolioAdvice(token: string): Promise<AIPortfolioAdvice> {
    // For now, return mock data since the endpoint would need token portfolio data
    // In production, this would call a real AI endpoint with portfolio analysis
    return {
      token,
      action: 'hold',
      confidence: 0.85,
      reasoning: 'AI analysis suggests holding based on current market conditions and token fundamentals',
      priceTarget: null,
      timeframe: '30d',
    };
  }

  async explainTransaction(txHash: string): Promise<AITransactionExplanation> {
    const response = await this.request<{
      tx_hash: string;
      explanation: string;
      risk: string;
    }>('/tx_explanation', {
      tx_hash: txHash,
    });

    return {
      txHash: response.tx_hash,
      explanation: response.explanation,
      risk: response.risk,
      category: this.categorizeTransaction(response.explanation),
      simplifiedExplanation: this.simplifyExplanation(response.explanation),
    };
  }

  async getValidatorScore(validatorData: {
    uptime: number;
    responseTime: number;
    missedBlocks: number;
    slashingEvents: number;
    reports: number;
  }): Promise<any> {
    const response = await this.request('/validator_score', validatorData);
    return response;
  }

  async getNetworkOptimization(networkData: {
    peerCount: number;
    messageRate: number;
    latency: number;
    networkStats: any;
  }): Promise<any> {
    const response = await this.request('/network_optimization', networkData);
    return response;
  }

  async detectNetworkAnomaly(networkData: any): Promise<{
    isAnomalous: boolean;
    anomalyScore: number;
    detectedAnomalies: string[];
    severity: string;
  }> {
    const response = await this.request('/network_anomaly', networkData);
    return response;
  }

  async validateBlock(blockData: {
    index: number;
    transactionCount: number;
    validator: string;
    gasFee: number;
    timestamp: number;
  }): Promise<{
    isValid: boolean;
    confidence: number;
    reasons: string[];
    recommendation: string;
  }> {
    const response = await this.request('/block_validation', blockData);
    return response;
  }

  private categorizeTransaction(explanation: string): string {
    const categories = {
      transfer: ['transfer', 'send', 'payment'],
      swap: ['swap', 'exchange', 'trade'],
      stake: ['stake', 'deposit', 'lock'],
      unstake: ['unstake', 'withdraw', 'claim'],
      approve: ['approve', 'allowance'],
      contract: ['contract', 'function', 'call'],
    };

    const lowerExplanation = explanation.toLowerCase();
    
    for (const [category, keywords] of Object.entries(categories)) {
      if (keywords.some(keyword => lowerExplanation.includes(keyword))) {
        return category;
      }
    }
    
    return 'unknown';
  }

  private simplifyExplanation(explanation: string): string {
    // Simplify technical explanations for better user understanding
    const simplifications: Record<string, string> = {
      'contract interaction': 'interacting with a smart contract',
      'function call': 'calling a function',
      'token transfer': 'sending tokens',
      'allowance': 'giving permission to spend tokens',
      'stake': 'locking tokens to earn rewards',
      'unstake': 'unlocking staked tokens',
    };

    let simplified = explanation;
    for (const [technical, simple] of Object.entries(simplifications)) {
      simplified = simplified.replace(new RegExp(technical, 'gi'), simple);
    }

    return simplified;
  }

  // Utility methods for AI-powered features
  async getRecommendedGasPrice(): Promise<{
    slow: number;
    standard: number;
    fast: number;
    instant: number;
  }> {
    try {
      const suggestion = await this.getFeeSuggestion({
        networkLoad: 0.5,
        txCount: 100,
        avgTps: 1000,
        blockTime: 10,
        mempoolSize: 50,
      });

      const basePrice = suggestion.suggested;
      return {
        slow: basePrice * 0.8,
        standard: basePrice,
        fast: basePrice * 1.5,
        instant: basePrice * 2.0,
      };
    } catch {
      // Fallback prices
      return {
        slow: 15,
        standard: 20,
        fast: 30,
        instant: 50,
      };
    }
  }

  async analyzeWalletRisk(address: string): Promise<{
    riskScore: number;
    riskLevel: 'low' | 'medium' | 'high';
    factors: string[];
  }> {
    // This would integrate with the security module
    // For now, return a safe default
    return {
      riskScore: 0.1,
      riskLevel: 'low',
      factors: [],
    };
  }
}

export const aiService = new AIService();
