import { useContext } from 'react';
import { useAI as useAIContext } from '../contexts/AIContext';

export const useAI = () => {
  return useAIContext();
};
