export interface AIFeatures {
  feeSuggestion: AIFeeSuggestion | null;
  securityAlert: AISecurityCheck | null;
  portfolioAdvice: AIPortfolioAdvice | null;
  transactionExplanation: AITransactionExplanation | null;
  fraudDetection: AIFraudDetection | null;
}

export interface AIFeeSuggestion {
  mode: string;
  suggested: number;
  reason: string;
  confidence: number;
  modes?: {
    eco?: number;
    standard?: number;
    fast?: number;
    priority?: number;
  };
}

export interface AISecurityCheck {
  isSafe: boolean;
  riskScore: number;
  reasons: string[];
  confidence: number;
}

export interface AIPortfolioAdvice {
  token: string;
  action: 'hold' | 'buy' | 'sell' | 'swap' | 'farm';
  confidence: number;
  reasoning: string;
  priceTarget?: number;
  timeframe: string;
}

export interface AITransactionExplanation {
  txHash: string;
  explanation: string;
  risk: string;
  category: string;
  simplifiedExplanation: string;
}

export interface AIFraudDetection {
  isLegitimate: boolean;
  riskFactors: string[];
  recommendations: string[];
  confidence: number;
}

export interface AIState {
  isConnected: boolean;
  features: AIFeatures;
  lastUpdate: Date | null;
  isLoading: boolean;
  error: string | null;
}

export type AIAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string }
  | { type: 'SET_CONNECTED'; payload: boolean }
  | { type: 'UPDATE_FEATURES'; payload: Partial<AIFeatures> }
  | { type: 'UPDATE_FEE_SUGGESTION'; payload: AIFeeSuggestion }
  | { type: 'UPDATE_SECURITY_ALERT'; payload: AISecurityCheck }
  | { type: 'UPDATE_PORTFOLIO_ADVICE'; payload: AIPortfolioAdvice }
  | { type: 'UPDATE_TRANSACTION_EXPLANATION'; payload: AITransactionExplanation };

export interface AIGasPrediction {
  slow: number;
  standard: number;
  fast: number;
  instant: number;
  prediction: {
    nextHour: number;
    next24Hours: number;
    trend: 'up' | 'down' | 'stable';
  };
}

export interface AIWalletRisk {
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  factors: string[];
  recommendations: string[];
}

export interface AIMarketInsight {
  token: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  factors: string[];
  priceTarget?: {
    target: number;
    timeframe: string;
    probability: number;
  };
}

export interface AINetworkHealth {
  congestion: number;
  stability: number;
  security: number;
  overall: 'healthy' | 'congested' | 'unstable' | 'critical';
  recommendations: string[];
}
