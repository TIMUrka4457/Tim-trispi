import { ethers } from 'ethers';

export interface WalletState {
  isConnected: boolean;
  address: string | null;
  balance: string;
  network: {
    chainId: number;
    name: string;
  } | null;
  provider: ethers.Provider | null;
  signer: ethers.Signer | null;
  isLoading: boolean;
  error: string | null;
}

export type WalletAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string }
  | {
      type: 'SET_CONNECTED';
      payload: {
        address: string;
        provider: ethers.Provider;
        signer: ethers.Signer;
        network: { chainId: number; name: string };
      };
    }
  | { type: 'SET_DISCONNECTED' }
  | { type: 'SET_BALANCE'; payload: string }
  | { type: 'SET_NETWORK'; payload: { chainId: number; name: string } };

export interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  blockNumber: number;
  gasUsed: string;
  gasPrice: string;
  status: 'pending' | 'confirmed' | 'failed';
}

export interface TokenBalance {
  address: string;
  symbol: string;
  name: string;
  balance: string;
  decimals: number;
  price?: number;
  valueUSD?: number;
}

export interface NetworkConfig {
  chainId: number;
  name: string;
  rpcUrl: string;
  blockExplorerUrl: string;
  nativeCurrency: {
    name: string;
    symbol: string;
    decimals: number;
  };
}

export interface WalletConnectConfig {
  projectId: string;
  chains: number[];
  metadata: {
    name: string;
    description: string;
    url: string;
    icons: string[];
  };
}
