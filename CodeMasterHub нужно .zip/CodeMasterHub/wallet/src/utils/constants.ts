export const SUPPORTED_NETWORKS = {
  1: {
    name: 'Ethereum Mainnet',
    rpcUrl: 'https://mainnet.infura.io/v3/',
    blockExplorerUrl: 'https://etherscan.io',
    nativeCurrency: {
      name: 'Ether',
      symbol: 'ETH',
      decimals: 18,
    },
  },
  5: {
    name: 'Goerli Testnet',
    rpcUrl: 'https://goerli.infura.io/v3/',
    blockExplorerUrl: 'https://goerli.etherscan.io',
    nativeCurrency: {
      name: 'Goerli Ether',
      symbol: 'GoerliETH',
      decimals: 18,
    },
  },
  137: {
    name: 'Polygon Mainnet',
    rpcUrl: 'https://polygon-rpc.com',
    blockExplorerUrl: 'https://polygonscan.com',
    nativeCurrency: {
      name: 'MATIC',
      symbol: 'MATIC',
      decimals: 18,
    },
  },
  56: {
    name: 'Binance Smart Chain',
    rpcUrl: 'https://bsc-dataseed.binance.org',
    blockExplorerUrl: 'https://bscscan.com',
    nativeCurrency: {
      name: 'BNB',
      symbol: 'BNB',
      decimals: 18,
    },
  },
};

export const TRISPI_CONTRACTS = {
  TOKEN: {
    1: '0x...', // Mainnet address
    5: '0x...', // Goerli address
  },
  STAKING: {
    1: '0x...',
    5: '0x...',
  },
  DAO: {
    1: '0x...',
    5: '0x...',
  },
  SECURITY: {
    1: '0x...',
    5: '0x...',
  },
};

export const AI_CONFIG = {
  BASE_URL: process.env.REACT_APP_AI_BACKEND_URL || 'http://localhost:8000',
  ENDPOINTS: {
    GAS_FEE: '/api/ai/gas_fee',
    FRAUD_DETECTION: '/api/ai/fraud_detection',
    VALIDATOR_SCORE: '/api/ai/validator_score',
    SHARDING: '/api/ai/sharding',
    BLOCK_VALIDATION: '/api/ai/block_validation',
    NETWORK_OPTIMIZATION: '/api/ai/network_optimization',
    HEALTH: '/health',
  },
  TIMEOUT: 5000,
  RETRY_ATTEMPTS: 3,
};

export const WALLET_CONFIG = {
  AUTO_CONNECT: true,
  THEME: 'dark',
  DEFAULT_SLIPPAGE: 0.5, // 0.5%
  DEFAULT_DEADLINE: 20, // 20 minutes
  GAS_PRICE_SPEEDS: {
    slow: 1,
    standard: 1.25,
    fast: 1.5,
    instant: 2,
  },
};

export const SECURITY_LEVELS = {
  LOW: {
    threshold: 30,
    color: 'red',
    label: 'High Risk',
  },
  MEDIUM: {
    threshold: 70,
    color: 'yellow',
    label: 'Medium Risk',
  },
  HIGH: {
    threshold: 90,
    color: 'green',
    label: 'Low Risk',
  },
  EXCELLENT: {
    threshold: 95,
    color: 'emerald',
    label: 'Excellent',
  },
};

export const TRANSACTION_TYPES = {
  TRANSFER: 'transfer',
  APPROVE: 'approve',
  SWAP: 'swap',
  STAKE: 'stake',
  UNSTAKE: 'unstake',
  GOVERNANCE: 'governance',
  CONTRACT_INTERACTION: 'contract_interaction',
};

export const GAS_LIMITS = {
  TRANSFER: 21000,
  TOKEN_TRANSFER: 65000,
  TOKEN_APPROVE: 60000,
  SWAP: 200000,
  STAKE: 150000,
  UNSTAKE: 120000,
  GOVERNANCE_VOTE: 100000,
};

export const POLLING_INTERVALS = {
  BALANCE: 30000, // 30 seconds
  TRANSACTIONS: 60000, // 1 minute
  GAS_PRICE: 15000, // 15 seconds
  AI_INSIGHTS: 300000, // 5 minutes
  SECURITY_SCAN: 600000, // 10 minutes
};

export const CACHE_KEYS = {
  WALLET_ADDRESS: 'trispi_wallet_address',
  TRANSACTION_HISTORY: 'trispi_tx_history',
  GAS_PRICES: 'trispi_gas_prices',
  AI_INSIGHTS: 'trispi_ai_insights',
  SECURITY_DATA: 'trispi_security_data',
};

export const STORAGE_KEYS = {
  WALLET_PREFERENCES: 'trispi_wallet_preferences',
  NETWORK_SETTINGS: 'trispi_network_settings',
  AI_SETTINGS: 'trispi_ai_settings',
  THEME: 'trispi_theme',
};

export const API_ENDPOINTS = {
  COINGECKO: 'https://api.coingecko.com/api/v3',
  ETHERSCAN: 'https://api.etherscan.io/api',
  MORALIS: 'https://deep-index.moralis.io/api/v2',
  ALCHEMY: 'https://eth-mainnet.alchemyapi.io/v2',
};

export const ERROR_MESSAGES = {
  WALLET_NOT_CONNECTED: 'Please connect your wallet first',
  NETWORK_NOT_SUPPORTED: 'This network is not supported',
  INSUFFICIENT_BALANCE: 'Insufficient balance for this transaction',
  TRANSACTION_FAILED: 'Transaction failed. Please try again.',
  AI_SERVICE_UNAVAILABLE: 'AI service is currently unavailable',
  INVALID_ADDRESS: 'Please enter a valid wallet address',
  INVALID_AMOUNT: 'Please enter a valid amount',
  USER_REJECTED: 'Transaction was rejected by user',
};

export const SUCCESS_MESSAGES = {
  WALLET_CONNECTED: 'Wallet connected successfully!',
  TRANSACTION_SENT: 'Transaction sent successfully!',
  TRANSACTION_CONFIRMED: 'Transaction confirmed!',
  SETTINGS_SAVED: 'Settings saved successfully!',
  AI_SCAN_COMPLETE: 'AI security scan completed',
};

export const FEATURE_FLAGS = {
  AI_INSIGHTS: true,
  SECURITY_MODULE: true,
  STAKING: true,
  GOVERNANCE: true,
  PORTFOLIO_TRACKING: true,
  TRANSACTION_SIMULATION: true,
  DARK_MODE: true,
};

export const ANIMATION_DURATIONS = {
  FAST: 0.15,
  NORMAL: 0.25,
  SLOW: 0.4,
  PAGE_TRANSITION: 0.3,
};

export const BREAKPOINTS = {
  SM: 640,
  MD: 768,
  LG: 1024,
  XL: 1280,
  '2XL': 1536,
};

export const COLORS = {
  PRIMARY: '#3B82F6',
  SECONDARY: '#8B5CF6',
  SUCCESS: '#10B981',
  WARNING: '#F59E0B',
  ERROR: '#EF4444',
  INFO: '#06B6D4',
};
