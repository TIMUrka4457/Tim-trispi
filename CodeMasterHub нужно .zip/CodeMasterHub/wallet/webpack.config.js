const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { DefinePlugin } = require('webpack');

module.exports = (env, argv) => {
  const isDevelopment = argv.mode === 'development';
  
  return {
    entry: './src/index.ts',
    mode: isDevelopment ? 'development' : 'production',
    
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          use: {
            loader: 'ts-loader',
            options: {
              transpileOnly: isDevelopment,
            },
          },
          exclude: /node_modules/,
        },
        {
          test: /\.css$/i,
          use: [
            'style-loader',
            'css-loader',
            {
              loader: 'postcss-loader',
              options: {
                postcssOptions: {
                  plugins: [
                    require('tailwindcss'),
                    require('autoprefixer'),
                  ],
                },
              },
            },
          ],
        },
        {
          test: /\.(png|jpe?g|gif|svg|ico)$/i,
          type: 'asset/resource',
          generator: {
            filename: 'images/[name].[hash][ext]',
          },
        },
        {
          test: /\.(woff|woff2|eot|ttf|otf)$/i,
          type: 'asset/resource',
          generator: {
            filename: 'fonts/[name].[hash][ext]',
          },
        },
      ],
    },
    
    resolve: {
      extensions: ['.tsx', '.ts', '.js', '.jsx'],
      alias: {
        '@': path.resolve(__dirname, 'src'),
        '@components': path.resolve(__dirname, 'src/components'),
        '@contexts': path.resolve(__dirname, 'src/contexts'),
        '@hooks': path.resolve(__dirname, 'src/hooks'),
        '@services': path.resolve(__dirname, 'src/services'),
        '@utils': path.resolve(__dirname, 'src/utils'),
        '@types': path.resolve(__dirname, 'src/types'),
        '@ai': path.resolve(__dirname, 'src/ai'),
      },
      fallback: {
        crypto: require.resolve('crypto-browserify'),
        stream: require.resolve('stream-browserify'),
        buffer: require.resolve('buffer'),
        util: require.resolve('util'),
        assert: require.resolve('assert'),
        url: require.resolve('url'),
        os: require.resolve('os-browserify/browser'),
        https: require.resolve('https-browserify'),
        http: require.resolve('stream-http'),
        path: require.resolve('path-browserify'),
        fs: false,
        net: false,
        tls: false,
      },
    },
    
    output: {
      filename: isDevelopment ? '[name].js' : '[name].[contenthash].js',
      path: path.resolve(__dirname, 'dist'),
      clean: true,
      publicPath: '/',
    },
    
    plugins: [
      new HtmlWebpackPlugin({
        template: './public/index.html',
        favicon: './public/favicon.ico',
        inject: true,
        minify: !isDevelopment && {
          removeComments: true,
          collapseWhitespace: true,
          removeRedundantAttributes: true,
          useShortDoctype: true,
          removeEmptyAttributes: true,
          removeStyleLinkTypeAttributes: true,
          keepClosingSlash: true,
          minifyJS: true,
          minifyCSS: true,
          minifyURLs: true,
        },
      }),
      
      new DefinePlugin({
        'process.env.NODE_ENV': JSON.stringify(argv.mode),
        'process.env.REACT_APP_AI_BACKEND_URL': JSON.stringify(
          process.env.REACT_APP_AI_BACKEND_URL || 'http://localhost:8000'
        ),
        'process.env.REACT_APP_TRISPI_TOKEN_ADDRESS': JSON.stringify(
          process.env.REACT_APP_TRISPI_TOKEN_ADDRESS || ''
        ),
        'process.env.REACT_APP_STAKING_ADDRESS': JSON.stringify(
          process.env.REACT_APP_STAKING_ADDRESS || ''
        ),
        'process.env.REACT_APP_DAO_ADDRESS': JSON.stringify(
          process.env.REACT_APP_DAO_ADDRESS || ''
        ),
        'process.env.REACT_APP_SECURITY_ADDRESS': JSON.stringify(
          process.env.REACT_APP_SECURITY_ADDRESS || ''
        ),
        'process.env.REACT_APP_NETWORK_ID': JSON.stringify(
          process.env.REACT_APP_NETWORK_ID || '1'
        ),
        'process.env.REACT_APP_INFURA_ID': JSON.stringify(
          process.env.REACT_APP_INFURA_ID || ''
        ),
        'process.env.REACT_APP_WALLETCONNECT_PROJECT_ID': JSON.stringify(
          process.env.REACT_APP_WALLETCONNECT_PROJECT_ID || ''
        ),
      }),
    ],
    
    devServer: {
      static: {
        directory: path.join(__dirname, 'public'),
      },
      historyApiFallback: true,
      host: '0.0.0.0',
      port: 5000,
      hot: true,
      compress: true,
      open: false,
      allowedHosts: 'all',
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
        'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization',
      },
      proxy: {
        '/api': {
          target: process.env.REACT_APP_AI_BACKEND_URL || 'http://localhost:8000',
          changeOrigin: true,
          secure: false,
        },
      },
    },
    
    optimization: {
      splitChunks: {
        chunks: 'all',
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            chunks: 'all',
          },
          common: {
            minChunks: 2,
            chunks: 'all',
            name: 'common',
            enforce: true,
          },
        },
      },
      runtimeChunk: 'single',
    },
    
    devtool: isDevelopment ? 'eval-source-map' : 'source-map',
    
    stats: {
      errorDetails: true,
    },
    
    performance: {
      hints: isDevelopment ? false : 'warning',
      maxEntrypointSize: 512000,
      maxAssetSize: 512000,
    },
  };
};
