-- TRISPI Blockchain Database Schema

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Blocks table
CREATE TABLE blocks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    index BIGINT NOT NULL UNIQUE,
    timestamp TIMESTAMPTZ NOT NULL,
    prev_hash TEXT NOT NULL,
    hash TEXT NOT NULL UNIQUE,
    validator TEXT NOT NULL,
    gas_fee DOUBLE PRECISION NOT NULL DEFAULT 0,
    transaction_count INTEGER NOT NULL DEFAULT 0,
    merkle_root TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create index on block index for fast lookups
CREATE INDEX idx_blocks_index ON blocks(index DESC);
CREATE INDEX idx_blocks_hash ON blocks(hash);
CREATE INDEX idx_blocks_timestamp ON blocks(timestamp DESC);
CREATE INDEX idx_blocks_validator ON blocks(validator);

-- Transactions table
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    block_id UUID REFERENCES blocks(id) ON DELETE CASCADE,
    from_address TEXT NOT NULL,
    to_address TEXT NOT NULL,
    amount BIGINT NOT NULL CHECK (amount >= 0),
    gas_fee DOUBLE PRECISION NOT NULL CHECK (gas_fee >= 0),
    data TEXT,
    signature TEXT NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes on transactions
CREATE INDEX idx_transactions_block_id ON transactions(block_id);
CREATE INDEX idx_transactions_from_address ON transactions(from_address);
CREATE INDEX idx_transactions_to_address ON transactions(to_address);
CREATE INDEX idx_transactions_timestamp ON transactions(timestamp DESC);
CREATE INDEX idx_transactions_amount ON transactions(amount);

-- Account balances table
CREATE TABLE account_balances (
    address TEXT PRIMARY KEY,
    balance BIGINT NOT NULL CHECK (balance >= 0) DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create index on balance for queries
CREATE INDEX idx_account_balances_balance ON account_balances(balance DESC);

-- Validators table
CREATE TABLE validators (
    address TEXT PRIMARY KEY,
    stake BIGINT NOT NULL CHECK (stake >= 0),
    uptime DOUBLE PRECISION NOT NULL DEFAULT 1.0 CHECK (uptime >= 0 AND uptime <= 1),
    last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    missed_blocks INTEGER NOT NULL DEFAULT 0 CHECK (missed_blocks >= 0),
    slashing_events INTEGER NOT NULL DEFAULT 0 CHECK (slashing_events >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active BOOLEAN NOT NULL DEFAULT true
);

-- Create indexes on validators
CREATE INDEX idx_validators_stake ON validators(stake DESC);
CREATE INDEX idx_validators_is_active ON validators(is_active);
CREATE INDEX idx_validators_uptime ON validators(uptime DESC);
CREATE INDEX idx_validators_last_seen ON validators(last_seen DESC);

-- Validator performance history
CREATE TABLE validator_performance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    validator_address TEXT NOT NULL REFERENCES validators(address) ON DELETE CASCADE,
    blocks_produced INTEGER NOT NULL DEFAULT 0,
    blocks_missed INTEGER NOT NULL DEFAULT 0,
    rewards_earned BIGINT NOT NULL DEFAULT 0,
    slashing_amount BIGINT NOT NULL DEFAULT 0,
    period_start TIMESTAMPTZ NOT NULL,
    period_end TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes on performance
CREATE INDEX idx_validator_performance_address ON validator_performance(validator_address);
CREATE INDEX idx_validator_performance_period ON validator_performance(period_start, period_end);

-- Network statistics table
CREATE TABLE network_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    total_blocks BIGINT NOT NULL DEFAULT 0,
    total_transactions BIGINT NOT NULL DEFAULT 0,
    active_validators INTEGER NOT NULL DEFAULT 0,
    network_load DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (network_load >= 0 AND network_load <= 1),
    avg_tps DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (avg_tps >= 0),
    mempool_size INTEGER NOT NULL DEFAULT 0 CHECK (mempool_size >= 0),
    avg_gas_fee DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (avg_gas_fee >= 0)
);

-- Create index on network stats timestamp
CREATE INDEX idx_network_stats_timestamp ON network_stats(timestamp DESC);

-- Pending transactions table (mempool)
CREATE TABLE pending_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    from_address TEXT NOT NULL,
    to_address TEXT NOT NULL,
    amount BIGINT NOT NULL CHECK (amount >= 0),
    gas_fee DOUBLE PRECISION NOT NULL CHECK (gas_fee >= 0),
    data TEXT,
    signature TEXT NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes on pending transactions
CREATE INDEX idx_pending_transactions_from_address ON pending_transactions(from_address);
CREATE INDEX idx_pending_transactions_gas_fee ON pending_transactions(gas_fee DESC);
CREATE INDEX idx_pending_transactions_expires_at ON pending_transactions(expires_at);
CREATE INDEX idx_pending_transactions_timestamp ON pending_transactions(timestamp);

-- Peers table for P2P network
CREATE TABLE peers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    node_id TEXT NOT NULL UNIQUE,
    address TEXT NOT NULL,
    port INTEGER NOT NULL CHECK (port > 0 AND port <= 65535),
    version TEXT NOT NULL,
    last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active BOOLEAN NOT NULL DEFAULT true,
    connection_count INTEGER NOT NULL DEFAULT 0,
    reputation_score DOUBLE PRECISION NOT NULL DEFAULT 0.5 CHECK (reputation_score >= 0 AND reputation_score <= 1),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes on peers
CREATE INDEX idx_peers_node_id ON peers(node_id);
CREATE INDEX idx_peers_is_active ON peers(is_active);
CREATE INDEX idx_peers_last_seen ON peers(last_seen DESC);
CREATE INDEX idx_peers_reputation_score ON peers(reputation_score DESC);

-- AI model predictions and analytics
CREATE TABLE ai_predictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    prediction_type TEXT NOT NULL, -- 'gas_fee', 'fraud_detection', 'validator_score', 'sharding'
    input_data JSONB NOT NULL,
    prediction_result JSONB NOT NULL,
    confidence_score DOUBLE PRECISION CHECK (confidence_score >= 0 AND confidence_score <= 1),
    model_version TEXT NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    accuracy_feedback DOUBLE PRECISION CHECK (accuracy_feedback >= 0 AND accuracy_feedback <= 1)
);

-- Create indexes on AI predictions
CREATE INDEX idx_ai_predictions_type ON ai_predictions(prediction_type);
CREATE INDEX idx_ai_predictions_timestamp ON ai_predictions(timestamp DESC);
CREATE INDEX idx_ai_predictions_confidence ON ai_predictions(confidence_score DESC);

-- Smart contract deployments
CREATE TABLE smart_contracts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    address TEXT NOT NULL UNIQUE,
    deployer_address TEXT NOT NULL,
    contract_name TEXT NOT NULL,
    contract_code TEXT NOT NULL,
    abi JSONB NOT NULL,
    constructor_args JSONB,
    deployment_block_id UUID REFERENCES blocks(id) ON DELETE SET NULL,
    deployment_transaction_id UUID REFERENCES transactions(id) ON DELETE SET NULL,
    is_verified BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes on smart contracts
CREATE INDEX idx_smart_contracts_address ON smart_contracts(address);
CREATE INDEX idx_smart_contracts_deployer ON smart_contracts(deployer_address);
CREATE INDEX idx_smart_contracts_name ON smart_contracts(contract_name);
CREATE INDEX idx_smart_contracts_verified ON smart_contracts(is_verified);

-- Functions to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for account_balances
CREATE TRIGGER update_account_balances_updated_at 
    BEFORE UPDATE ON account_balances 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Function to clean up expired pending transactions
CREATE OR REPLACE FUNCTION cleanup_expired_transactions()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM pending_transactions 
    WHERE expires_at < NOW();
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ language 'plpgsql';

-- Function to calculate network statistics
CREATE OR REPLACE FUNCTION calculate_network_stats()
RETURNS VOID AS $$
DECLARE
    total_blocks_count BIGINT;
    total_tx_count BIGINT;
    active_val_count INTEGER;
    mempool_count INTEGER;
    current_load DOUBLE PRECISION;
    current_tps DOUBLE PRECISION;
    current_gas_fee DOUBLE PRECISION;
BEGIN
    -- Get current statistics
    SELECT COUNT(*) INTO total_blocks_count FROM blocks;
    SELECT COUNT(*) INTO total_tx_count FROM transactions;
    SELECT COUNT(*) INTO active_val_count FROM validators WHERE is_active = true;
    SELECT COUNT(*) INTO mempool_count FROM pending_transactions;
    
    -- Calculate network load (simplified)
    current_load := LEAST(mempool_count::DOUBLE PRECISION / 1000.0, 1.0);
    
    -- Calculate TPS (transactions per second over last hour)
    SELECT COUNT(*)::DOUBLE PRECISION / 3600.0 INTO current_tps
    FROM transactions 
    WHERE timestamp > NOW() - INTERVAL '1 hour';
    
    -- Calculate average gas fee over last 100 transactions
    SELECT COALESCE(AVG(gas_fee), 0) INTO current_gas_fee
    FROM transactions 
    ORDER BY timestamp DESC 
    LIMIT 100;
    
    -- Insert new stats record
    INSERT INTO network_stats (
        total_blocks, 
        total_transactions, 
        active_validators, 
        network_load, 
        avg_tps, 
        mempool_size, 
        avg_gas_fee
    ) VALUES (
        total_blocks_count,
        total_tx_count,
        active_val_count,
        current_load,
        current_tps,
        mempool_count,
        current_gas_fee
    );
END;
$$ language 'plpgsql';

-- Create initial genesis block entry
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM blocks WHERE index = 0) THEN
        INSERT INTO blocks (index, timestamp, prev_hash, hash, validator, gas_fee, transaction_count, merkle_root)
        VALUES (
            0,
            NOW(),
            repeat('0', 64),
            'genesis_block_hash_placeholder',
            'genesis',
            0,
            0,
            repeat('0', 64)
        );
    END IF;
END $$;

-- Create views for common queries
CREATE VIEW v_latest_blocks AS
SELECT 
    b.*,
    COUNT(t.id) as actual_transaction_count
FROM blocks b
LEFT JOIN transactions t ON b.id = t.block_id
GROUP BY b.id, b.index, b.timestamp, b.prev_hash, b.hash, b.validator, b.gas_fee, b.transaction_count, b.merkle_root, b.created_at
ORDER BY b.index DESC
LIMIT 100;

CREATE VIEW v_validator_stats AS
SELECT 
    v.*,
    COALESCE(vp.total_blocks_produced, 0) as total_blocks_produced,
    COALESCE(vp.total_rewards, 0) as total_rewards
FROM validators v
LEFT JOIN (
    SELECT 
        validator_address,
        SUM(blocks_produced) as total_blocks_produced,
        SUM(rewards_earned) as total_rewards
    FROM validator_performance
    GROUP BY validator_address
) vp ON v.address = vp.validator_address
WHERE v.is_active = true
ORDER BY v.stake DESC;

-- Grant permissions (adjust as needed for your setup)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO trispi_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO trispi_user;
-- GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO trispi_user;
