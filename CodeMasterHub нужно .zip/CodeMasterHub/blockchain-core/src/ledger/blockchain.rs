use anyhow::{Result, anyhow};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::{info, warn};

use crate::ledger::block::Block;
use crate::ledger::transaction::Transaction;
use crate::crypto::hash::Hash;

#[derive(Clone)]
pub struct Blockchain {
    blocks: Arc<RwLock<Vec<Block>>>,
    validators: Arc<RwLock<HashMap<String, u64>>>,
    pending_transactions: Arc<RwLock<Vec<Transaction>>>,
    balances: Arc<RwLock<HashMap<String, u64>>>,
}

impl Blockchain {
    pub async fn new() -> Result<Self> {
        let genesis_block = Block::genesis().await?;
        let mut blocks = Vec::new();
        blocks.push(genesis_block);

        let mut validators = HashMap::new();
        validators.insert("validator_001".to_string(), 1000);
        validators.insert("validator_002".to_string(), 800);
        validators.insert("validator_003".to_string(), 600);

        let mut balances = HashMap::new();
        balances.insert("genesis".to_string(), 1000000);

        Ok(Self {
            blocks: Arc::new(RwLock::new(blocks)),
            validators: Arc::new(RwLock::new(validators)),
            pending_transactions: Arc::new(RwLock::new(Vec::new())),
            balances: Arc::new(RwLock::new(balances)),
        })
    }

    pub async fn add_block(&self, mut block: Block) -> Result<()> {
        let mut blocks = self.blocks.write().await;
        let latest = blocks.last().ok_or(anyhow!("No blocks in chain"))?;

        // Validate block
        if block.previous_hash != latest.hash {
            return Err(anyhow!("Invalid previous hash"));
        }

        if block.index != latest.index + 1 {
            return Err(anyhow!("Invalid block index"));
        }

        // Process transactions
        let mut balances = self.balances.write().await;
        let mut pending = self.pending_transactions.write().await;

        for tx in &block.transactions {
            if let Err(e) = self.process_transaction(tx, &mut balances).await {
                warn!("Transaction processing failed: {}", e);
                continue;
            }
            
            // Remove from pending
            pending.retain(|pending_tx| pending_tx.hash != tx.hash);
        }

        // Recalculate block hash after processing
        block.calculate_hash().await?;
        
        blocks.push(block.clone());
        info!("Block #{} added to blockchain", block.index);
        
        Ok(())
    }

    async fn process_transaction(&self, tx: &Transaction, balances: &mut HashMap<String, u64>) -> Result<()> {
        let from_balance = balances.get(&tx.from).copied().unwrap_or(0);
        
        if from_balance < tx.amount {
            return Err(anyhow!("Insufficient balance"));
        }

        // Update balances
        *balances.entry(tx.from.clone()).or_insert(0) -= tx.amount;
        *balances.entry(tx.to.clone()).or_insert(0) += tx.amount;

        Ok(())
    }

    pub async fn get_latest_block(&self) -> Result<Block> {
        let blocks = self.blocks.read().await;
        blocks.last()
            .cloned()
            .ok_or(anyhow!("No blocks in chain"))
    }

    pub async fn get_blocks_from_height(&self, height: u64) -> Result<Vec<Block>> {
        let blocks = self.blocks.read().await;
        Ok(blocks.iter()
            .skip(height as usize)
            .cloned()
            .collect())
    }

    pub async fn get_validators(&self) -> Result<Vec<(String, u64)>> {
        let validators = self.validators.read().await;
        Ok(validators.iter()
            .map(|(k, v)| (k.clone(), *v))
            .collect())
    }

    pub async fn add_validator(&self, address: String, stake: u64) -> Result<()> {
        let mut validators = self.validators.write().await;
        validators.insert(address, stake);
        Ok(())
    }

    pub async fn get_pending_transactions(&self) -> Result<Vec<Transaction>> {
        let pending = self.pending_transactions.read().await;
        Ok(pending.clone())
    }

    pub async fn get_pending_transaction_count(&self) -> Result<usize> {
        let pending = self.pending_transactions.read().await;
        Ok(pending.len())
    }

    pub async fn add_pending_transaction(&self, transaction: Transaction) -> Result<()> {
        let mut pending = self.pending_transactions.write().await;
        pending.push(transaction);
        Ok(())
    }

    pub async fn get_balance(&self, address: &str) -> Result<u64> {
        let balances = self.balances.read().await;
        Ok(balances.get(address).copied().unwrap_or(0))
    }

    pub async fn get_chain_length(&self) -> Result<usize> {
        let blocks = self.blocks.read().await;
        Ok(blocks.len())
    }
}
