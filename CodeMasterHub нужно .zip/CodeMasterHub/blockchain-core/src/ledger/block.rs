use anyhow::Result;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::ledger::transaction::Transaction;
use crate::crypto::hash::{Hash, calculate_hash};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Block {
    pub index: u64,
    pub timestamp: DateTime<Utc>,
    pub previous_hash: Hash,
    pub hash: Hash,
    pub transactions: Vec<Transaction>,
    pub validator: String,
    pub gas_fee: f64,
    pub nonce: u64,
}

impl Block {
    pub async fn new(
        index: u64,
        previous_hash: Hash,
        transactions: Vec<Transaction>,
        validator: String,
        gas_fee: f64,
    ) -> Result<Self> {
        let timestamp = Utc::now();
        let nonce = 0;
        
        let mut block = Self {
            index,
            timestamp,
            previous_hash,
            hash: Hash::default(),
            transactions,
            validator,
            gas_fee,
            nonce,
        };

        block.calculate_hash().await?;
        Ok(block)
    }

    pub async fn genesis() -> Result<Self> {
        let timestamp = Utc::now();
        let genesis_tx = Transaction::genesis().await?;
        
        let mut block = Self {
            index: 0,
            timestamp,
            previous_hash: Hash::from_str("0"),
            hash: Hash::default(),
            transactions: vec![genesis_tx],
            validator: "genesis".to_string(),
            gas_fee: 0.0,
            nonce: 0,
        };

        block.calculate_hash().await?;
        Ok(block)
    }

    pub async fn calculate_hash(&mut self) -> Result<()> {
        let data = format!(
            "{}{}{}{}{}{}{}",
            self.index,
            self.timestamp.timestamp(),
            self.previous_hash.to_string(),
            self.transactions_hash().await?,
            self.validator,
            self.gas_fee,
            self.nonce
        );
        
        self.hash = calculate_hash(&data)?;
        Ok(())
    }

    async fn transactions_hash(&self) -> Result<Hash> {
        let mut tx_data = String::new();
        for tx in &self.transactions {
            tx_data.push_str(&tx.hash.to_string());
        }
        calculate_hash(&tx_data)
    }

    pub fn is_valid(&self, previous_block: &Block) -> bool {
        // Validate block structure
        if self.index != previous_block.index + 1 {
            return false;
        }
        
        if self.previous_hash != previous_block.hash {
            return false;
        }

        // Additional validations can be added here
        true
    }
}
