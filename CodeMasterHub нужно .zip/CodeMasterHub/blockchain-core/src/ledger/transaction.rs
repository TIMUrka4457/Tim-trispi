use anyhow::Result;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::crypto::hash::{Hash, calculate_hash};
use crate::crypto::signature::Signature;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transaction {
    pub hash: Hash,
    pub from: String,
    pub to: String,
    pub amount: u64,
    pub timestamp: DateTime<Utc>,
    pub signature: Option<Signature>,
    pub nonce: u64,
    pub gas_fee: f64,
}

impl Transaction {
    pub async fn new(
        from: String,
        to: String,
        amount: u64,
        gas_fee: f64,
        nonce: u64,
    ) -> Result<Self> {
        let timestamp = Utc::now();
        
        let mut transaction = Self {
            hash: Hash::default(),
            from,
            to,
            amount,
            timestamp,
            signature: None,
            nonce,
            gas_fee,
        };

        transaction.calculate_hash().await?;
        Ok(transaction)
    }

    pub async fn genesis() -> Result<Self> {
        Self::new(
            "genesis".to_string(),
            "genesis".to_string(),
            1000000,
            0.0,
            0,
        ).await
    }

    pub async fn calculate_hash(&mut self) -> Result<()> {
        let data = format!(
            "{}{}{}{}{}{}",
            self.from,
            self.to,
            self.amount,
            self.timestamp.timestamp(),
            self.nonce,
            self.gas_fee
        );
        
        self.hash = calculate_hash(&data)?;
        Ok(())
    }

    pub fn sign(&mut self, signature: Signature) {
        self.signature = Some(signature);
    }

    pub fn is_valid(&self) -> bool {
        // Basic validation
        if self.amount == 0 && self.from != "genesis" {
            return false;
        }

        if self.from == self.to && self.from != "genesis" {
            return false;
        }

        // Signature validation would go here
        true
    }
}
