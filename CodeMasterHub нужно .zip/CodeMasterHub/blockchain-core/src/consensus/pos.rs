use anyhow::Result;
use rand::{seq::SliceRandom, thread_rng};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Mutex;
use tokio::time::sleep;
use tracing::{info, warn};

use crate::ledger::blockchain::Blockchain;
use crate::ledger::block::Block;
use crate::ledger::transaction::Transaction;
use crate::ai_client::AIClient;

pub struct ProofOfStake {
    blockchain: Arc<Mutex<Blockchain>>,
    ai_client: AIClient,
    validator_address: String,
}

impl ProofOfStake {
    pub async fn new(blockchain: Arc<Mutex<Blockchain>>, ai_client: AIClient) -> Result<Self> {
        Ok(Self {
            blockchain,
            ai_client,
            validator_address: "validator_001".to_string(), // In production, this would be from config
        })
    }

    pub async fn run(&self) -> Result<()> {
        info!("🔄 Starting Proof of Stake consensus mechanism");

        loop {
            sleep(Duration::from_secs(10)).await;

            // Get current blockchain state
            let blockchain = self.blockchain.lock().await;
            let latest_block = blockchain.get_latest_block().await?;
            let validators = blockchain.get_validators().await?;
            
            if validators.is_empty() {
                warn!("⚠️ No validators found, skipping consensus round");
                drop(blockchain);
                continue;
            }

            // AI-powered validator selection
            let selected_validator = self.ai_select_validator(&validators).await?;
            info!("🧠 AI selected validator: {}", selected_validator);

            // Check if we are the selected validator
            if selected_validator == self.validator_address {
                info!("🎯 We are selected as validator, creating new block");
                
                // Get pending transactions
                let pending_txs = blockchain.get_pending_transactions().await?;
                drop(blockchain);

                // AI-powered gas fee optimization
                let optimized_gas_fee = self.optimize_gas_fee(&pending_txs).await?;
                
                // Create new block
                let new_block = self.create_block(latest_block, pending_txs, optimized_gas_fee).await?;
                
                // Add block to blockchain
                let mut blockchain = self.blockchain.lock().await;
                match blockchain.add_block(new_block.clone()).await {
                    Ok(_) => {
                        info!("✅ New block #{} created and added", new_block.index);
                        // In a real implementation, this would be broadcast to the network
                    }
                    Err(e) => {
                        warn!("❌ Failed to add new block: {}", e);
                    }
                }
            } else {
                drop(blockchain);
                info!("⏳ Waiting for validator {} to create block", selected_validator);
            }
        }
    }

    async fn ai_select_validator(&self, validators: &[(String, u64)]) -> Result<String> {
        // Use AI to intelligently select validator based on various factors
        match self.ai_client.select_validator(validators).await {
            Ok(validator) => Ok(validator),
            Err(e) => {
                warn!("AI validator selection failed: {}, using fallback", e);
                self.fallback_validator_selection(validators)
            }
        }
    }

    fn fallback_validator_selection(&self, validators: &[(String, u64)]) -> Result<String> {
        // Weighted random selection based on stake
        let total_stake: u64 = validators.iter().map(|(_, stake)| *stake).sum();
        if total_stake == 0 {
            return Ok(validators[0].0.clone());
        }

        let mut weighted_validators = Vec::new();
        for (address, stake) in validators {
            let weight = (*stake as f64 / total_stake as f64 * 100.0) as usize;
            for _ in 0..weight.max(1) {
                weighted_validators.push(address.clone());
            }
        }

        let mut rng = thread_rng();
        Ok(weighted_validators
            .choose(&mut rng)
            .unwrap_or(&validators[0].0)
            .clone())
    }

    async fn optimize_gas_fee(&self, transactions: &[Transaction]) -> Result<f64> {
        // AI-powered gas fee optimization
        let network_stats = self.get_network_statistics().await?;
        
        match self.ai_client.optimize_gas_fee(&network_stats, transactions).await {
            Ok(optimized_fee) => {
                info!("🧠 AI optimized gas fee: {}", optimized_fee);
                Ok(optimized_fee)
            }
            Err(e) => {
                warn!("AI gas optimization failed: {}, using default", e);
                Ok(1.0) // Default gas fee
            }
        }
    }

    async fn get_network_statistics(&self) -> Result<serde_json::Value> {
        let blockchain = self.blockchain.lock().await;
        let latest_block = blockchain.get_latest_block().await?;
        let pending_count = blockchain.get_pending_transaction_count().await?;
        
        Ok(serde_json::json!({
            "network_load": 0.7,
            "tx_count": pending_count,
            "avg_tps": 1200.0,
            "block_time": 10,
            "mempool_size": pending_count,
            "latest_block_height": latest_block.index
        }))
    }

    async fn create_block(
        &self,
        previous_block: Block,
        transactions: Vec<Transaction>,
        gas_fee: f64,
    ) -> Result<Block> {
        let block = Block::new(
            previous_block.index + 1,
            previous_block.hash.clone(),
            transactions,
            self.validator_address.clone(),
            gas_fee,
        ).await?;

        info!("🔨 Created new block: #{} with {} transactions", block.index, block.transactions.len());
        Ok(block)
    }
}
