pub mod pos;

pub use pos::ProofOfStake;
