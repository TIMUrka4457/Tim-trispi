use anyhow::{Result, anyhow};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{Mutex, RwLock};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tracing::{info, warn, error};
use uuid::Uuid;

use crate::ledger::blockchain::Blockchain;
use crate::ledger::block::Block;
use crate::ai_client::AIClient;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Message {
    Ping { id: String },
    Pong { id: String },
    NewBlock { block: Block },
    RequestBlocks { from_height: u64 },
    BlockResponse { blocks: Vec<Block> },
    PeerDiscovery { peers: Vec<String> },
    Transaction { data: String },
}

#[derive(Clone)]
pub struct P2PNode {
    id: String,
    blockchain: Arc<Mutex<Blockchain>>,
    peers: Arc<RwLock<HashMap<String, SocketAddr>>>,
    ai_client: AIClient,
}

impl P2PNode {
    pub async fn new(blockchain: Arc<Mutex<Blockchain>>, ai_client: AIClient) -> Result<Self> {
        Ok(Self {
            id: Uuid::new_v4().to_string(),
            blockchain,
            peers: Arc::new(RwLock::new(HashMap::new())),
            ai_client,
        })
    }

    pub async fn start(&self, address: &str) -> Result<()> {
        let listener = TcpListener::bind(address).await?;
        info!("🌐 P2P Node {} listening on {}", self.id, address);

        loop {
            match listener.accept().await {
                Ok((stream, addr)) => {
                    let node = self.clone();
                    tokio::spawn(async move {
                        if let Err(e) = node.handle_connection(stream, addr).await {
                            warn!("Connection error with {}: {}", addr, e);
                        }
                    });
                }
                Err(e) => {
                    error!("Failed to accept connection: {}", e);
                }
            }
        }
    }

    async fn handle_connection(&self, mut stream: TcpStream, addr: SocketAddr) -> Result<()> {
        let mut reader = BufReader::new(&mut stream);
        let mut line = String::new();

        loop {
            line.clear();
            match reader.read_line(&mut line).await {
                Ok(0) => break, // Connection closed
                Ok(_) => {
                    if let Ok(message) = serde_json::from_str::<Message>(&line.trim()) {
                        self.handle_message(message, &mut stream, addr).await?;
                    }
                }
                Err(e) => {
                    warn!("Read error from {}: {}", addr, e);
                    break;
                }
            }
        }

        // Remove peer on disconnect
        let mut peers = self.peers.write().await;
        peers.retain(|_, peer_addr| *peer_addr != addr);
        
        Ok(())
    }

    async fn handle_message(&self, message: Message, stream: &mut TcpStream, addr: SocketAddr) -> Result<()> {
        match message {
            Message::Ping { id } => {
                let response = Message::Pong { id };
                self.send_message(stream, &response).await?;
                
                // Add peer
                let mut peers = self.peers.write().await;
                peers.insert(id, addr);
            }
            Message::Pong { id: _ } => {
                info!("Received pong from {}", addr);
            }
            Message::NewBlock { block } => {
                info!("📦 Received new block #{} from {}", block.index, addr);
                
                // AI-powered block validation
                let validation_result = self.ai_client.validate_block(&block).await;
                match validation_result {
                    Ok(is_valid) if is_valid => {
                        let mut blockchain = self.blockchain.lock().await;
                        if let Err(e) = blockchain.add_block(block.clone()).await {
                            warn!("Failed to add block: {}", e);
                        } else {
                            info!("✅ Block #{} added successfully", block.index);
                            // Broadcast to other peers
                            self.broadcast_block(block).await?;
                        }
                    }
                    Ok(_) => {
                        warn!("❌ AI validation failed for block #{}", block.index);
                    }
                    Err(e) => {
                        warn!("AI validation error: {}", e);
                    }
                }
            }
            Message::RequestBlocks { from_height } => {
                let blockchain = self.blockchain.lock().await;
                let blocks = blockchain.get_blocks_from_height(from_height).await?;
                let response = Message::BlockResponse { blocks };
                self.send_message(stream, &response).await?;
            }
            Message::BlockResponse { blocks } => {
                info!("Received {} blocks from {}", blocks.len(), addr);
                let mut blockchain = self.blockchain.lock().await;
                for block in blocks {
                    if let Err(e) = blockchain.add_block(block).await {
                        warn!("Failed to sync block: {}", e);
                    }
                }
            }
            Message::PeerDiscovery { peers: peer_list } => {
                info!("Discovered {} peers from {}", peer_list.len(), addr);
                // Connect to new peers
                for peer_addr in peer_list {
                    if let Ok(socket_addr) = peer_addr.parse::<SocketAddr>() {
                        let node = self.clone();
                        tokio::spawn(async move {
                            if let Err(e) = node.connect_to_peer(socket_addr).await {
                                warn!("Failed to connect to peer {}: {}", socket_addr, e);
                            }
                        });
                    }
                }
            }
            Message::Transaction { data } => {
                info!("Received transaction from {}: {}", addr, data);
                // Process transaction through AI fraud detection
                if let Ok(is_safe) = self.ai_client.check_transaction_fraud(&data).await {
                    if is_safe {
                        // Add to mempool or process
                        info!("✅ Transaction validated and added to mempool");
                    } else {
                        warn!("⚠️ Suspicious transaction detected and rejected");
                    }
                }
            }
        }
        Ok(())
    }

    async fn send_message(&self, stream: &mut TcpStream, message: &Message) -> Result<()> {
        let json = serde_json::to_string(message)?;
        stream.write_all(format!("{}\n", json).as_bytes()).await?;
        stream.flush().await?;
        Ok(())
    }

    async fn broadcast_block(&self, block: Block) -> Result<()> {
        let message = Message::NewBlock { block };
        let peers = self.peers.read().await;
        
        for (_, addr) in peers.iter() {
            let node = self.clone();
            let msg = message.clone();
            let peer_addr = *addr;
            
            tokio::spawn(async move {
                if let Ok(mut stream) = TcpStream::connect(peer_addr).await {
                    let _ = node.send_message(&mut stream, &msg).await;
                }
            });
        }
        
        Ok(())
    }

    async fn connect_to_peer(&self, addr: SocketAddr) -> Result<()> {
        let mut stream = TcpStream::connect(addr).await?;
        let ping = Message::Ping { id: self.id.clone() };
        self.send_message(&mut stream, &ping).await?;
        info!("Connected to peer: {}", addr);
        Ok(())
    }
}
