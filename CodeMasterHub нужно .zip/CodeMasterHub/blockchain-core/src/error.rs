//! Error types for TRISPI blockchain

use thiserror::Error;

pub type Result<T> = std::result::Result<T, TrispiError>;

#[derive(Error, Debug)]
pub enum TrispiError {
    #[error("Database error: {0}")]
    DatabaseError(#[from] sqlx::Error),

    #[error("Serialization error: {0}")]
    SerializationError(#[from] serde_json::Error),

    #[error("Network error: {0}")]
    NetworkError(String),

    #[error("Invalid block: {0}")]
    InvalidBlock(String),

    #[error("Invalid transaction: {0}")]
    InvalidTransaction(String),

    #[error("Invalid signature: {0}")]
    InvalidSignature(String),

    #[error("Invalid key: {0}")]
    InvalidKey(String),

    #[error("Insufficient balance: {0}")]
    InsufficientBalance(String),

    #[error("Block not found: {0}")]
    BlockNotFound(String),

    #[error("Transaction not found: {0}")]
    TransactionNotFound(String),

    #[error("Validator not found: {0}")]
    ValidatorNotFound(String),

    #[error("Invalid stake amount: {0}")]
    InvalidStake(String),

    #[error("Maximum validators reached")]
    MaxValidatorsReached,

    #[error("Consensus error: {0}")]
    ConsensusError(String),

    #[error("Cryptographic error: {0}")]
    CryptoError(String),

    #[error("Configuration error: {0}")]
    ConfigError(String),

    #[error("AI service error: {0}")]
    AIServiceError(String),

    #[error("Suspicious transaction detected: {0}")]
    SuspiciousTransaction(String),

    #[error("Insufficient gas fee")]
    InsufficientGasFee,

    #[error("Transaction timeout")]
    TransactionTimeout,

    #[error("Peer connection failed: {0}")]
    PeerConnectionFailed(String),

    #[error("Message parsing error: {0}")]
    MessageParsingError(String),

    #[error("Handshake failed: {0}")]
    HandshakeFailed(String),

    #[error("Protocol version mismatch: expected {expected}, got {actual}")]
    ProtocolVersionMismatch { expected: String, actual: String },

    #[error("Rate limit exceeded")]
    RateLimitExceeded,

    #[error("Internal error: {0}")]
    InternalError(String),

    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),

    #[error("Reqwest error: {0}")]
    ReqwestError(#[from] reqwest::Error),

    #[error("Anyhow error: {0}")]
    AnyhowError(#[from] anyhow::Error),

    #[error("Address parse error: {0}")]
    AddrParseError(#[from] std::net::AddrParseError),

    #[error("Uuid parse error: {0}")]
    UuidError(#[from] uuid::Error),

    #[error("Bincode error: {0}")]
    BincodeError(#[from] bincode::Error),
}

impl TrispiError {
    pub fn network(msg: impl Into<String>) -> Self {
        Self::NetworkError(msg.into())
    }

    pub fn invalid_block(msg: impl Into<String>) -> Self {
        Self::InvalidBlock(msg.into())
    }

    pub fn invalid_transaction(msg: impl Into<String>) -> Self {
        Self::InvalidTransaction(msg.into())
    }

    pub fn consensus(msg: impl Into<String>) -> Self {
        Self::ConsensusError(msg.into())
    }

    pub fn crypto(msg: impl Into<String>) -> Self {
        Self::CryptoError(msg.into())
    }

    pub fn config(msg: impl Into<String>) -> Self {
        Self::ConfigError(msg.into())
    }

    pub fn ai_service(msg: impl Into<String>) -> Self {
        Self::AIServiceError(msg.into())
    }

    pub fn internal(msg: impl Into<String>) -> Self {
        Self::InternalError(msg.into())
    }
}

// Convert warp rejections to our error type
impl warp::reject::Reject for TrispiError {}

// Helper macros for common error patterns
#[macro_export]
macro_rules! ensure {
    ($cond:expr, $err:expr) => {
        if !$cond {
            return Err($err);
        }
    };
}

#[macro_export]
macro_rules! bail {
    ($err:expr) => {
        return Err($err);
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_creation() {
        let error = TrispiError::network("Test network error");
        assert!(matches!(error, TrispiError::NetworkError(_)));
    }

    #[test]
    fn test_error_display() {
        let error = TrispiError::InvalidBlock("Test block error".to_string());
        assert_eq!(error.to_string(), "Invalid block: Test block error");
    }

    #[test]
    fn test_error_from_conversion() {
        let io_error = std::io::Error::new(std::io::ErrorKind::NotFound, "File not found");
        let trispi_error: TrispiError = io_error.into();
        assert!(matches!(trispi_error, TrispiError::IoError(_)));
    }
}
