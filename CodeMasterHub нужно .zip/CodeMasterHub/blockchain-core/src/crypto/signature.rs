use anyhow::Result;
use ed25519_dalek::{Keypair, PublicKey, SecretKey, Signature as Ed25519Signature, Signer, Verifier};
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Signature {
    pub bytes: Vec<u8>,
}

impl Signature {
    pub fn from_bytes(bytes: Vec<u8>) -> Self {
        Self { bytes }
    }
}

pub struct KeyPair {
    keypair: Keypair,
}

impl KeyPair {
    pub fn generate() -> Result<Self> {
        let mut csprng = OsRng {};
        let keypair = Keypair::generate(&mut csprng);
        Ok(Self { keypair })
    }

    pub fn from_secret_key(secret_bytes: &[u8]) -> Result<Self> {
        let secret_key = SecretKey::from_bytes(secret_bytes)?;
        let public_key = PublicKey::from(&secret_key);
        let keypair = Keypair { secret: secret_key, public: public_key };
        Ok(Self { keypair })
    }

    pub fn sign(&self, message: &[u8]) -> Result<Signature> {
        let signature = self.keypair.sign(message);
        Ok(Signature::from_bytes(signature.to_bytes().to_vec()))
    }

    pub fn verify(&self, message: &[u8], signature: &Signature) -> Result<bool> {
        let ed25519_sig = Ed25519Signature::from_bytes(&signature.bytes)?;
        match self.keypair.public.verify(message, &ed25519_sig) {
            Ok(_) => Ok(true),
            Err(_) => Ok(false),
        }
    }

    pub fn public_key(&self) -> Vec<u8> {
        self.keypair.public.to_bytes().to_vec()
    }

    pub fn secret_key(&self) -> Vec<u8> {
        self.keypair.secret.to_bytes().to_vec()
    }
}
