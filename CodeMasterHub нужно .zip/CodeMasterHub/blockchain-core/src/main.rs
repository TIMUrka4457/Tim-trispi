use anyhow::Result;
use clap::{Arg, Command};
use std::env;
use tracing::{info, warn};
use tracing_subscriber;

mod network;
mod consensus;
mod ledger;
mod crypto;
mod ai_client;

use crate::network::p2p::P2PNode;
use crate::consensus::pos::ProofOfStake;
use crate::ledger::blockchain::Blockchain;

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::init();

    let matches = Command::new("TRISPI Blockchain Node")
        .version("1.0")
        .author("TRISPI Team")
        .about("Advanced AI-powered blockchain node")
        .arg(
            Arg::new("port")
                .short('p')
                .long("port")
                .value_name("PORT")
                .help("P2P listening port")
                .default_value("3030"),
        )
        .arg(
            Arg::new("ai-endpoint")
                .long("ai-endpoint")
                .value_name("URL")
                .help("AI backend endpoint")
                .default_value("http://localhost:8000/api/ai"),
        )
        .get_matches();

    let port = matches.get_one::<String>("port").unwrap();
    let ai_endpoint = matches.get_one::<String>("ai-endpoint").unwrap();

    info!("🚀 Starting TRISPI Blockchain Node on port {}", port);

    // Initialize blockchain
    let blockchain = Blockchain::new().await?;
    
    // Initialize AI client
    let ai_client = ai_client::AIClient::new(ai_endpoint);

    // Start P2P networking
    let p2p_node = P2PNode::new(blockchain.clone(), ai_client.clone()).await?;
    let p2p_handle = tokio::spawn(async move {
        if let Err(e) = p2p_node.start(&format!("0.0.0.0:{}", port)).await {
            warn!("P2P node error: {}", e);
        }
    });

    // Start consensus mechanism
    let consensus = ProofOfStake::new(blockchain.clone(), ai_client).await?;
    let consensus_handle = tokio::spawn(async move {
        if let Err(e) = consensus.run().await {
            warn!("Consensus error: {}", e);
        }
    });

    // Wait for both tasks
    tokio::try_join!(p2p_handle, consensus_handle)?;

    Ok(())
}
