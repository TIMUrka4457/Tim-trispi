//! Configuration management for TRISPI blockchain

use crate::consensus::pos::ConsensusConfig;
use serde::{Deserialize, Serialize};
use std::net::SocketAddr;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub database_url: String,
    pub ai_endpoint: String,
    pub network: NetworkConfig,
    pub consensus: ConsensusConfig,
    pub logging: LoggingConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkConfig {
    pub listen_address: String,
    pub rpc_address: String,
    pub bootstrap_peers: Vec<String>,
    pub max_peers: usize,
    pub peer_discovery_interval: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    pub level: String,
    pub file: Option<String>,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            database_url: "postgresql://trispi_user:trispi_pass@localhost:5432/trispi".to_string(),
            ai_endpoint: "http://localhost:8000/api/ai".to_string(),
            network: NetworkConfig::default(),
            consensus: ConsensusConfig::default(),
            logging: LoggingConfig::default(),
        }
    }
}

impl Default for NetworkConfig {
    fn default() -> Self {
        Self {
            listen_address: "0.0.0.0:3030".to_string(),
            rpc_address: "0.0.0.0:8080".to_string(),
            bootstrap_peers: vec![],
            max_peers: 50,
            peer_discovery_interval: 30,
        }
    }
}

impl Default for LoggingConfig {
    fn default() -> Self {
        Self {
            level: "info".to_string(),
            file: None,
        }
    }
}

impl AppConfig {
    pub fn load_from_env() -> Self {
        let mut config = Self::default();
        
        if let Ok(db_url) = std::env::var("DATABASE_URL") {
            config.database_url = db_url;
        }
        
        if let Ok(ai_endpoint) = std::env::var("AI_ENDPOINT") {
            config.ai_endpoint = ai_endpoint;
        }
        
        if let Ok(listen_addr) = std::env::var("LISTEN_ADDRESS") {
            config.network.listen_address = listen_addr;
        }
        
        if let Ok(rpc_addr) = std::env::var("RPC_ADDRESS") {
            config.network.rpc_address = rpc_addr;
        }
        
        if let Ok(log_level) = std::env::var("RUST_LOG") {
            config.logging.level = log_level;
        }
        
        config
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_config() {
        let config = AppConfig::default();
        assert!(config.database_url.contains("postgresql"));
        assert!(config.ai_endpoint.contains("localhost:8000"));
    }

    #[test]
    fn test_config_serialization() {
        let config = AppConfig::default();
        let serialized = serde_json::to_string(&config).unwrap();
        let deserialized: AppConfig = serde_json::from_str(&serialized).unwrap();
        assert_eq!(config.database_url, deserialized.database_url);
    }
}
