use anyhow::{Result, anyhow};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use std::time::Duration;
use tracing::{warn, info};

use crate::ledger::block::Block;
use crate::ledger::transaction::Transaction;

#[derive(Clone)]
pub struct AIClient {
    endpoint: String,
    client: Client,
}

#[derive(Serialize)]
pub struct GasFeeRequest {
    pub network_load: f64,
    pub tx_count: u32,
    pub avg_tps: f64,
    pub block_time: u32,
    pub mempool_size: u32,
}

#[derive(Deserialize)]
pub struct GasFeeResponse {
    pub recommended_gas_fee: f64,
}

#[derive(Serialize)]
pub struct ValidatorSelectionRequest {
    pub validators: Vec<(String, u64)>,
    pub network_stats: serde_json::Value,
}

#[derive(Deserialize)]
pub struct ValidatorSelectionResponse {
    pub selected_validator: String,
    pub confidence: f64,
}

#[derive(Serialize)]
pub struct FraudDetectionRequest {
    pub transaction_data: String,
    pub sender_history: Vec<String>,
    pub network_patterns: serde_json::Value,
}

#[derive(Deserialize)]
pub struct FraudDetectionResponse {
    pub is_safe: bool,
    pub risk_score: f64,
    pub reasons: Vec<String>,
}

impl AIClient {
    pub fn new(endpoint: &str) -> Self {
        let client = Client::builder()
            .timeout(Duration::from_secs(5))
            .build()
            .expect("Failed to create HTTP client");

        Self {
            endpoint: endpoint.to_string(),
            client,
        }
    }

    pub async fn optimize_gas_fee(&self, network_stats: &serde_json::Value, transactions: &[Transaction]) -> Result<f64> {
        let request = GasFeeRequest {
            network_load: network_stats["network_load"].as_f64().unwrap_or(0.5),
            tx_count: transactions.len() as u32,
            avg_tps: network_stats["avg_tps"].as_f64().unwrap_or(1000.0),
            block_time: network_stats["block_time"].as_u64().unwrap_or(10) as u32,
            mempool_size: network_stats["mempool_size"].as_u64().unwrap_or(0) as u32,
        };

        let url = format!("{}/gas_fee", self.endpoint);
        match self.client.post(&url).json(&request).send().await {
            Ok(response) => {
                if response.status().is_success() {
                    let fee_response: GasFeeResponse = response.json().await?;
                    info!("AI optimized gas fee: {}", fee_response.recommended_gas_fee);
                    Ok(fee_response.recommended_gas_fee)
                } else {
                    Err(anyhow!("AI service returned error: {}", response.status()))
                }
            }
            Err(e) => {
                warn!("Failed to connect to AI service: {}", e);
                Err(anyhow!("AI service unavailable"))
            }
        }
    }

    pub async fn select_validator(&self, validators: &[(String, u64)]) -> Result<String> {
        let network_stats = serde_json::json!({
            "timestamp": chrono::Utc::now().timestamp(),
            "total_validators": validators.len(),
            "total_stake": validators.iter().map(|(_, stake)| stake).sum::<u64>()
        });

        let request = ValidatorSelectionRequest {
            validators: validators.to_vec(),
            network_stats,
        };

        let url = format!("{}/validator_selection", self.endpoint);
        match self.client.post(&url).json(&request).send().await {
            Ok(response) => {
                if response.status().is_success() {
                    let selection_response: ValidatorSelectionResponse = response.json().await?;
                    info!("AI selected validator: {} (confidence: {})", 
                          selection_response.selected_validator, 
                          selection_response.confidence);
                    Ok(selection_response.selected_validator)
                } else {
                    Err(anyhow!("AI service returned error: {}", response.status()))
                }
            }
            Err(e) => {
                warn!("Failed to connect to AI service for validator selection: {}", e);
                Err(anyhow!("AI service unavailable"))
            }
        }
    }

    pub async fn check_transaction_fraud(&self, transaction_data: &str) -> Result<bool> {
        let request = FraudDetectionRequest {
            transaction_data: transaction_data.to_string(),
            sender_history: vec![], // Would be populated with actual history
            network_patterns: serde_json::json!({}),
        };

        let url = format!("{}/fraud_detection", self.endpoint);
        match self.client.post(&url).json(&request).send().await {
            Ok(response) => {
                if response.status().is_success() {
                    let fraud_response: FraudDetectionResponse = response.json().await?;
                    info!("Transaction fraud check: safe={}, risk_score={}", 
                          fraud_response.is_safe, 
                          fraud_response.risk_score);
                    Ok(fraud_response.is_safe)
                } else {
                    Err(anyhow!("AI service returned error: {}", response.status()))
                }
            }
            Err(e) => {
                warn!("Failed to connect to AI service for fraud detection: {}", e);
                Err(anyhow!("AI service unavailable"))
            }
        }
    }

    pub async fn validate_block(&self, block: &Block) -> Result<bool> {
        // AI-powered block validation
        let block_data = serde_json::json!({
            "index": block.index,
            "transaction_count": block.transactions.len(),
            "validator": block.validator,
            "gas_fee": block.gas_fee,
            "timestamp": block.timestamp.timestamp()
        });

        let url = format!("{}/block_validation", self.endpoint);
        match self.client.post(&url).json(&block_data).send().await {
            Ok(response) => {
                if response.status().is_success() {
                    let validation_result: serde_json::Value = response.json().await?;
                    let is_valid = validation_result["is_valid"].as_bool().unwrap_or(false);
                    info!("AI block validation result: {}", is_valid);
                    Ok(is_valid)
                } else {
                    Err(anyhow!("AI service returned error: {}", response.status()))
                }
            }
            Err(e) => {
                warn!("Failed to connect to AI service for block validation: {}", e);
                Err(anyhow!("AI service unavailable"))
            }
        }
    }
}
