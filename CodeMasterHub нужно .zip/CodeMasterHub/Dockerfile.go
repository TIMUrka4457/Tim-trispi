# Multi-stage build for Go P2P networking
FROM golang:1.21-alpine AS builder

# Install build dependencies
RUN apk add --no-cache git ca-certificates

# Set working directory
WORKDIR /app

# Copy go mod and sum files
COPY networking/go.mod networking/go.sum ./

# Download dependencies
RUN go mod download

# Copy source code
COPY networking/ .

# Build the application
RUN CGO_ENABLED=0 GOOS=linux go build -a -installsuffix cgo -o trispi-p2p .

# Runtime stage
FROM alpine:latest

# Install runtime dependencies
RUN apk --no-cache add ca-certificates curl

# Create non-root user
RUN adduser -D -s /bin/sh trispi

WORKDIR /app

# Copy binary from builder stage
COPY --from=builder /app/trispi-p2p .

# Copy configuration
COPY networking/config ./config

# Create necessary directories
RUN mkdir -p data logs && chown -R trispi:trispi /app

# Switch to non-root user
USER trispi

# Expose ports
EXPOSE 4000 3030

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:4000/health || exit 1

# Default command
CMD ["./trispi-p2p", "-port", "4000", "-ai", "http://ai-backend:8000/api/ai"]
