"""
TRISPI AI Backend Application Package
"""

__version__ = "1.0.0"
__author__ = "TRISPI Team"
__description__ = "AI services for TRISPI blockchain"
