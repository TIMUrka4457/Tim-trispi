"""
API routes for TRISPI AI Backend
"""

from typing import Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Request
from prometheus_client import Counter, Histogram
import structlog
import time

from app.models.requests import (
    GasFeeRequest,
    TxFraudRequest,
    ValidatorScoreRequest,
    ShardingRequest
)
from app.models.responses import (
    GasFeeResponse,
    TxFraudResponse,
    ValidatorScoreResponse,
    ShardingResponse
)

# Prometheus metrics
REQUEST_COUNT = Counter('ai_requests_total', 'Total AI requests', ['endpoint', 'status'])
REQUEST_DURATION = Histogram('ai_request_duration_seconds', 'Request duration', ['endpoint'])

logger = structlog.get_logger()
router = APIRouter()


@router.post("/ai/gas_fee", response_model=GasFeeResponse)
async def predict_gas_fee(request: GasFeeRequest, req: Request):
    """
    Predict optimal gas fee using AI
    """
    start_time = time.time()
    
    try:
        logger.info("Gas fee prediction request", 
                   network_load=request.network_load,
                   tx_count=request.tx_count)
        
        # Get AI model from app state
        gas_optimizer = req.app.state.gas_optimizer
        
        # Make prediction
        predicted_fee = gas_optimizer.predict_fee(
            network_load=request.network_load,
            tx_count=request.tx_count,
            avg_tps=request.avg_tps,
            block_time=request.block_time,
            mempool_size=request.mempool_size
        )
        
        # Record metrics
        REQUEST_COUNT.labels(endpoint='gas_fee', status='success').inc()
        REQUEST_DURATION.labels(endpoint='gas_fee').observe(time.time() - start_time)
        
        logger.info("Gas fee prediction completed", 
                   predicted_fee=predicted_fee,
                   duration=time.time() - start_time)
        
        return GasFeeResponse(recommended_gas_fee=predicted_fee)
        
    except Exception as e:
        REQUEST_COUNT.labels(endpoint='gas_fee', status='error').inc()
        logger.error("Gas fee prediction failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@router.post("/ai/tx_fraud", response_model=TxFraudResponse)
async def detect_transaction_fraud(request: TxFraudRequest, req: Request):
    """
    Detect fraudulent transactions using AI
    """
    start_time = time.time()
    
    try:
        logger.info("Fraud detection request", 
                   features_count=len(request.tx_features))
        
        # Get AI model from app state
        fraud_detector = req.app.state.fraud_detector
        
        # Make prediction
        is_suspicious = fraud_detector.is_suspicious(request.tx_features)
        
        # Record metrics
        REQUEST_COUNT.labels(endpoint='tx_fraud', status='success').inc()
        REQUEST_DURATION.labels(endpoint='tx_fraud').observe(time.time() - start_time)
        
        logger.info("Fraud detection completed", 
                   is_suspicious=is_suspicious,
                   duration=time.time() - start_time)
        
        return TxFraudResponse(is_suspicious=is_suspicious)
        
    except Exception as e:
        REQUEST_COUNT.labels(endpoint='tx_fraud', status='error').inc()
        logger.error("Fraud detection failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Fraud detection failed: {str(e)}")


@router.post("/ai/validator_score", response_model=ValidatorScoreResponse)
async def calculate_validator_score(request: ValidatorScoreRequest, req: Request):
    """
    Calculate validator performance score using AI
    """
    start_time = time.time()
    
    try:
        logger.info("Validator scoring request", 
                   uptime=request.uptime,
                   missed_blocks=request.missed_blocks)
        
        # Get AI model from app state
        validator_scorer = req.app.state.validator_scorer
        
        # Calculate score
        score = validator_scorer.calculate_score(
            uptime=request.uptime,
            response_time=request.response_time,
            missed_blocks=request.missed_blocks,
            slashing_events=request.slashing_events,
            reports=request.reports
        )
        
        # Record metrics
        REQUEST_COUNT.labels(endpoint='validator_score', status='success').inc()
        REQUEST_DURATION.labels(endpoint='validator_score').observe(time.time() - start_time)
        
        logger.info("Validator scoring completed", 
                   score=score,
                   duration=time.time() - start_time)
        
        return ValidatorScoreResponse(score=score)
        
    except Exception as e:
        REQUEST_COUNT.labels(endpoint='validator_score', status='error').inc()
        logger.error("Validator scoring failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Validator scoring failed: {str(e)}")


@router.post("/ai/sharding", response_model=ShardingResponse)
async def recommend_sharding(request: ShardingRequest, req: Request):
    """
    Recommend sharding strategy using AI
    """
    start_time = time.time()
    
    try:
        logger.info("Sharding recommendation request", 
                   network_stats_count=len(request.network_stats),
                   heatmap_size=len(request.tx_heatmap))
        
        # Get AI model from app state
        sharding_optimizer = req.app.state.sharding_optimizer
        
        # Make recommendation
        recommendation = sharding_optimizer.recommend_shard_split(
            network_stats=request.network_stats,
            tx_heatmap=request.tx_heatmap
        )
        
        # Record metrics
        REQUEST_COUNT.labels(endpoint='sharding', status='success').inc()
        REQUEST_DURATION.labels(endpoint='sharding').observe(time.time() - start_time)
        
        logger.info("Sharding recommendation completed", 
                   split=recommendation["split"],
                   target_shards=recommendation["target_shards"],
                   duration=time.time() - start_time)
        
        return ShardingResponse(
            split=recommendation["split"],
            target_shards=recommendation["target_shards"]
        )
        
    except Exception as e:
        REQUEST_COUNT.labels(endpoint='sharding', status='error').inc()
        logger.error("Sharding recommendation failed", error=str(e))
        raise HTTPException(status_code=500, detail=f"Sharding recommendation failed: {str(e)}")


@router.get("/ai/models/status")
async def get_models_status(req: Request):
    """
    Get status of all AI models
    """
    try:
        status = {
            "gas_optimizer": {
                "loaded": hasattr(req.app.state, 'gas_optimizer'),
                "model_type": "RandomForestRegressor",
                "version": "1.0"
            },
            "fraud_detector": {
                "loaded": hasattr(req.app.state, 'fraud_detector'),
                "model_type": "IsolationForest",
                "version": "1.0"
            },
            "validator_scorer": {
                "loaded": hasattr(req.app.state, 'validator_scorer'),
                "model_type": "WeightedScoring",
                "version": "1.0"
            },
            "sharding_optimizer": {
                "loaded": hasattr(req.app.state, 'sharding_optimizer'),
                "model_type": "RuleBasedOptimizer",
                "version": "1.0"
            }
        }
        
        return {"status": "healthy", "models": status}
        
    except Exception as e:
        logger.error("Failed to get models status", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get models status: {str(e)}")


@router.get("/ai/metrics")
async def get_ai_metrics():
    """
    Get AI service metrics
    """
    try:
        # This would typically return metrics from a metrics store
        # For now, return basic metrics
        metrics = {
            "total_requests": sum([
                REQUEST_COUNT.labels(endpoint='gas_fee', status='success')._value.get(),
                REQUEST_COUNT.labels(endpoint='tx_fraud', status='success')._value.get(),
                REQUEST_COUNT.labels(endpoint='validator_score', status='success')._value.get(),
                REQUEST_COUNT.labels(endpoint='sharding', status='success')._value.get()
            ]),
            "error_count": sum([
                REQUEST_COUNT.labels(endpoint='gas_fee', status='error')._value.get(),
                REQUEST_COUNT.labels(endpoint='tx_fraud', status='error')._value.get(),
                REQUEST_COUNT.labels(endpoint='validator_score', status='error')._value.get(),
                REQUEST_COUNT.labels(endpoint='sharding', status='error')._value.get()
            ]),
            "endpoints": {
                "gas_fee": {
                    "success_count": REQUEST_COUNT.labels(endpoint='gas_fee', status='success')._value.get(),
                    "error_count": REQUEST_COUNT.labels(endpoint='gas_fee', status='error')._value.get()
                },
                "tx_fraud": {
                    "success_count": REQUEST_COUNT.labels(endpoint='tx_fraud', status='success')._value.get(),
                    "error_count": REQUEST_COUNT.labels(endpoint='tx_fraud', status='error')._value.get()
                },
                "validator_score": {
                    "success_count": REQUEST_COUNT.labels(endpoint='validator_score', status='success')._value.get(),
                    "error_count": REQUEST_COUNT.labels(endpoint='validator_score', status='error')._value.get()
                },
                "sharding": {
                    "success_count": REQUEST_COUNT.labels(endpoint='sharding', status='success')._value.get(),
                    "error_count": REQUEST_COUNT.labels(endpoint='sharding', status='error')._value.get()
                }
            }
        }
        
        return metrics
        
    except Exception as e:
        logger.error("Failed to get AI metrics", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get metrics: {str(e)}")
