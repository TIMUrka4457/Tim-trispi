"""
Database configuration and connection management
"""

import asyncio
import os
from typing import Optional
import asyncpg
import structlog
from contextlib import asynccontextmanager

logger = structlog.get_logger()

# Global connection pool
_connection_pool: Optional[asyncpg.Pool] = None


async def init_db() -> None:
    """Initialize database connection pool"""
    global _connection_pool
    
    try:
        database_url = os.getenv('DATABASE_URL', 'postgresql://trispi_user:trispi_pass@localhost:5432/trispi')
        
        _connection_pool = await asyncpg.create_pool(
            database_url,
            min_size=5,
            max_size=20,
            max_queries=50000,
            max_inactive_connection_lifetime=300,
            command_timeout=60
        )
        
        logger.info("Database connection pool initialized", url=database_url.split('@')[1] if '@' in database_url else database_url)
        
        # Test connection
        async with _connection_pool.acquire() as conn:
            await conn.execute('SELECT 1')
            logger.info("Database connection test successful")
            
    except Exception as e:
        logger.error("Failed to initialize database", error=str(e))
        raise


async def close_db() -> None:
    """Close database connection pool"""
    global _connection_pool
    
    if _connection_pool:
        await _connection_pool.close()
        _connection_pool = None
        logger.info("Database connection pool closed")


@asynccontextmanager
async def get_db_connection():
    """Get database connection from pool"""
    if not _connection_pool:
        raise RuntimeError("Database pool not initialized")
    
    async with _connection_pool.acquire() as connection:
        try:
            yield connection
        except Exception as e:
            logger.error("Database operation failed", error=str(e))
            raise


class DatabaseManager:
    """Database operations manager"""
    
    @staticmethod
    async def store_prediction(model_type: str, input_data: dict, prediction: dict, confidence: float = None) -> str:
        """Store AI prediction in database"""
        try:
            async with get_db_connection() as conn:
                prediction_id = await conn.fetchval(
                    """
                    INSERT INTO ai_predictions (
                        prediction_type, input_data, prediction_result, 
                        confidence_score, model_version, timestamp
                    ) VALUES ($1, $2, $3, $4, $5, NOW())
                    RETURNING id
                    """,
                    model_type, input_data, prediction, confidence, "1.0"
                )
                
                logger.debug("Prediction stored", 
                           model_type=model_type, 
                           prediction_id=str(prediction_id))
                
                return str(prediction_id)
                
        except Exception as e:
            logger.error("Failed to store prediction", error=str(e))
            raise
    
    @staticmethod
    async def get_prediction_history(model_type: str, limit: int = 100) -> list:
        """Get prediction history for a model type"""
        try:
            async with get_db_connection() as conn:
                rows = await conn.fetch(
                    """
                    SELECT id, input_data, prediction_result, confidence_score, timestamp
                    FROM ai_predictions
                    WHERE prediction_type = $1
                    ORDER BY timestamp DESC
                    LIMIT $2
                    """,
                    model_type, limit
                )
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error("Failed to get prediction history", error=str(e))
            return []
    
    @staticmethod
    async def update_prediction_feedback(prediction_id: str, accuracy_feedback: float) -> bool:
        """Update prediction with accuracy feedback"""
        try:
            async with get_db_connection() as conn:
                result = await conn.execute(
                    """
                    UPDATE ai_predictions
                    SET accuracy_feedback = $1
                    WHERE id = $2
                    """,
                    accuracy_feedback, prediction_id
                )
                
                if result == "UPDATE 1":
                    logger.debug("Prediction feedback updated", 
                               prediction_id=prediction_id,
                               accuracy=accuracy_feedback)
                    return True
                else:
                    logger.warning("Prediction not found for feedback update", 
                                 prediction_id=prediction_id)
                    return False
                    
        except Exception as e:
            logger.error("Failed to update prediction feedback", error=str(e))
            return False
    
    @staticmethod
    async def get_model_performance_metrics(model_type: str, days: int = 30) -> dict:
        """Get performance metrics for a model type"""
        try:
            async with get_db_connection() as conn:
                # Get basic metrics
                basic_metrics = await conn.fetchrow(
                    """
                    SELECT 
                        COUNT(*) as total_predictions,
                        AVG(confidence_score) as avg_confidence,
                        AVG(accuracy_feedback) as avg_accuracy,
                        COUNT(CASE WHEN accuracy_feedback IS NOT NULL THEN 1 END) as feedback_count
                    FROM ai_predictions
                    WHERE prediction_type = $1 
                    AND timestamp > NOW() - INTERVAL '%s days'
                    """,
                    model_type, days
                )
                
                # Get daily prediction counts
                daily_counts = await conn.fetch(
                    """
                    SELECT 
                        DATE(timestamp) as date,
                        COUNT(*) as count
                    FROM ai_predictions
                    WHERE prediction_type = $1 
                    AND timestamp > NOW() - INTERVAL '%s days'
                    GROUP BY DATE(timestamp)
                    ORDER BY date DESC
                    """,
                    model_type, days
                )
                
                return {
                    "model_type": model_type,
                    "period_days": days,
                    "total_predictions": basic_metrics['total_predictions'],
                    "avg_confidence": float(basic_metrics['avg_confidence'] or 0),
                    "avg_accuracy": float(basic_metrics['avg_accuracy'] or 0),
                    "feedback_coverage": (basic_metrics['feedback_count'] / max(basic_metrics['total_predictions'], 1)),
                    "daily_counts": [
                        {"date": str(row['date']), "count": row['count']}
                        for row in daily_counts
                    ]
                }
                
        except Exception as e:
            logger.error("Failed to get model performance metrics", error=str(e))
            return {}
    
    @staticmethod
    async def store_validator_metrics(validator_address: str, metrics: dict) -> bool:
        """Store validator performance metrics"""
        try:
            async with get_db_connection() as conn:
                await conn.execute(
                    """
                    INSERT INTO validator_performance (
                        validator_address, blocks_produced, blocks_missed,
                        rewards_earned, slashing_amount, period_start, period_end
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                    ON CONFLICT (validator_address, period_start, period_end)
                    DO UPDATE SET
                        blocks_produced = EXCLUDED.blocks_produced,
                        blocks_missed = EXCLUDED.blocks_missed,
                        rewards_earned = EXCLUDED.rewards_earned,
                        slashing_amount = EXCLUDED.slashing_amount
                    """,
                    validator_address,
                    metrics.get('blocks_produced', 0),
                    metrics.get('blocks_missed', 0),
                    metrics.get('rewards_earned', 0.0),
                    metrics.get('slashing_amount', 0.0),
                    metrics.get('period_start'),
                    metrics.get('period_end')
                )
                
                logger.debug("Validator metrics stored", validator=validator_address)
                return True
                
        except Exception as e:
            logger.error("Failed to store validator metrics", error=str(e))
            return False
    
    @staticmethod
    async def get_network_statistics() -> dict:
        """Get current network statistics"""
        try:
            async with get_db_connection() as conn:
                # Get latest network stats
                stats = await conn.fetchrow(
                    """
                    SELECT * FROM network_stats
                    ORDER BY timestamp DESC
                    LIMIT 1
                    """
                )
                
                if stats:
                    return dict(stats)
                else:
                    # Return default stats if none exist
                    return {
                        "total_blocks": 0,
                        "total_transactions": 0,
                        "active_validators": 0,
                        "network_load": 0.0,
                        "avg_tps": 0.0,
                        "mempool_size": 0,
                        "avg_gas_fee": 0.0
                    }
                    
        except Exception as e:
            logger.error("Failed to get network statistics", error=str(e))
            return {}
    
    @staticmethod
    async def store_fraud_detection_result(transaction_id: str, is_suspicious: bool, 
                                         risk_score: float, risk_factors: list) -> bool:
        """Store fraud detection result"""
        try:
            async with get_db_connection() as conn:
                await conn.execute(
                    """
                    INSERT INTO fraud_detections (
                        transaction_id, is_suspicious, risk_score, 
                        risk_factors, detection_timestamp
                    ) VALUES ($1, $2, $3, $4, NOW())
                    ON CONFLICT (transaction_id) 
                    DO UPDATE SET
                        is_suspicious = EXCLUDED.is_suspicious,
                        risk_score = EXCLUDED.risk_score,
                        risk_factors = EXCLUDED.risk_factors,
                        detection_timestamp = EXCLUDED.detection_timestamp
                    """,
                    transaction_id, is_suspicious, risk_score, risk_factors
                )
                
                logger.debug("Fraud detection result stored", 
                           transaction_id=transaction_id,
                           is_suspicious=is_suspicious)
                return True
                
        except Exception as e:
            logger.error("Failed to store fraud detection result", error=str(e))
            return False
    
    @staticmethod
    async def cleanup_old_predictions(days: int = 90) -> int:
        """Clean up old prediction records"""
        try:
            async with get_db_connection() as conn:
                result = await conn.execute(
                    """
                    DELETE FROM ai_predictions
                    WHERE timestamp < NOW() - INTERVAL '%s days'
                    """,
                    days
                )
                
                deleted_count = int(result.split()[-1])
                logger.info("Old predictions cleaned up", 
                          deleted_count=deleted_count,
                          older_than_days=days)
                
                return deleted_count
                
        except Exception as e:
            logger.error("Failed to cleanup old predictions", error=str(e))
            return 0


# Create additional tables for AI-specific data if they don't exist
async def create_ai_tables():
    """Create AI-specific database tables"""
    try:
        async with get_db_connection() as conn:
            # Fraud detection results table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS fraud_detections (
                    transaction_id TEXT PRIMARY KEY,
                    is_suspicious BOOLEAN NOT NULL,
                    risk_score DOUBLE PRECISION NOT NULL,
                    risk_factors TEXT[],
                    detection_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)
            
            # Model training data table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS model_training_data (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    model_type TEXT NOT NULL,
                    features JSONB NOT NULL,
                    target_value DOUBLE PRECISION,
                    target_label TEXT,
                    data_source TEXT,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)
            
            # Create indexes
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_fraud_detections_timestamp 
                ON fraud_detections(detection_timestamp DESC)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_model_training_data_type 
                ON model_training_data(model_type)
            """)
            
            logger.info("AI-specific tables created/verified")
            
    except Exception as e:
        logger.error("Failed to create AI tables", error=str(e))
        raise


# Initialize AI tables when module is imported
async def init_ai_tables():
    """Initialize AI-specific tables"""
    if _connection_pool:
        await create_ai_tables()
