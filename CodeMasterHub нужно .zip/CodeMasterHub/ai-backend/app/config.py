"""
Configuration management for TRISPI AI Backend
"""

import os
from functools import lru_cache
from typing import List, Optional
from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    """Application settings"""
    
    # Basic app settings
    app_name: str = "TRISPI AI Backend"
    version: str = "1.0.0"
    debug: bool = Field(default=False, env="DEBUG")
    
    # Server settings
    host: str = Field(default="0.0.0.0", env="HOST")
    port: int = Field(default=8000, env="PORT")
    reload: bool = Field(default=False, env="RELOAD")
    
    # Database settings
    database_url: str = Field(
        default="postgresql://trispi_user:trispi_pass@localhost:5432/trispi",
        env="DATABASE_URL"
    )
    database_pool_size: int = Field(default=20, env="DATABASE_POOL_SIZE")
    database_timeout: int = Field(default=60, env="DATABASE_TIMEOUT")
    
    # Redis settings
    redis_url: str = Field(default="redis://localhost:6379", env="REDIS_URL")
    redis_timeout: int = Field(default=5, env="REDIS_TIMEOUT")
    
    # AI Model settings
    ai_model_path: str = Field(default="/app/models", env="AI_MODEL_PATH")
    model_update_interval: int = Field(default=3600, env="MODEL_UPDATE_INTERVAL")  # seconds
    batch_size: int = Field(default=1000, env="BATCH_SIZE")
    
    # Security settings
    allowed_origins: List[str] = Field(
        default=["*"],
        env="ALLOWED_ORIGINS"
    )
    api_key: Optional[str] = Field(default=None, env="API_KEY")
    rate_limit_per_minute: int = Field(default=100, env="RATE_LIMIT_PER_MINUTE")
    
    # Logging settings
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_format: str = Field(default="json", env="LOG_FORMAT")
    log_file: Optional[str] = Field(default=None, env="LOG_FILE")
    
    # Monitoring settings
    enable_metrics: bool = Field(default=True, env="ENABLE_METRICS")
    metrics_port: int = Field(default=9090, env="METRICS_PORT")
    
    # AI Service specific settings
    gas_fee_model_type: str = Field(default="RandomForestRegressor", env="GAS_FEE_MODEL_TYPE")
    fraud_detection_threshold: float = Field(default=-0.2, env="FRAUD_DETECTION_THRESHOLD")
    validator_scoring_weights: dict = Field(
        default={
            'uptime': 0.25,
            'reliability': 0.20,
            'performance': 0.15,
            'security': 0.15,
            'stake_health': 0.10,
            'experience': 0.10,
            'community': 0.05
        },
        env="VALIDATOR_SCORING_WEIGHTS"
    )
    
    # Sharding optimization settings
    max_shards: int = Field(default=64, env="MAX_SHARDS")
    min_shards: int = Field(default=2, env="MIN_SHARDS")
    target_utilization: float = Field(default=0.75, env="TARGET_UTILIZATION")
    
    # Performance settings
    worker_processes: int = Field(default=4, env="WORKER_PROCESSES")
    max_request_size: int = Field(default=10485760, env="MAX_REQUEST_SIZE")  # 10MB
    request_timeout: int = Field(default=30, env="REQUEST_TIMEOUT")
    
    # Blockchain integration settings
    blockchain_rpc_url: str = Field(
        default="http://localhost:8080",
        env="BLOCKCHAIN_RPC_URL"
    )
    network_layer_url: str = Field(
        default="http://localhost:9000",
        env="NETWORK_LAYER_URL"
    )
    
    # Data retention settings
    prediction_retention_days: int = Field(default=90, env="PREDICTION_RETENTION_DAYS")
    metrics_retention_days: int = Field(default=30, env="METRICS_RETENTION_DAYS")
    
    # Feature flags
    enable_batch_predictions: bool = Field(default=True, env="ENABLE_BATCH_PREDICTIONS")
    enable_model_updates: bool = Field(default=True, env="ENABLE_MODEL_UPDATES")
    enable_auto_scaling: bool = Field(default=False, env="ENABLE_AUTO_SCALING")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        
        # Example .env file content
        env_example = """
        DEBUG=false
        LOG_LEVEL=INFO
        DATABASE_URL=postgresql://user:pass@localhost:5432/trispi
        REDIS_URL=redis://localhost:6379
        API_KEY=your_secret_api_key
        ALLOWED_ORIGINS=["http://localhost:3000", "https://yourdomain.com"]
        AI_MODEL_PATH=/app/models
        GAS_FEE_MODEL_TYPE=RandomForestRegressor
        FRAUD_DETECTION_THRESHOLD=-0.2
        MAX_SHARDS=64
        TARGET_UTILIZATION=0.75
        WORKER_PROCESSES=4
        BLOCKCHAIN_RPC_URL=http://localhost:8080
        """


class DevelopmentSettings(Settings):
    """Development environment settings"""
    debug: bool = True
    log_level: str = "DEBUG"
    reload: bool = True
    worker_processes: int = 1
    
    class Config:
        env_prefix = "DEV_"


class ProductionSettings(Settings):
    """Production environment settings"""
    debug: bool = False
    log_level: str = "INFO"
    reload: bool = False
    allowed_origins: List[str] = []  # Should be explicitly set in production
    
    class Config:
        env_prefix = "PROD_"


class TestSettings(Settings):
    """Test environment settings"""
    debug: bool = True
    log_level: str = "DEBUG"
    database_url: str = "postgresql://test:test@localhost:5432/test_trispi"
    redis_url: str = "redis://localhost:6379/1"
    
    class Config:
        env_prefix = "TEST_"


@lru_cache()
def get_settings() -> Settings:
    """
    Get application settings based on environment
    """
    environment = os.getenv("ENVIRONMENT", "development").lower()
    
    if environment == "production":
        return ProductionSettings()
    elif environment == "test":
        return TestSettings()
    else:
        return DevelopmentSettings()


# Configuration validation
def validate_settings(settings: Settings) -> None:
    """Validate settings and raise errors for invalid configurations"""
    
    # Validate database URL
    if not settings.database_url.startswith(("postgresql://", "postgres://")):
        raise ValueError("DATABASE_URL must be a valid PostgreSQL connection string")
    
    # Validate Redis URL
    if not settings.redis_url.startswith("redis://"):
        raise ValueError("REDIS_URL must be a valid Redis connection string")
    
    # Validate AI model path
    if not os.path.exists(settings.ai_model_path):
        os.makedirs(settings.ai_model_path, exist_ok=True)
    
    # Validate fraud detection threshold
    if not -1.0 <= settings.fraud_detection_threshold <= 1.0:
        raise ValueError("FRAUD_DETECTION_THRESHOLD must be between -1.0 and 1.0")
    
    # Validate sharding settings
    if settings.min_shards >= settings.max_shards:
        raise ValueError("MIN_SHARDS must be less than MAX_SHARDS")
    
    if not 0.1 <= settings.target_utilization <= 1.0:
        raise ValueError("TARGET_UTILIZATION must be between 0.1 and 1.0")
    
    # Validate validator scoring weights
    weight_sum = sum(settings.validator_scoring_weights.values())
    if not 0.99 <= weight_sum <= 1.01:  # Allow for small floating point errors
        raise ValueError("Validator scoring weights must sum to 1.0")


# Environment-specific configurations
def get_database_config(settings: Settings) -> dict:
    """Get database configuration dictionary"""
    return {
        "url": settings.database_url,
        "pool_size": settings.database_pool_size,
        "timeout": settings.database_timeout
    }


def get_redis_config(settings: Settings) -> dict:
    """Get Redis configuration dictionary"""
    return {
        "url": settings.redis_url,
        "timeout": settings.redis_timeout
    }


def get_ai_config(settings: Settings) -> dict:
    """Get AI-specific configuration dictionary"""
    return {
        "model_path": settings.ai_model_path,
        "update_interval": settings.model_update_interval,
        "batch_size": settings.batch_size,
        "gas_fee_model_type": settings.gas_fee_model_type,
        "fraud_threshold": settings.fraud_detection_threshold,
        "validator_weights": settings.validator_scoring_weights,
        "max_shards": settings.max_shards,
        "min_shards": settings.min_shards,
        "target_utilization": settings.target_utilization
    }


def get_security_config(settings: Settings) -> dict:
    """Get security configuration dictionary"""
    return {
        "allowed_origins": settings.allowed_origins,
        "api_key": settings.api_key,
        "rate_limit": settings.rate_limit_per_minute
    }


# Export main settings getter
__all__ = ["get_settings", "Settings", "validate_settings"]
