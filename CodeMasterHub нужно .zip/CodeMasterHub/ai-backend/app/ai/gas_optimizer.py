"""
Gas Fee Optimization using Machine Learning
"""

import numpy as np
import joblib
import os
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import structlog

logger = structlog.get_logger()


class GasFeeOptimizer:
    """
    AI model for optimizing gas fees based on network conditions
    """
    
    def __init__(self, model_path: str = None):
        self.model = None
        self.scaler = None
        self.feature_names = [
            'network_load', 'tx_count', 'avg_tps', 'block_time', 'mempool_size'
        ]
        self.model_path = model_path or os.path.join(os.getenv('AI_MODEL_PATH', '/app/models'), 'gas_fee_model.pkl')
        self.scaler_path = model_path or os.path.join(os.getenv('AI_MODEL_PATH', '/app/models'), 'gas_fee_scaler.pkl')
        
        # Initialize model
        self._load_or_create_model()
    
    def _load_or_create_model(self):
        """Load existing model or create a new one"""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                logger.info("Loaded existing gas fee optimization model")
            else:
                self._create_and_train_model()
                logger.info("Created new gas fee optimization model")
        except Exception as e:
            logger.error("Failed to load gas fee model, creating new one", error=str(e))
            self._create_and_train_model()
    
    def _create_and_train_model(self):
        """Create and train a new model with synthetic data"""
        # Generate synthetic training data
        X, y = self._generate_training_data(1000)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        y_pred = self.model.predict(X_test_scaled)
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        logger.info("Model training completed", 
                   mae=mae, 
                   r2_score=r2,
                   training_samples=len(X_train))
        
        # Save model
        self._save_model()
    
    def _generate_training_data(self, n_samples: int):
        """Generate synthetic training data for gas fee optimization"""
        np.random.seed(42)
        
        # Generate features
        network_load = np.random.uniform(0, 1, n_samples)
        tx_count = np.random.randint(1, 1000, n_samples)
        avg_tps = np.random.uniform(100, 2000, n_samples)
        block_time = np.random.uniform(8, 20, n_samples)  # seconds
        mempool_size = np.random.randint(0, 500, n_samples)
        
        X = np.column_stack([network_load, tx_count, avg_tps, block_time, mempool_size])
        
        # Generate target values (gas fees) based on realistic relationships
        base_fee = 0.001  # Base gas fee
        
        # Gas fee increases with network load and mempool size
        load_factor = 1 + (network_load * 10)  # Up to 11x increase
        mempool_factor = 1 + (mempool_size / 500 * 5)  # Up to 6x increase
        
        # Gas fee decreases with higher TPS (better network efficiency)
        tps_factor = 2000 / (avg_tps + 100)  # Inverse relationship
        
        # Block time affects urgency
        time_factor = block_time / 12  # Normalized to 12-second blocks
        
        # Transaction count creates competition
        tx_factor = 1 + (tx_count / 1000 * 2)  # Up to 3x increase
        
        # Combine factors with some noise
        y = base_fee * load_factor * mempool_factor * tps_factor * time_factor * tx_factor
        y += np.random.normal(0, 0.0001, n_samples)  # Add noise
        y = np.clip(y, 0.0001, 1.0)  # Reasonable bounds
        
        return X, y
    
    def predict_fee(self, network_load: float, tx_count: int, avg_tps: float, 
                   block_time: int, mempool_size: int) -> float:
        """
        Predict optimal gas fee based on network conditions
        
        Args:
            network_load: Network load ratio (0-1)
            tx_count: Number of pending transactions
            avg_tps: Average transactions per second
            block_time: Block time in seconds
            mempool_size: Size of mempool
            
        Returns:
            Predicted gas fee
        """
        try:
            # Prepare features
            features = np.array([[network_load, tx_count, avg_tps, block_time, mempool_size]])
            
            # Validate inputs
            if not (0 <= network_load <= 1):
                raise ValueError("network_load must be between 0 and 1")
            if tx_count < 0:
                raise ValueError("tx_count must be non-negative")
            if avg_tps < 0:
                raise ValueError("avg_tps must be non-negative")
            if block_time <= 0:
                raise ValueError("block_time must be positive")
            if mempool_size < 0:
                raise ValueError("mempool_size must be non-negative")
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Make prediction
            predicted_fee = self.model.predict(features_scaled)[0]
            
            # Ensure reasonable bounds
            predicted_fee = max(0.0001, min(predicted_fee, 1.0))
            
            logger.debug("Gas fee prediction", 
                        network_load=network_load,
                        tx_count=tx_count,
                        predicted_fee=predicted_fee)
            
            return float(predicted_fee)
            
        except Exception as e:
            logger.error("Gas fee prediction failed", error=str(e))
            # Return fallback fee
            return 0.001
    
    def update_model(self, X: np.ndarray, y: np.ndarray):
        """
        Update the model with new training data
        
        Args:
            X: Feature matrix
            y: Target values
        """
        try:
            if len(X) != len(y):
                raise ValueError("X and y must have same length")
            
            # Scale new features
            X_scaled = self.scaler.transform(X)
            
            # Retrain model (in production, you might use partial_fit or incremental learning)
            self.model.fit(X_scaled, y)
            
            # Save updated model
            self._save_model()
            
            logger.info("Model updated with new data", samples=len(X))
            
        except Exception as e:
            logger.error("Model update failed", error=str(e))
            raise
    
    def _save_model(self):
        """Save the trained model and scaler"""
        try:
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)
            logger.info("Model saved", path=self.model_path)
        except Exception as e:
            logger.error("Failed to save model", error=str(e))
    
    def get_feature_importance(self):
        """Get feature importance from the trained model"""
        if self.model and hasattr(self.model, 'feature_importances_'):
            importance = dict(zip(self.feature_names, self.model.feature_importances_))
            return importance
        return None
    
    def evaluate_model(self, X_test: np.ndarray, y_test: np.ndarray) -> dict:
        """
        Evaluate model performance
        
        Args:
            X_test: Test features
            y_test: Test targets
            
        Returns:
            Dictionary with evaluation metrics
        """
        try:
            X_test_scaled = self.scaler.transform(X_test)
            y_pred = self.model.predict(X_test_scaled)
            
            metrics = {
                'mae': mean_absolute_error(y_test, y_pred),
                'r2_score': r2_score(y_test, y_pred),
                'rmse': np.sqrt(np.mean((y_test - y_pred) ** 2))
            }
            
            return metrics
            
        except Exception as e:
            logger.error("Model evaluation failed", error=str(e))
            return {}
