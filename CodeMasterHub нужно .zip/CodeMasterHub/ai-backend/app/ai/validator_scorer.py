"""
Validator Performance Scoring using AI
"""

import numpy as np
import structlog
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta

logger = structlog.get_logger()


@dataclass
class ValidatorMetrics:
    """Data class for validator metrics"""
    uptime: float
    response_time: float
    missed_blocks: int
    slashing_events: int
    reports: int
    blocks_produced: int = 0
    rewards_earned: float = 0.0
    stake_amount: float = 0.0
    delegator_count: int = 0
    commission_rate: float = 0.0
    age_days: int = 0


class ValidatorScorer:
    """
    AI-enhanced validator performance scoring system
    """
    
    def __init__(self):
        # Scoring weights for different metrics
        self.weights = {
            'uptime': 0.25,           # 25% - Very important
            'reliability': 0.20,      # 20% - Block production reliability
            'performance': 0.15,      # 15% - Response time and efficiency
            'security': 0.15,         # 15% - Slashing events and reports
            'stake_health': 0.10,     # 10% - Stake amount and distribution
            'experience': 0.10,       # 10% - Validator age and history
            'community': 0.05         # 5% - Community engagement
        }
        
        # Performance thresholds
        self.thresholds = {
            'excellent_uptime': 0.99,
            'good_uptime': 0.95,
            'poor_uptime': 0.90,
            'max_response_time': 1000,  # ms
            'max_missed_blocks': 5,
            'max_slashing_events': 0,
            'min_stake': 1000,
            'min_age_days': 30
        }
        
        logger.info("Validator scorer initialized", weights=self.weights)
    
    def calculate_score(self, uptime: float, response_time: float, missed_blocks: int,
                       slashing_events: int, reports: int, **kwargs) -> float:
        """
        Calculate comprehensive validator score
        
        Args:
            uptime: Validator uptime percentage (0-1)
            response_time: Average response time in ms
            missed_blocks: Number of missed blocks
            slashing_events: Number of slashing events
            reports: Number of reports against validator
            **kwargs: Additional metrics
            
        Returns:
            Validator score (0-1)
        """
        try:
            # Create metrics object
            metrics = ValidatorMetrics(
                uptime=uptime,
                response_time=response_time,
                missed_blocks=missed_blocks,
                slashing_events=slashing_events,
                reports=reports,
                blocks_produced=kwargs.get('blocks_produced', 0),
                rewards_earned=kwargs.get('rewards_earned', 0.0),
                stake_amount=kwargs.get('stake_amount', 0.0),
                delegator_count=kwargs.get('delegator_count', 0),
                commission_rate=kwargs.get('commission_rate', 0.0),
                age_days=kwargs.get('age_days', 0)
            )
            
            # Calculate individual component scores
            scores = {
                'uptime': self._score_uptime(metrics),
                'reliability': self._score_reliability(metrics),
                'performance': self._score_performance(metrics),
                'security': self._score_security(metrics),
                'stake_health': self._score_stake_health(metrics),
                'experience': self._score_experience(metrics),
                'community': self._score_community(metrics)
            }
            
            # Calculate weighted total score
            total_score = sum(
                scores[component] * self.weights[component]
                for component in scores
            )
            
            # Apply penalties for critical issues
            total_score = self._apply_penalties(total_score, metrics)
            
            # Ensure score is within bounds
            total_score = max(0.0, min(1.0, total_score))
            
            logger.debug("Validator score calculated",
                        component_scores=scores,
                        total_score=total_score,
                        validator_metrics=metrics)
            
            return total_score
            
        except Exception as e:
            logger.error("Validator scoring failed", error=str(e))
            return 0.5  # Default neutral score
    
    def _score_uptime(self, metrics: ValidatorMetrics) -> float:
        """Score validator uptime"""
        if metrics.uptime >= self.thresholds['excellent_uptime']:
            return 1.0
        elif metrics.uptime >= self.thresholds['good_uptime']:
            # Linear interpolation between good and excellent
            return 0.8 + 0.2 * (
                (metrics.uptime - self.thresholds['good_uptime']) /
                (self.thresholds['excellent_uptime'] - self.thresholds['good_uptime'])
            )
        elif metrics.uptime >= self.thresholds['poor_uptime']:
            # Linear interpolation between poor and good
            return 0.4 + 0.4 * (
                (metrics.uptime - self.thresholds['poor_uptime']) /
                (self.thresholds['good_uptime'] - self.thresholds['poor_uptime'])
            )
        else:
            # Poor uptime gets very low score
            return max(0.0, metrics.uptime / self.thresholds['poor_uptime'] * 0.4)
    
    def _score_reliability(self, metrics: ValidatorMetrics) -> float:
        """Score block production reliability"""
        if metrics.missed_blocks == 0:
            base_score = 1.0
        elif metrics.missed_blocks <= self.thresholds['max_missed_blocks']:
            # Exponential decay for missed blocks
            base_score = np.exp(-metrics.missed_blocks / 2.0)
        else:
            # Heavy penalty for many missed blocks
            base_score = max(0.1, np.exp(-metrics.missed_blocks / 1.0))
        
        # Bonus for high block production
        if metrics.blocks_produced > 100:
            production_bonus = min(0.1, np.log(metrics.blocks_produced / 100) / 10)
            base_score += production_bonus
        
        return min(1.0, base_score)
    
    def _score_performance(self, metrics: ValidatorMetrics) -> float:
        """Score validator performance metrics"""
        # Response time scoring
        if metrics.response_time <= 100:  # Excellent response time
            response_score = 1.0
        elif metrics.response_time <= 500:  # Good response time
            response_score = 1.0 - (metrics.response_time - 100) / 400 * 0.3
        elif metrics.response_time <= self.thresholds['max_response_time']:
            response_score = 0.7 - (metrics.response_time - 500) / 500 * 0.5
        else:
            response_score = max(0.1, 0.2 - (metrics.response_time - 1000) / 1000 * 0.1)
        
        # Efficiency bonus based on rewards vs stake
        efficiency_score = 0.5  # Default
        if metrics.stake_amount > 0 and metrics.rewards_earned > 0:
            reward_rate = metrics.rewards_earned / metrics.stake_amount
            # Normalize reward rate (assuming 5-15% APY is good)
            if 0.05 <= reward_rate <= 0.15:
                efficiency_score = 1.0
            elif reward_rate > 0.15:
                efficiency_score = 0.8  # Too high might be suspicious
            else:
                efficiency_score = max(0.2, reward_rate / 0.05 * 0.8)
        
        return (response_score + efficiency_score) / 2
    
    def _score_security(self, metrics: ValidatorMetrics) -> float:
        """Score validator security record"""
        base_score = 1.0
        
        # Heavy penalties for slashing events
        if metrics.slashing_events > 0:
            base_score *= (0.5 ** metrics.slashing_events)
        
        # Penalties for reports
        if metrics.reports > 0:
            base_score *= max(0.3, 1.0 - metrics.reports * 0.1)
        
        return max(0.0, base_score)
    
    def _score_stake_health(self, metrics: ValidatorMetrics) -> float:
        """Score validator stake health"""
        score = 0.5  # Default score
        
        # Stake amount scoring
        if metrics.stake_amount >= self.thresholds['min_stake'] * 10:
            stake_score = 1.0
        elif metrics.stake_amount >= self.thresholds['min_stake']:
            stake_score = 0.7 + 0.3 * (
                (metrics.stake_amount - self.thresholds['min_stake']) /
                (self.thresholds['min_stake'] * 9)
            )
        else:
            stake_score = max(0.1, metrics.stake_amount / self.thresholds['min_stake'] * 0.7)
        
        # Delegator count bonus (shows community trust)
        delegator_score = 0.5
        if metrics.delegator_count > 0:
            delegator_score = min(1.0, 0.5 + np.log(metrics.delegator_count + 1) / 10)
        
        # Commission rate scoring (reasonable rates are better)
        commission_score = 1.0
        if metrics.commission_rate > 0.2:  # 20%+ commission is high
            commission_score = max(0.3, 1.0 - (metrics.commission_rate - 0.2) / 0.3)
        elif metrics.commission_rate < 0.01:  # Very low commission might be unsustainable
            commission_score = 0.8
        
        return (stake_score + delegator_score + commission_score) / 3
    
    def _score_experience(self, metrics: ValidatorMetrics) -> float:
        """Score validator experience and history"""
        if metrics.age_days < self.thresholds['min_age_days']:
            # New validators get lower score
            return max(0.3, metrics.age_days / self.thresholds['min_age_days'] * 0.7)
        elif metrics.age_days < 365:  # Less than 1 year
            return 0.7 + 0.2 * (metrics.age_days - self.thresholds['min_age_days']) / 335
        else:  # 1+ years gets full score
            return min(1.0, 0.9 + min(0.1, np.log(metrics.age_days / 365) / 10))
    
    def _score_community(self, metrics: ValidatorMetrics) -> float:
        """Score community engagement and trust"""
        # This is a simplified implementation
        # In reality, this would include social metrics, governance participation, etc.
        
        base_score = 0.5
        
        # Delegator count as proxy for community trust
        if metrics.delegator_count > 100:
            base_score = 1.0
        elif metrics.delegator_count > 10:
            base_score = 0.5 + 0.5 * np.log(metrics.delegator_count / 10) / np.log(10)
        elif metrics.delegator_count > 0:
            base_score = 0.3 + 0.2 * metrics.delegator_count / 10
        
        return base_score
    
    def _apply_penalties(self, score: float, metrics: ValidatorMetrics) -> float:
        """Apply penalties for critical issues"""
        penalty_factor = 1.0
        
        # Critical penalties
        if metrics.slashing_events > 2:
            penalty_factor *= 0.5  # 50% penalty for multiple slashing events
        
        if metrics.uptime < 0.8:
            penalty_factor *= 0.7  # 30% penalty for very poor uptime
        
        if metrics.missed_blocks > 20:
            penalty_factor *= 0.8  # 20% penalty for many missed blocks
        
        return score * penalty_factor
    
    def get_detailed_analysis(self, metrics: ValidatorMetrics) -> Dict:
        """
        Get detailed analysis of validator performance
        
        Args:
            metrics: Validator metrics
            
        Returns:
            Detailed analysis dictionary
        """
        try:
            # Calculate component scores
            scores = {
                'uptime': self._score_uptime(metrics),
                'reliability': self._score_reliability(metrics),
                'performance': self._score_performance(metrics),
                'security': self._score_security(metrics),
                'stake_health': self._score_stake_health(metrics),
                'experience': self._score_experience(metrics),
                'community': self._score_community(metrics)
            }
            
            # Calculate total score
            total_score = sum(
                scores[component] * self.weights[component]
                for component in scores
            )
            
            # Generate recommendations
            recommendations = self._generate_recommendations(metrics, scores)
            
            # Identify strengths and weaknesses
            strengths = [
                component for component, score in scores.items()
                if score >= 0.8
            ]
            
            weaknesses = [
                component for component, score in scores.items()
                if score < 0.6
            ]
            
            # Risk assessment
            risk_level = self._assess_risk_level(metrics, scores)
            
            return {
                "overall_score": total_score,
                "component_scores": scores,
                "weighted_scores": {
                    component: scores[component] * self.weights[component]
                    for component in scores
                },
                "strengths": strengths,
                "weaknesses": weaknesses,
                "recommendations": recommendations,
                "risk_level": risk_level,
                "metrics_summary": {
                    "uptime_percentage": f"{metrics.uptime * 100:.2f}%",
                    "response_time_ms": metrics.response_time,
                    "missed_blocks": metrics.missed_blocks,
                    "slashing_events": metrics.slashing_events,
                    "blocks_produced": metrics.blocks_produced,
                    "stake_amount": metrics.stake_amount,
                    "delegator_count": metrics.delegator_count,
                    "age_days": metrics.age_days
                }
            }
            
        except Exception as e:
            logger.error("Detailed analysis failed", error=str(e))
            return {"error": "Analysis failed", "overall_score": 0.5}
    
    def _generate_recommendations(self, metrics: ValidatorMetrics, scores: Dict) -> List[str]:
        """Generate recommendations based on validator performance"""
        recommendations = []
        
        if scores['uptime'] < 0.8:
            recommendations.append("Improve validator uptime and reliability")
        
        if scores['performance'] < 0.7:
            recommendations.append("Optimize validator performance and response time")
        
        if metrics.missed_blocks > 5:
            recommendations.append("Reduce missed blocks through better monitoring")
        
        if scores['security'] < 0.9:
            recommendations.append("Review security practices to prevent slashing")
        
        if metrics.stake_amount < self.thresholds['min_stake']:
            recommendations.append("Increase stake amount to improve network security")
        
        if metrics.delegator_count < 10:
            recommendations.append("Engage with community to attract more delegators")
        
        if metrics.commission_rate > 0.15:
            recommendations.append("Consider reducing commission rate to attract delegators")
        
        if metrics.age_days < 90:
            recommendations.append("Continue operating consistently to build reputation")
        
        return recommendations
    
    def _assess_risk_level(self, metrics: ValidatorMetrics, scores: Dict) -> str:
        """Assess overall risk level of the validator"""
        overall_score = sum(
            scores[component] * self.weights[component]
            for component in scores
        )
        
        if metrics.slashing_events > 1 or metrics.uptime < 0.8:
            return "HIGH"
        elif overall_score >= 0.8:
            return "LOW"
        elif overall_score >= 0.6:
            return "MEDIUM"
        else:
            return "HIGH"
    
    def compare_validators(self, validators_data: List[Dict]) -> Dict:
        """
        Compare multiple validators and rank them
        
        Args:
            validators_data: List of validator data dictionaries
            
        Returns:
            Comparison results with rankings
        """
        try:
            results = []
            
            for i, data in enumerate(validators_data):
                score = self.calculate_score(**data)
                results.append({
                    "validator_id": data.get('id', f'validator_{i}'),
                    "score": score,
                    "data": data
                })
            
            # Sort by score (descending)
            results.sort(key=lambda x: x['score'], reverse=True)
            
            # Add rankings
            for i, result in enumerate(results):
                result["rank"] = i + 1
            
            return {
                "rankings": results,
                "summary": {
                    "total_validators": len(results),
                    "avg_score": np.mean([r['score'] for r in results]),
                    "top_score": results[0]['score'] if results else 0,
                    "bottom_score": results[-1]['score'] if results else 0
                }
            }
            
        except Exception as e:
            logger.error("Validator comparison failed", error=str(e))
            return {"error": "Comparison failed"}
