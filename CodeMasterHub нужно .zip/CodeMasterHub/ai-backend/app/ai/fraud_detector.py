"""
Transaction Fraud Detection using Machine Learning
"""

import numpy as np
import joblib
import os
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
import structlog

logger = structlog.get_logger()


class TxFraudDetector:
    """
    AI model for detecting fraudulent transactions using anomaly detection
    """
    
    def __init__(self, model_path: str = None):
        self.model = None
        self.scaler = None
        self.feature_names = [
            'amount', 'gas_fee', 'time_since_last_tx', 'sender_balance', 
            'receiver_balance', 'tx_frequency', 'amount_velocity', 'gas_ratio'
        ]
        self.model_path = model_path or os.path.join(os.getenv('AI_MODEL_PATH', '/app/models'), 'fraud_model.pkl')
        self.scaler_path = model_path or os.path.join(os.getenv('AI_MODEL_PATH', '/app/models'), 'fraud_scaler.pkl')
        
        # Fraud detection thresholds
        self.anomaly_threshold = -0.2
        self.high_amount_threshold = 1000000  # Large transaction threshold
        self.suspicious_patterns = {
            'rapid_fire': 10,  # More than 10 transactions per minute
            'round_amount': [100, 1000, 10000, 100000],  # Suspicious round amounts
            'gas_anomaly': 0.1  # Gas fee deviation threshold
        }
        
        # Initialize model
        self._load_or_create_model()
    
    def _load_or_create_model(self):
        """Load existing model or create a new one"""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                logger.info("Loaded existing fraud detection model")
            else:
                self._create_and_train_model()
                logger.info("Created new fraud detection model")
        except Exception as e:
            logger.error("Failed to load fraud model, creating new one", error=str(e))
            self._create_and_train_model()
    
    def _create_and_train_model(self):
        """Create and train a new fraud detection model"""
        # Generate synthetic training data
        X, y = self._generate_training_data(5000)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train isolation forest for anomaly detection
        self.model = IsolationForest(
            contamination=0.1,  # Expect 10% anomalies
            random_state=42,
            n_estimators=100
        )
        
        # Train on normal transactions only
        normal_indices = y_train == 0
        self.model.fit(X_train_scaled[normal_indices])
        
        # Evaluate model
        y_pred = self.model.predict(X_test_scaled)
        y_pred_binary = (y_pred == -1).astype(int)  # Convert to binary (1 = fraud, 0 = normal)
        
        logger.info("Fraud detection model training completed",
                   test_samples=len(X_test),
                   fraud_samples=sum(y_test),
                   detected_frauds=sum(y_pred_binary))
        
        # Save model
        self._save_model()
    
    def _generate_training_data(self, n_samples: int):
        """Generate synthetic training data for fraud detection"""
        np.random.seed(42)
        
        # Generate normal transactions (90%)
        n_normal = int(n_samples * 0.9)
        n_fraud = n_samples - n_normal
        
        # Normal transaction features
        normal_amounts = np.random.lognormal(3, 1.5, n_normal)  # Log-normal distribution
        normal_gas_fees = np.random.uniform(0.001, 0.01, n_normal)
        normal_time_gaps = np.random.exponential(300, n_normal)  # 5 min average
        normal_sender_balance = np.random.lognormal(8, 2, n_normal)
        normal_receiver_balance = np.random.lognormal(7, 2, n_normal)
        normal_tx_frequency = np.random.poisson(2, n_normal)  # 2 tx per hour average
        normal_amount_velocity = normal_amounts / np.maximum(normal_time_gaps, 1)
        normal_gas_ratio = normal_gas_fees / np.maximum(normal_amounts, 0.001)
        
        # Fraudulent transaction features (more extreme values)
        fraud_amounts = np.concatenate([
            np.random.lognormal(6, 2, n_fraud // 2),  # Very large amounts
            np.random.uniform(0.1, 10, n_fraud // 2)  # Very small amounts
        ])
        fraud_gas_fees = np.random.uniform(0.0001, 0.1, n_fraud)  # Unusual gas fees
        fraud_time_gaps = np.random.exponential(10, n_fraud)  # Very rapid transactions
        fraud_sender_balance = np.random.lognormal(10, 3, n_fraud)  # Unusual balances
        fraud_receiver_balance = np.random.lognormal(5, 3, n_fraud)
        fraud_tx_frequency = np.random.poisson(20, n_fraud)  # High frequency
        fraud_amount_velocity = fraud_amounts / np.maximum(fraud_time_gaps, 1)
        fraud_gas_ratio = fraud_gas_fees / np.maximum(fraud_amounts, 0.001)
        
        # Combine features
        X_normal = np.column_stack([
            normal_amounts, normal_gas_fees, normal_time_gaps,
            normal_sender_balance, normal_receiver_balance,
            normal_tx_frequency, normal_amount_velocity, normal_gas_ratio
        ])
        
        X_fraud = np.column_stack([
            fraud_amounts, fraud_gas_fees, fraud_time_gaps,
            fraud_sender_balance, fraud_receiver_balance,
            fraud_tx_frequency, fraud_amount_velocity, fraud_gas_ratio
        ])
        
        X = np.vstack([X_normal, X_fraud])
        y = np.concatenate([np.zeros(n_normal), np.ones(n_fraud)])
        
        # Shuffle data
        indices = np.random.permutation(len(X))
        return X[indices], y[indices]
    
    def is_suspicious(self, tx_features: list) -> bool:
        """
        Check if a transaction is suspicious based on features
        
        Args:
            tx_features: List of transaction features
            
        Returns:
            True if transaction is suspicious, False otherwise
        """
        try:
            # If we don't have enough features, use basic rule-based detection
            if len(tx_features) < len(self.feature_names):
                return self._rule_based_detection(tx_features)
            
            # Prepare features for ML model
            features = np.array([tx_features[:len(self.feature_names)]])
            
            # Validate inputs
            if np.any(np.isnan(features)) or np.any(np.isinf(features)):
                logger.warning("Invalid features detected, using rule-based fallback")
                return self._rule_based_detection(tx_features)
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Get anomaly score
            anomaly_score = self.model.decision_function(features_scaled)[0]
            
            # Check if transaction is anomalous
            is_anomaly = anomaly_score < self.anomaly_threshold
            
            # Additional rule-based checks
            rule_based_suspicious = self._rule_based_detection(tx_features)
            
            # Combine ML and rule-based results
            is_suspicious = is_anomaly or rule_based_suspicious
            
            logger.debug("Fraud detection completed",
                        anomaly_score=anomaly_score,
                        is_anomaly=is_anomaly,
                        rule_based_suspicious=rule_based_suspicious,
                        final_result=is_suspicious)
            
            return is_suspicious
            
        except Exception as e:
            logger.error("Fraud detection failed, using conservative approach", error=str(e))
            # Conservative approach: flag unusual patterns
            return self._rule_based_detection(tx_features)
    
    def _rule_based_detection(self, tx_features: list) -> bool:
        """
        Rule-based fraud detection as fallback
        
        Args:
            tx_features: List of transaction features
            
        Returns:
            True if suspicious based on rules
        """
        try:
            if len(tx_features) == 0:
                return False
            
            amount = tx_features[0] if len(tx_features) > 0 else 0
            gas_fee = tx_features[1] if len(tx_features) > 1 else 0
            time_gap = tx_features[2] if len(tx_features) > 2 else 300
            
            suspicious_flags = []
            
            # Check for unusually large amounts
            if amount > self.high_amount_threshold:
                suspicious_flags.append("large_amount")
            
            # Check for round amounts (often used in fraud)
            if amount in self.suspicious_patterns['round_amount']:
                suspicious_flags.append("round_amount")
            
            # Check for rapid transactions
            if time_gap < 60 / self.suspicious_patterns['rapid_fire']:  # Less than 6 seconds
                suspicious_flags.append("rapid_fire")
            
            # Check for unusual gas fees
            if len(tx_features) > 1 and amount > 0:
                gas_ratio = gas_fee / amount
                if gas_ratio > self.suspicious_patterns['gas_anomaly'] or gas_ratio < 0.00001:
                    suspicious_flags.append("gas_anomaly")
            
            # Check for very small amounts with high gas fees (dust attack)
            if amount < 0.001 and gas_fee > 0.01:
                suspicious_flags.append("dust_attack")
            
            is_suspicious = len(suspicious_flags) >= 2  # Multiple red flags
            
            if suspicious_flags:
                logger.debug("Rule-based fraud detection flags", 
                           flags=suspicious_flags,
                           is_suspicious=is_suspicious)
            
            return is_suspicious
            
        except Exception as e:
            logger.error("Rule-based detection failed", error=str(e))
            return False
    
    def analyze_transaction_pattern(self, tx_history: list) -> dict:
        """
        Analyze transaction patterns for a user
        
        Args:
            tx_history: List of transaction dictionaries
            
        Returns:
            Analysis results
        """
        try:
            if not tx_history:
                return {"risk_score": 0.0, "patterns": [], "recommendations": []}
            
            analysis = {
                "risk_score": 0.0,
                "patterns": [],
                "recommendations": [],
                "statistics": {}
            }
            
            # Extract features
            amounts = [tx.get('amount', 0) for tx in tx_history]
            timestamps = [tx.get('timestamp', 0) for tx in tx_history]
            gas_fees = [tx.get('gas_fee', 0) for tx in tx_history]
            
            # Calculate statistics
            analysis["statistics"] = {
                "total_transactions": len(tx_history),
                "total_amount": sum(amounts),
                "avg_amount": np.mean(amounts) if amounts else 0,
                "max_amount": max(amounts) if amounts else 0,
                "avg_gas_fee": np.mean(gas_fees) if gas_fees else 0
            }
            
            # Pattern analysis
            if len(amounts) > 1:
                # Check for amount patterns
                amount_std = np.std(amounts)
                amount_mean = np.mean(amounts)
                if amount_std / amount_mean < 0.1 and len(amounts) > 5:
                    analysis["patterns"].append("consistent_amounts")
                    analysis["risk_score"] += 0.3
                
                # Check for timing patterns
                if len(timestamps) > 2:
                    time_diffs = np.diff(sorted(timestamps))
                    if np.std(time_diffs) < np.mean(time_diffs) * 0.1:
                        analysis["patterns"].append("regular_timing")
                        analysis["risk_score"] += 0.2
                
                # Check for frequency
                if len(tx_history) > 50:
                    analysis["patterns"].append("high_frequency")
                    analysis["risk_score"] += 0.1
            
            # Generate recommendations
            if analysis["risk_score"] > 0.5:
                analysis["recommendations"].append("Enhanced monitoring recommended")
            if analysis["risk_score"] > 0.7:
                analysis["recommendations"].append("Manual review required")
            if "consistent_amounts" in analysis["patterns"]:
                analysis["recommendations"].append("Check for automated trading")
            
            return analysis
            
        except Exception as e:
            logger.error("Transaction pattern analysis failed", error=str(e))
            return {"risk_score": 0.5, "patterns": [], "recommendations": ["Analysis failed"]}
    
    def update_model(self, X: np.ndarray, y: np.ndarray):
        """
        Update the fraud detection model with new data
        
        Args:
            X: Feature matrix
            y: Labels (0 = normal, 1 = fraud)
        """
        try:
            if len(X) != len(y):
                raise ValueError("X and y must have same length")
            
            # Filter for normal transactions only
            normal_indices = y == 0
            if np.sum(normal_indices) == 0:
                logger.warning("No normal transactions in update data")
                return
            
            # Scale new features
            X_scaled = self.scaler.transform(X)
            
            # Retrain model on normal transactions
            self.model.fit(X_scaled[normal_indices])
            
            # Save updated model
            self._save_model()
            
            logger.info("Fraud detection model updated", 
                       samples=len(X),
                       normal_samples=np.sum(normal_indices),
                       fraud_samples=np.sum(y))
            
        except Exception as e:
            logger.error("Model update failed", error=str(e))
            raise
    
    def _save_model(self):
        """Save the trained model and scaler"""
        try:
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)
            logger.info("Fraud detection model saved", path=self.model_path)
        except Exception as e:
            logger.error("Failed to save fraud detection model", error=str(e))
    
    def get_model_info(self) -> dict:
        """Get information about the current model"""
        return {
            "model_type": "IsolationForest",
            "features": self.feature_names,
            "anomaly_threshold": self.anomaly_threshold,
            "contamination": getattr(self.model, 'contamination', 0.1),
            "n_estimators": getattr(self.model, 'n_estimators', 100)
        }
