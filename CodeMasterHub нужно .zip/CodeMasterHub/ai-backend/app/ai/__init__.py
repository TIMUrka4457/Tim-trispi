"""
AI package for TRISPI blockchain
"""
