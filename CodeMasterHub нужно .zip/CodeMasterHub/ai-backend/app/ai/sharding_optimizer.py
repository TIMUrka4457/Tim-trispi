"""
Sharding Optimization using AI
"""

import numpy as np
import structlog
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict

logger = structlog.get_logger()


@dataclass
class ShardMetrics:
    """Metrics for a single shard"""
    shard_id: int
    transaction_count: int
    total_gas_used: float
    average_response_time: float
    validator_count: int
    storage_size: float  # MB
    cross_shard_txs: int
    utilization: float  # 0-1


@dataclass
class NetworkMetrics:
    """Overall network metrics"""
    total_tps: float
    total_shards: int
    cross_shard_ratio: float
    avg_block_time: float
    network_congestion: float
    validator_distribution: List[int]  # validators per shard


class ShardingOptimizer:
    """
    AI-powered sharding optimization system
    """
    
    def __init__(self):
        # Optimization parameters
        self.target_utilization = 0.75  # Target shard utilization
        self.max_utilization = 0.9      # Maximum acceptable utilization
        self.min_utilization = 0.3      # Minimum utilization before merge
        self.max_shards = 64            # Maximum number of shards
        self.min_shards = 2             # Minimum number of shards
        self.min_validators_per_shard = 4
        
        # Performance thresholds
        self.thresholds = {
            'max_response_time': 2000,      # ms
            'max_cross_shard_ratio': 0.3,   # 30%
            'target_tps_per_shard': 1000,
            'split_threshold': 0.85,        # Utilization threshold for splitting
            'merge_threshold': 0.25         # Utilization threshold for merging
        }
        
        logger.info("Sharding optimizer initialized")
    
    def recommend_shard_split(self, network_stats: Dict, tx_heatmap: List[float]) -> Dict:
        """
        Recommend sharding strategy based on network conditions
        
        Args:
            network_stats: Dictionary with network statistics
            tx_heatmap: List of transaction load per shard (0-1 values)
            
        Returns:
            Sharding recommendation
        """
        try:
            logger.debug("Analyzing sharding optimization", 
                        network_stats=network_stats,
                        heatmap_size=len(tx_heatmap))
            
            current_shards = len(tx_heatmap) if tx_heatmap else 1
            
            # Analyze current performance
            analysis = self._analyze_current_performance(network_stats, tx_heatmap)
            
            # Determine recommendation
            recommendation = self._generate_recommendation(analysis, current_shards)
            
            logger.info("Sharding recommendation generated",
                       current_shards=current_shards,
                       recommended_action=recommendation.get('action'),
                       target_shards=recommendation.get('target_shards'))
            
            return recommendation
            
        except Exception as e:
            logger.error("Sharding optimization failed", error=str(e))
            return {
                "split": False,
                "target_shards": len(tx_heatmap) if tx_heatmap else 1,
                "action": "maintain",
                "reason": "Analysis failed",
                "confidence": 0.0
            }
    
    def _analyze_current_performance(self, network_stats: Dict, tx_heatmap: List[float]) -> Dict:
        """Analyze current network performance"""
        analysis = {
            "current_shards": len(tx_heatmap) if tx_heatmap else 1,
            "avg_utilization": 0.0,
            "max_utilization": 0.0,
            "min_utilization": 0.0,
            "utilization_variance": 0.0,
            "overloaded_shards": 0,
            "underloaded_shards": 0,
            "total_tps": network_stats.get('total_tps', 0),
            "network_congestion": network_stats.get('network_congestion', 0),
            "cross_shard_ratio": network_stats.get('cross_shard_ratio', 0),
            "performance_issues": []
        }
        
        if tx_heatmap:
            heatmap = np.array(tx_heatmap)
            analysis["avg_utilization"] = np.mean(heatmap)
            analysis["max_utilization"] = np.max(heatmap)
            analysis["min_utilization"] = np.min(heatmap)
            analysis["utilization_variance"] = np.var(heatmap)
            
            # Count problematic shards
            analysis["overloaded_shards"] = np.sum(heatmap > self.thresholds['split_threshold'])
            analysis["underloaded_shards"] = np.sum(heatmap < self.thresholds['merge_threshold'])
            
            # Identify performance issues
            if analysis["max_utilization"] > self.max_utilization:
                analysis["performance_issues"].append("shard_overload")
            
            if analysis["utilization_variance"] > 0.1:
                analysis["performance_issues"].append("load_imbalance")
            
            if analysis["cross_shard_ratio"] > self.thresholds['max_cross_shard_ratio']:
                analysis["performance_issues"].append("excessive_cross_shard")
        
        # Network-level issues
        if network_stats.get('avg_response_time', 0) > self.thresholds['max_response_time']:
            analysis["performance_issues"].append("slow_response")
        
        if network_stats.get('network_congestion', 0) > 0.8:
            analysis["performance_issues"].append("network_congestion")
        
        return analysis
    
    def _generate_recommendation(self, analysis: Dict, current_shards: int) -> Dict:
        """Generate sharding recommendation based on analysis"""
        recommendation = {
            "split": False,
            "target_shards": current_shards,
            "action": "maintain",
            "reason": "",
            "confidence": 0.0,
            "priority": "low",
            "estimated_improvement": {},
            "implementation_plan": []
        }
        
        # Determine if we should split shards
        should_split = self._should_split_shards(analysis, current_shards)
        should_merge = self._should_merge_shards(analysis, current_shards)
        
        if should_split and not should_merge:
            target_shards = self._calculate_optimal_shard_count(analysis, current_shards, "split")
            recommendation.update({
                "split": True,
                "target_shards": target_shards,
                "action": "split",
                "reason": self._get_split_reason(analysis),
                "confidence": self._calculate_confidence(analysis, "split"),
                "priority": self._get_priority(analysis),
                "estimated_improvement": self._estimate_improvement(analysis, target_shards, "split"),
                "implementation_plan": self._create_implementation_plan("split", current_shards, target_shards)
            })
        elif should_merge and not should_split:
            target_shards = self._calculate_optimal_shard_count(analysis, current_shards, "merge")
            recommendation.update({
                "split": False,  # This is merge, not split
                "target_shards": target_shards,
                "action": "merge",
                "reason": self._get_merge_reason(analysis),
                "confidence": self._calculate_confidence(analysis, "merge"),
                "priority": self._get_priority(analysis),
                "estimated_improvement": self._estimate_improvement(analysis, target_shards, "merge"),
                "implementation_plan": self._create_implementation_plan("merge", current_shards, target_shards)
            })
        else:
            # Maintain current configuration
            recommendation.update({
                "reason": "Current sharding configuration is optimal",
                "confidence": self._calculate_confidence(analysis, "maintain"),
                "priority": "low"
            })
        
        return recommendation
    
    def _should_split_shards(self, analysis: Dict, current_shards: int) -> bool:
        """Determine if shards should be split"""
        if current_shards >= self.max_shards:
            return False
        
        # Split conditions
        conditions = [
            analysis["overloaded_shards"] > 0,  # Any overloaded shards
            analysis["max_utilization"] > self.thresholds['split_threshold'],
            "shard_overload" in analysis["performance_issues"],
            analysis["avg_utilization"] > 0.8 and analysis["utilization_variance"] < 0.05  # High uniform load
        ]
        
        return any(conditions)
    
    def _should_merge_shards(self, analysis: Dict, current_shards: int) -> bool:
        """Determine if shards should be merged"""
        if current_shards <= self.min_shards:
            return False
        
        # Merge conditions
        conditions = [
            analysis["underloaded_shards"] >= current_shards // 2,  # Half or more underloaded
            analysis["avg_utilization"] < self.thresholds['merge_threshold'],
            analysis["max_utilization"] < 0.5  # Even the busiest shard is underutilized
        ]
        
        return any(conditions)
    
    def _calculate_optimal_shard_count(self, analysis: Dict, current_shards: int, action: str) -> int:
        """Calculate optimal number of shards"""
        if action == "split":
            # Calculate how many shards we need based on load
            if analysis["max_utilization"] > 0:
                total_load = analysis["avg_utilization"] * current_shards
                target_shards = int(np.ceil(total_load / self.target_utilization))
                return min(self.max_shards, max(current_shards + 1, target_shards))
            else:
                return min(self.max_shards, current_shards * 2)
        
        elif action == "merge":
            # Calculate how few shards we can use
            if analysis["avg_utilization"] > 0:
                total_load = analysis["avg_utilization"] * current_shards
                target_shards = max(1, int(np.ceil(total_load / self.target_utilization)))
                return max(self.min_shards, target_shards)
            else:
                return max(self.min_shards, current_shards // 2)
        
        return current_shards
    
    def _get_split_reason(self, analysis: Dict) -> str:
        """Get reason for splitting shards"""
        reasons = []
        
        if analysis["overloaded_shards"] > 0:
            reasons.append(f"{analysis['overloaded_shards']} shard(s) overloaded")
        
        if analysis["max_utilization"] > self.max_utilization:
            reasons.append(f"Peak utilization {analysis['max_utilization']:.1%} exceeds threshold")
        
        if "network_congestion" in analysis["performance_issues"]:
            reasons.append("Network congestion detected")
        
        return "; ".join(reasons) if reasons else "Proactive scaling for better performance"
    
    def _get_merge_reason(self, analysis: Dict) -> str:
        """Get reason for merging shards"""
        reasons = []
        
        if analysis["underloaded_shards"] > 0:
            reasons.append(f"{analysis['underloaded_shards']} shard(s) underutilized")
        
        if analysis["avg_utilization"] < self.thresholds['merge_threshold']:
            reasons.append(f"Average utilization {analysis['avg_utilization']:.1%} below threshold")
        
        return "; ".join(reasons) if reasons else "Consolidation for efficiency"
    
    def _calculate_confidence(self, analysis: Dict, action: str) -> float:
        """Calculate confidence in the recommendation"""
        base_confidence = 0.7
        
        # Increase confidence based on clear indicators
        if action == "split":
            if analysis["overloaded_shards"] > 0:
                base_confidence += 0.2
            if analysis["max_utilization"] > 0.9:
                base_confidence += 0.1
        
        elif action == "merge":
            if analysis["underloaded_shards"] > analysis["current_shards"] // 2:
                base_confidence += 0.2
            if analysis["max_utilization"] < 0.4:
                base_confidence += 0.1
        
        elif action == "maintain":
            if 0.3 < analysis["avg_utilization"] < 0.8:
                base_confidence += 0.2
        
        # Decrease confidence for edge cases
        if analysis["utilization_variance"] > 0.2:
            base_confidence -= 0.1  # High variance makes prediction less reliable
        
        return min(1.0, max(0.1, base_confidence))
    
    def _get_priority(self, analysis: Dict) -> str:
        """Determine priority of the recommendation"""
        if "shard_overload" in analysis["performance_issues"]:
            return "high"
        elif analysis["max_utilization"] > 0.9 or analysis["avg_utilization"] < 0.2:
            return "medium"
        else:
            return "low"
    
    def _estimate_improvement(self, analysis: Dict, target_shards: int, action: str) -> Dict:
        """Estimate performance improvement from the recommendation"""
        current_shards = analysis["current_shards"]
        improvement = {}
        
        if action == "split":
            # Estimate reduction in utilization
            load_reduction = current_shards / target_shards
            improvement["utilization_reduction"] = f"{(1 - load_reduction) * 100:.1f}%"
            improvement["estimated_max_utilization"] = f"{analysis['max_utilization'] * load_reduction:.1%}"
            improvement["response_time_improvement"] = "20-40%"
            
        elif action == "merge":
            # Estimate increase in efficiency
            efficiency_gain = (current_shards - target_shards) / current_shards
            improvement["efficiency_gain"] = f"{efficiency_gain * 100:.1f}%"
            improvement["resource_savings"] = f"{efficiency_gain * 100:.1f}% validator resources"
            improvement["estimated_utilization"] = f"{analysis['avg_utilization'] * current_shards / target_shards:.1%}"
        
        return improvement
    
    def _create_implementation_plan(self, action: str, current_shards: int, target_shards: int) -> List[str]:
        """Create implementation plan for the recommendation"""
        plan = []
        
        if action == "split":
            shard_increase = target_shards - current_shards
            plan.extend([
                f"1. Prepare {shard_increase} new shard(s)",
                "2. Identify validators for new shards",
                "3. Gradually migrate transactions to balance load",
                "4. Monitor performance during transition",
                "5. Adjust if needed based on real performance"
            ])
        
        elif action == "merge":
            shards_to_remove = current_shards - target_shards
            plan.extend([
                f"1. Identify {shards_to_remove} shard(s) for consolidation",
                "2. Migrate transactions from target shards",
                "3. Redistribute validators",
                "4. Gradually reduce shard count",
                "5. Monitor for any performance degradation"
            ])
        
        return plan
    
    def optimize_shard_assignment(self, transactions: List[Dict], num_shards: int) -> Dict:
        """
        Optimize transaction assignment to shards
        
        Args:
            transactions: List of transaction data
            num_shards: Number of available shards
            
        Returns:
            Optimization results with shard assignments
        """
        try:
            if not transactions or num_shards <= 0:
                return {"error": "Invalid input parameters"}
            
            # Initialize shard loads
            shard_loads = [0.0] * num_shards
            shard_assignments = {}
            cross_shard_count = 0
            
            # Simple load balancing algorithm
            for i, tx in enumerate(transactions):
                tx_size = tx.get('size', 1.0)
                from_addr = tx.get('from', '')
                to_addr = tx.get('to', '')
                
                # Determine optimal shard based on address affinity and current load
                optimal_shard = self._find_optimal_shard(
                    from_addr, to_addr, shard_loads, tx_size
                )
                
                shard_assignments[i] = optimal_shard
                shard_loads[optimal_shard] += tx_size
                
                # Check if cross-shard transaction
                from_shard = hash(from_addr) % num_shards
                to_shard = hash(to_addr) % num_shards
                if from_shard != to_shard:
                    cross_shard_count += 1
            
            # Calculate metrics
            load_balance = np.std(shard_loads) / np.mean(shard_loads) if np.mean(shard_loads) > 0 else 0
            cross_shard_ratio = cross_shard_count / len(transactions)
            
            return {
                "shard_assignments": shard_assignments,
                "shard_loads": shard_loads,
                "load_balance_score": 1.0 / (1.0 + load_balance),  # Higher is better
                "cross_shard_ratio": cross_shard_ratio,
                "optimization_score": self._calculate_optimization_score(
                    load_balance, cross_shard_ratio
                ),
                "recommendations": self._generate_assignment_recommendations(
                    shard_loads, cross_shard_ratio
                )
            }
            
        except Exception as e:
            logger.error("Shard assignment optimization failed", error=str(e))
            return {"error": "Optimization failed"}
    
    def _find_optimal_shard(self, from_addr: str, to_addr: str, 
                           shard_loads: List[float], tx_size: float) -> int:
        """Find optimal shard for a transaction"""
        num_shards = len(shard_loads)
        
        # Calculate affinity scores for each shard
        scores = []
        for shard_id in range(num_shards):
            # Address affinity (prefer keeping related addresses together)
            affinity_score = 0.0
            if hash(from_addr) % num_shards == shard_id:
                affinity_score += 0.5
            if hash(to_addr) % num_shards == shard_id:
                affinity_score += 0.5
            
            # Load balancing score (prefer less loaded shards)
            max_load = max(shard_loads) if shard_loads else 1.0
            load_score = 1.0 - (shard_loads[shard_id] / max_load) if max_load > 0 else 1.0
            
            # Combined score
            total_score = affinity_score * 0.3 + load_score * 0.7
            scores.append(total_score)
        
        # Return shard with highest score
        return int(np.argmax(scores))
    
    def _calculate_optimization_score(self, load_balance: float, cross_shard_ratio: float) -> float:
        """Calculate overall optimization score"""
        load_score = 1.0 / (1.0 + load_balance)
        cross_shard_score = 1.0 - min(1.0, cross_shard_ratio / self.thresholds['max_cross_shard_ratio'])
        
        return (load_score * 0.6 + cross_shard_score * 0.4)
    
    def _generate_assignment_recommendations(self, shard_loads: List[float], 
                                           cross_shard_ratio: float) -> List[str]:
        """Generate recommendations for shard assignment optimization"""
        recommendations = []
        
        if np.std(shard_loads) / np.mean(shard_loads) > 0.3:
            recommendations.append("Improve load balancing across shards")
        
        if cross_shard_ratio > self.thresholds['max_cross_shard_ratio']:
            recommendations.append("Reduce cross-shard transactions through better address grouping")
        
        if max(shard_loads) > self.target_utilization * np.mean(shard_loads) * 2:
            recommendations.append("Consider splitting the most loaded shard")
        
        return recommendations
