"""
Pydantic models for API responses
"""

from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from enum import Enum


class PredictionConfidence(str, Enum):
    """Enum for prediction confidence levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class RiskLevel(str, Enum):
    """Enum for risk levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class GasFeeResponse(BaseModel):
    """Response model for gas fee prediction"""
    recommended_gas_fee: float = Field(..., ge=0, description="Recommended gas fee")
    confidence: Optional[PredictionConfidence] = Field(None, description="Prediction confidence")
    reasoning: Optional[str] = Field(None, description="Explanation for the recommendation")
    alternative_fees: Optional[Dict[str, float]] = Field(None, description="Alternative fee options")
    market_conditions: Optional[Dict[str, Any]] = Field(None, description="Current market conditions")
    
    class Config:
        schema_extra = {
            "example": {
                "recommended_gas_fee": 0.0025,
                "confidence": "high",
                "reasoning": "High network load and mempool congestion",
                "alternative_fees": {
                    "slow": 0.001,
                    "standard": 0.0025,
                    "fast": 0.005
                },
                "market_conditions": {
                    "network_load": 0.75,
                    "congestion_level": "medium"
                }
            }
        }


class TxFraudResponse(BaseModel):
    """Response model for transaction fraud detection"""
    is_suspicious: bool = Field(..., description="Whether transaction is suspicious")
    risk_score: Optional[float] = Field(None, ge=0.0, le=1.0, description="Risk score (0-1)")
    risk_factors: Optional[List[str]] = Field(None, description="Identified risk factors")
    confidence: Optional[PredictionConfidence] = Field(None, description="Detection confidence")
    recommendations: Optional[List[str]] = Field(None, description="Security recommendations")
    
    class Config:
        schema_extra = {
            "example": {
                "is_suspicious": True,
                "risk_score": 0.85,
                "risk_factors": ["large_amount", "rapid_fire", "gas_anomaly"],
                "confidence": "high",
                "recommendations": [
                    "Manual review recommended",
                    "Consider additional verification"
                ]
            }
        }


class ValidatorScoreResponse(BaseModel):
    """Response model for validator scoring"""
    score: float = Field(..., ge=0.0, le=1.0, description="Validator score (0-1)")
    grade: Optional[str] = Field(None, description="Letter grade (A-F)")
    component_scores: Optional[Dict[str, float]] = Field(None, description="Individual component scores")
    strengths: Optional[List[str]] = Field(None, description="Validator strengths")
    weaknesses: Optional[List[str]] = Field(None, description="Areas for improvement")
    risk_level: Optional[RiskLevel] = Field(None, description="Overall risk level")
    recommendations: Optional[List[str]] = Field(None, description="Improvement recommendations")
    
    class Config:
        schema_extra = {
            "example": {
                "score": 0.87,
                "grade": "B+",
                "component_scores": {
                    "uptime": 0.95,
                    "reliability": 0.90,
                    "performance": 0.85,
                    "security": 1.0,
                    "stake_health": 0.75,
                    "experience": 0.80,
                    "community": 0.70
                },
                "strengths": ["uptime", "security", "reliability"],
                "weaknesses": ["community", "stake_health"],
                "risk_level": "low",
                "recommendations": [
                    "Engage more with community",
                    "Consider increasing stake amount"
                ]
            }
        }


class ShardingResponse(BaseModel):
    """Response model for sharding optimization"""
    split: bool = Field(..., description="Whether to split shards")
    target_shards: int = Field(..., gt=0, description="Recommended number of shards")
    action: Optional[str] = Field(None, description="Recommended action (split/merge/maintain)")
    reason: Optional[str] = Field(None, description="Reason for recommendation")
    confidence: Optional[float] = Field(None, ge=0.0, le=1.0, description="Recommendation confidence")
    priority: Optional[str] = Field(None, description="Implementation priority")
    estimated_improvement: Optional[Dict[str, str]] = Field(None, description="Expected improvements")
    implementation_plan: Optional[List[str]] = Field(None, description="Implementation steps")
    current_analysis: Optional[Dict[str, Any]] = Field(None, description="Current performance analysis")
    
    class Config:
        schema_extra = {
            "example": {
                "split": True,
                "target_shards": 6,
                "action": "split",
                "reason": "2 shard(s) overloaded; Peak utilization 91.0% exceeds threshold",
                "confidence": 0.9,
                "priority": "high",
                "estimated_improvement": {
                    "utilization_reduction": "33.3%",
                    "estimated_max_utilization": "60.7%",
                    "response_time_improvement": "20-40%"
                },
                "implementation_plan": [
                    "1. Prepare 2 new shard(s)",
                    "2. Identify validators for new shards",
                    "3. Gradually migrate transactions to balance load",
                    "4. Monitor performance during transition",
                    "5. Adjust if needed based on real performance"
                ]
            }
        }


class ModelStatusResponse(BaseModel):
    """Response model for model status"""
    status: str = Field(..., description="Overall status")
    models: Dict[str, Dict[str, Any]] = Field(..., description="Individual model statuses")
    last_updated: Optional[datetime] = Field(None, description="Last update timestamp")
    performance_metrics: Optional[Dict[str, float]] = Field(None, description="Performance metrics")
    
    class Config:
        schema_extra = {
            "example": {
                "status": "healthy",
                "models": {
                    "gas_optimizer": {
                        "loaded": True,
                        "model_type": "RandomForestRegressor",
                        "version": "1.0",
                        "accuracy": 0.92
                    },
                    "fraud_detector": {
                        "loaded": True,
                        "model_type": "IsolationForest",
                        "version": "1.0",
                        "precision": 0.89
                    }
                }
            }
        }


class MetricsResponse(BaseModel):
    """Response model for AI service metrics"""
    total_requests: int = Field(..., ge=0, description="Total number of requests")
    error_count: int = Field(..., ge=0, description="Total number of errors")
    average_response_time: Optional[float] = Field(None, ge=0, description="Average response time in ms")
    endpoints: Dict[str, Dict[str, int]] = Field(..., description="Per-endpoint metrics")
    uptime: Optional[float] = Field(None, ge=0, description="Service uptime in hours")
    
    class Config:
        schema_extra = {
            "example": {
                "total_requests": 1542,
                "error_count": 23,
                "average_response_time": 125.5,
                "endpoints": {
                    "gas_fee": {
                        "success_count": 450,
                        "error_count": 5
                    },
                    "tx_fraud": {
                        "success_count": 380,
                        "error_count": 8
                    }
                },
                "uptime": 168.5
            }
        }


class BatchPredictionResponse(BaseModel):
    """Response model for batch predictions"""
    predictions: List[Dict[str, Any]] = Field(..., description="Batch prediction results")
    success_count: int = Field(..., ge=0, description="Number of successful predictions")
    error_count: int = Field(..., ge=0, description="Number of failed predictions")
    processing_time: Optional[float] = Field(None, ge=0, description="Total processing time in seconds")
    
    class Config:
        schema_extra = {
            "example": {
                "predictions": [
                    {"index": 0, "result": {"is_suspicious": False, "risk_score": 0.15}},
                    {"index": 1, "result": {"is_suspicious": True, "risk_score": 0.82}}
                ],
                "success_count": 2,
                "error_count": 0,
                "processing_time": 0.045
            }
        }


class HealthCheckResponse(BaseModel):
    """Response model for health checks"""
    status: str = Field(..., description="Overall health status")
    timestamp: datetime = Field(..., description="Health check timestamp")
    checks: Dict[str, Dict[str, Any]] = Field(..., description="Individual health checks")
    uptime: Optional[float] = Field(None, ge=0, description="Service uptime in seconds")
    version: Optional[str] = Field(None, description="Service version")
    
    class Config:
        schema_extra = {
            "example": {
                "status": "healthy",
                "timestamp": "2024-01-15T10:30:00Z",
                "checks": {
                    "models": {
                        "status": "healthy",
                        "loaded_models": 4,
                        "failed_models": 0
                    },
                    "database": {
                        "status": "healthy",
                        "connection": True,
                        "latency_ms": 2.5
                    }
                },
                "uptime": 3600.0,
                "version": "1.0.0"
            }
        }


class ErrorResponse(BaseModel):
    """Response model for errors"""
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[str] = Field(None, description="Additional error details")
    timestamp: datetime = Field(default_factory=datetime.now, description="Error timestamp")
    request_id: Optional[str] = Field(None, description="Request ID for tracking")
    
    class Config:
        schema_extra = {
            "example": {
                "error": "ValidationError",
                "message": "Invalid input parameters",
                "details": "network_load must be between 0 and 1",
                "timestamp": "2024-01-15T10:30:00Z",
                "request_id": "req_123456789"
            }
        }


class AnalysisResponse(BaseModel):
    """Response model for detailed analysis"""
    analysis_type: str = Field(..., description="Type of analysis performed")
    results: Dict[str, Any] = Field(..., description="Analysis results")
    insights: List[str] = Field(..., description="Key insights")
    recommendations: List[str] = Field(..., description="Actionable recommendations")
    confidence: Optional[float] = Field(None, ge=0.0, le=1.0, description="Analysis confidence")
    
    class Config:
        schema_extra = {
            "example": {
                "analysis_type": "transaction_pattern",
                "results": {
                    "risk_score": 0.3,
                    "patterns": ["high_frequency"],
                    "statistics": {
                        "total_transactions": 150,
                        "avg_amount": 500.0
                    }
                },
                "insights": [
                    "High transaction frequency detected",
                    "Consistent transaction amounts"
                ],
                "recommendations": [
                    "Monitor for automated trading patterns",
                    "Consider rate limiting"
                ],
                "confidence": 0.85
            }
        }
