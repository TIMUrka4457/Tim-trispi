"""
Pydantic models for API requests
"""

from pydantic import BaseModel, Field, validator
from typing import Dict, List, Optional, Any
from datetime import datetime


class GasFeeRequest(BaseModel):
    """Request model for gas fee prediction"""
    network_load: float = Field(..., ge=0.0, le=1.0, description="Network load ratio (0-1)")
    tx_count: int = Field(..., ge=0, description="Number of pending transactions")
    avg_tps: float = Field(..., ge=0, description="Average transactions per second")
    block_time: int = Field(..., gt=0, description="Block time in seconds")
    mempool_size: int = Field(..., ge=0, description="Size of mempool")
    
    @validator('network_load')
    def validate_network_load(cls, v):
        if not 0.0 <= v <= 1.0:
            raise ValueError('network_load must be between 0 and 1')
        return v
    
    @validator('avg_tps')
    def validate_avg_tps(cls, v):
        if v < 0:
            raise ValueError('avg_tps must be non-negative')
        return v

    class Config:
        schema_extra = {
            "example": {
                "network_load": 0.75,
                "tx_count": 150,
                "avg_tps": 1200.0,
                "block_time": 12,
                "mempool_size": 42
            }
        }


class TxFraudRequest(BaseModel):
    """Request model for transaction fraud detection"""
    tx_features: List[float] = Field(..., min_items=1, description="Transaction features for analysis")
    transaction_id: Optional[str] = Field(None, description="Transaction ID for tracking")
    additional_context: Optional[Dict[str, Any]] = Field(None, description="Additional context")
    
    @validator('tx_features')
    def validate_tx_features(cls, v):
        if not v:
            raise ValueError('tx_features cannot be empty')
        if any(not isinstance(x, (int, float)) for x in v):
            raise ValueError('All tx_features must be numeric')
        if any(x < 0 for x in v[:2]):  # First two features (amount, gas_fee) should be non-negative
            raise ValueError('Amount and gas_fee must be non-negative')
        return v

    class Config:
        schema_extra = {
            "example": {
                "tx_features": [1000.0, 0.001, 300.0, 50000.0, 25000.0, 2.0, 3.33, 0.000001],
                "transaction_id": "0x1234567890abcdef",
                "additional_context": {"sender_reputation": 0.8}
            }
        }


class ValidatorScoreRequest(BaseModel):
    """Request model for validator scoring"""
    uptime: float = Field(..., ge=0.0, le=1.0, description="Validator uptime ratio (0-1)")
    response_time: float = Field(..., ge=0, description="Average response time in milliseconds")
    missed_blocks: int = Field(..., ge=0, description="Number of missed blocks")
    slashing_events: int = Field(..., ge=0, description="Number of slashing events")
    reports: int = Field(..., ge=0, description="Number of reports against validator")
    
    # Optional additional metrics
    blocks_produced: Optional[int] = Field(0, ge=0, description="Total blocks produced")
    rewards_earned: Optional[float] = Field(0.0, ge=0, description="Total rewards earned")
    stake_amount: Optional[float] = Field(0.0, ge=0, description="Validator stake amount")
    delegator_count: Optional[int] = Field(0, ge=0, description="Number of delegators")
    commission_rate: Optional[float] = Field(0.0, ge=0.0, le=1.0, description="Commission rate (0-1)")
    age_days: Optional[int] = Field(0, ge=0, description="Validator age in days")
    
    @validator('uptime')
    def validate_uptime(cls, v):
        if not 0.0 <= v <= 1.0:
            raise ValueError('uptime must be between 0 and 1')
        return v
    
    @validator('commission_rate')
    def validate_commission_rate(cls, v):
        if v is not None and not 0.0 <= v <= 1.0:
            raise ValueError('commission_rate must be between 0 and 1')
        return v

    class Config:
        schema_extra = {
            "example": {
                "uptime": 0.99,
                "response_time": 150.0,
                "missed_blocks": 2,
                "slashing_events": 0,
                "reports": 0,
                "blocks_produced": 1000,
                "rewards_earned": 500.0,
                "stake_amount": 10000.0,
                "delegator_count": 25,
                "commission_rate": 0.05,
                "age_days": 180
            }
        }


class ShardingRequest(BaseModel):
    """Request model for sharding optimization"""
    network_stats: Dict[str, float] = Field(..., description="Network statistics")
    tx_heatmap: List[float] = Field(..., min_items=1, description="Transaction load per shard (0-1)")
    
    # Optional context
    current_validators: Optional[List[int]] = Field(None, description="Validators per shard")
    target_tps: Optional[float] = Field(None, ge=0, description="Target TPS")
    max_shards: Optional[int] = Field(None, gt=0, le=128, description="Maximum allowed shards")
    
    @validator('tx_heatmap')
    def validate_tx_heatmap(cls, v):
        if not v:
            raise ValueError('tx_heatmap cannot be empty')
        if any(not isinstance(x, (int, float)) for x in v):
            raise ValueError('All tx_heatmap values must be numeric')
        if any(x < 0 or x > 1 for x in v):
            raise ValueError('tx_heatmap values must be between 0 and 1')
        return v
    
    @validator('network_stats')
    def validate_network_stats(cls, v):
        required_keys = ['total_tps', 'network_congestion']
        for key in required_keys:
            if key not in v:
                raise ValueError(f'network_stats must contain {key}')
        return v

    class Config:
        schema_extra = {
            "example": {
                "network_stats": {
                    "total_tps": 2500.0,
                    "network_congestion": 0.75,
                    "cross_shard_ratio": 0.15,
                    "avg_response_time": 200.0
                },
                "tx_heatmap": [0.85, 0.65, 0.90, 0.45],
                "current_validators": [10, 8, 12, 6],
                "target_tps": 5000.0,
                "max_shards": 16
            }
        }


class ModelUpdateRequest(BaseModel):
    """Request model for updating AI models with new data"""
    model_type: str = Field(..., description="Type of model to update")
    training_data: List[Dict[str, Any]] = Field(..., min_items=1, description="New training data")
    validation_split: Optional[float] = Field(0.2, ge=0.0, le=0.5, description="Validation split ratio")
    
    @validator('model_type')
    def validate_model_type(cls, v):
        allowed_types = ['gas_fee', 'fraud_detection', 'validator_score', 'sharding']
        if v not in allowed_types:
            raise ValueError(f'model_type must be one of {allowed_types}')
        return v

    class Config:
        schema_extra = {
            "example": {
                "model_type": "gas_fee",
                "training_data": [
                    {
                        "features": [0.8, 100, 1500.0, 12, 25],
                        "target": 0.002
                    }
                ],
                "validation_split": 0.2
            }
        }


class BatchPredictionRequest(BaseModel):
    """Request model for batch predictions"""
    model_type: str = Field(..., description="Type of model for prediction")
    batch_data: List[Dict[str, Any]] = Field(..., min_items=1, description="Batch of data for prediction")
    
    @validator('model_type')
    def validate_model_type(cls, v):
        allowed_types = ['gas_fee', 'fraud_detection', 'validator_score', 'sharding']
        if v not in allowed_types:
            raise ValueError(f'model_type must be one of {allowed_types}')
        return v

    class Config:
        schema_extra = {
            "example": {
                "model_type": "fraud_detection",
                "batch_data": [
                    {"tx_features": [1000.0, 0.001, 300.0, 50000.0]},
                    {"tx_features": [50.0, 0.005, 60.0, 25000.0]}
                ]
            }
        }


class HealthCheckRequest(BaseModel):
    """Request model for health checks"""
    check_models: bool = Field(True, description="Whether to check model health")
    check_database: bool = Field(True, description="Whether to check database health")
    detailed: bool = Field(False, description="Whether to return detailed health info")

    class Config:
        schema_extra = {
            "example": {
                "check_models": True,
                "check_database": True,
                "detailed": False
            }
        }
