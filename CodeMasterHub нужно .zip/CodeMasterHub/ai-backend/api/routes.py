from fastapi import APIRouter, HTTPException, Depends
from typing import List, Dict, Any
import logging
from pydantic import BaseModel, Field

from models.gas_optimizer import GasFeeOptimizer
from models.fraud_detector import TransactionFraudDetector
from models.validator_scorer import ValidatorScorer, ValidatorMetrics
from models.sharding_optimizer import ShardingOptimizer, ShardMetrics, NetworkStats

logger = logging.getLogger(__name__)

# Initialize AI models
gas_optimizer = GasFeeOptimizer()
fraud_detector = TransactionFraudDetector()
validator_scorer = ValidatorScorer()
sharding_optimizer = ShardingOptimizer()

router = APIRouter()

# Pydantic models for request/response validation

class GasFeeRequest(BaseModel):
    network_load: float = Field(..., ge=0.0, le=1.0, description="Network load percentage")
    tx_count: int = Field(..., ge=0, description="Number of pending transactions")
    avg_tps: float = Field(..., ge=0, description="Average transactions per second")
    block_time: int = Field(..., ge=1, description="Block time in seconds")
    mempool_size: int = Field(..., ge=0, description="Mempool size")

class GasFeeResponse(BaseModel):
    recommended_gas_fee: float
    fee_modes: Dict[str, float]
    confidence: float
    reasoning: str

class FraudDetectionRequest(BaseModel):
    transaction_data: str = Field(..., description="Transaction data as JSON string")
    sender_history: List[str] = Field(default=[], description="Sender transaction history")
    network_patterns: Dict[str, Any] = Field(default={}, description="Network patterns data")

class FraudDetectionResponse(BaseModel):
    is_safe: bool
    risk_score: float
    reasons: List[str]
    confidence: float

class ValidatorSelectionRequest(BaseModel):
    validators: List[Dict[str, Any]] = Field(..., description="List of validators with their metrics")
    network_stats: Dict[str, Any] = Field(default={}, description="Current network statistics")

class ValidatorSelectionResponse(BaseModel):
    selected_validator: str
    confidence: float
    reasoning: str
    alternatives: List[str]

class ValidatorScoreRequest(BaseModel):
    uptime: float = Field(..., ge=0.0, le=1.0)
    response_time: float = Field(..., ge=0)
    missed_blocks: int = Field(..., ge=0)
    slashing_events: int = Field(..., ge=0)
    reports: int = Field(..., ge=0)
    stake_amount: float = Field(default=1000, ge=0)
    validator_age: int = Field(default=30, ge=0)
    successful_proposals: int = Field(default=0, ge=0)
    total_proposals: int = Field(default=0, ge=0)

class ShardingAnalysisRequest(BaseModel):
    shard_metrics: List[Dict[str, Any]]
    network_stats: Dict[str, Any]

class BlockValidationRequest(BaseModel):
    index: int
    transaction_count: int
    validator: str
    gas_fee: float
    timestamp: int

class NetworkOptimizationRequest(BaseModel):
    peer_count: int
    message_rate: float
    latency: float
    network_stats: Dict[str, Any]

# Gas Fee Optimization Endpoints

@router.post("/gas_fee", response_model=GasFeeResponse)
async def optimize_gas_fee(request: GasFeeRequest):
    """Get AI-optimized gas fee recommendation"""
    try:
        logger.info(f"🧠 Gas fee optimization request: load={request.network_load}, tx_count={request.tx_count}")
        
        # Get base recommendation
        recommended_fee = gas_optimizer.predict_gas_fee(
            network_load=request.network_load,
            tx_count=request.tx_count,
            avg_tps=request.avg_tps,
            block_time=request.block_time,
            mempool_size=request.mempool_size
        )
        
        # Get different fee modes
        network_stats = {
            "network_load": request.network_load,
            "tx_count": request.tx_count,
            "avg_tps": request.avg_tps,
            "block_time": request.block_time,
            "mempool_size": request.mempool_size
        }
        
        fee_modes = gas_optimizer.get_fee_recommendations(network_stats)
        
        # Calculate confidence based on network conditions
        confidence = 0.9 if request.network_load < 0.8 else 0.7
        
        reasoning = f"Based on {request.network_load:.1%} network load and {request.tx_count} pending transactions"
        
        return GasFeeResponse(
            recommended_gas_fee=recommended_fee,
            fee_modes=fee_modes,
            confidence=confidence,
            reasoning=reasoning
        )
        
    except Exception as e:
        logger.error(f"Gas fee optimization error: {e}")
        raise HTTPException(status_code=500, detail=f"Gas fee optimization failed: {str(e)}")

# Fraud Detection Endpoints

@router.post("/fraud_detection", response_model=FraudDetectionResponse)
async def detect_fraud(request: FraudDetectionRequest):
    """Detect potential fraud in transactions"""
    try:
        logger.info("🔍 Fraud detection request received")
        
        is_suspicious, risk_score, reasons = fraud_detector.is_transaction_suspicious(
            transaction_data=request.transaction_data,
            sender_history=request.sender_history
        )
        
        confidence = 0.85 if len(request.sender_history) > 10 else 0.7
        
        return FraudDetectionResponse(
            is_safe=not is_suspicious,
            risk_score=risk_score,
            reasons=reasons,
            confidence=confidence
        )
        
    except Exception as e:
        logger.error(f"Fraud detection error: {e}")
        raise HTTPException(status_code=500, detail=f"Fraud detection failed: {str(e)}")

# Validator Selection and Scoring Endpoints

@router.post("/validator_selection", response_model=ValidatorSelectionResponse)
async def select_validator(request: ValidatorSelectionRequest):
    """AI-powered validator selection"""
    try:
        logger.info(f"🎯 Validator selection for {len(request.validators)} validators")
        
        # Convert request data to ValidatorMetrics objects
        validator_metrics = []
        for validator_data in request.validators:
            validator_id = validator_data.get("id", "unknown")
            
            metrics = ValidatorMetrics(
                uptime=validator_data.get("uptime", 0.9),
                response_time=validator_data.get("response_time", 100),
                missed_blocks=validator_data.get("missed_blocks", 0),
                slashing_events=validator_data.get("slashing_events", 0),
                reports=validator_data.get("reports", 0),
                stake_amount=validator_data.get("stake_amount", 1000),
                validator_age=validator_data.get("validator_age", 30),
                successful_proposals=validator_data.get("successful_proposals", 0),
                total_proposals=validator_data.get("total_proposals", 0)
            )
            
            validator_metrics.append((validator_id, metrics))
        
        # Get AI recommendation
        recommendation = validator_scorer.get_validator_selection_recommendation(validator_metrics)
        
        if not recommendation.get("recommended_validator"):
            raise HTTPException(status_code=400, detail="No suitable validators found")
        
        return ValidatorSelectionResponse(
            selected_validator=recommendation["recommended_validator"],
            confidence=recommendation.get("confidence", 0.8),
            reasoning=recommendation.get("reason", "AI-optimized selection"),
            alternatives=recommendation.get("alternatives", [])
        )
        
    except Exception as e:
        logger.error(f"Validator selection error: {e}")
        raise HTTPException(status_code=500, detail=f"Validator selection failed: {str(e)}")

@router.post("/validator_score")
async def score_validator(request: ValidatorScoreRequest):
    """Calculate comprehensive validator score"""
    try:
        logger.info("📊 Validator scoring request")
        
        metrics = ValidatorMetrics(
            uptime=request.uptime,
            response_time=request.response_time,
            missed_blocks=request.missed_blocks,
            slashing_events=request.slashing_events,
            reports=request.reports,
            stake_amount=request.stake_amount,
            validator_age=request.validator_age,
            successful_proposals=request.successful_proposals,
            total_proposals=request.total_proposals
        )
        
        score_result = validator_scorer.calculate_comprehensive_score(metrics)
        
        return {
            "score": score_result["total_score"],
            "grade": score_result["grade"],
            "category_scores": score_result["category_scores"],
            "recommendations": score_result["recommendations"],
            "risk_factors": score_result["risk_factors"],
            "confidence": score_result["ai_confidence"]
        }
        
    except Exception as e:
        logger.error(f"Validator scoring error: {e}")
        raise HTTPException(status_code=500, detail=f"Validator scoring failed: {str(e)}")

# Sharding Optimization Endpoints

@router.post("/sharding")
async def optimize_sharding(request: ShardingAnalysisRequest):
    """Get sharding optimization recommendations"""
    try:
        logger.info("🔀 Sharding optimization request")
        
        # Convert request data to ShardMetrics objects
        shard_metrics = []
        for shard_data in request.shard_metrics:
            metrics = ShardMetrics(
                shard_id=shard_data.get("shard_id", 0),
                transaction_count=shard_data.get("transaction_count", 0),
                avg_transaction_size=shard_data.get("avg_transaction_size", 100.0),
                processing_time=shard_data.get("processing_time", 100.0),
                storage_usage=shard_data.get("storage_usage", 1000.0),
                network_latency=shard_data.get("network_latency", 50.0),
                error_rate=shard_data.get("error_rate", 0.001),
                capacity_utilization=shard_data.get("capacity_utilization", 0.5)
            )
            shard_metrics.append(metrics)
        
        # Convert network stats
        network_stats = NetworkStats(
            total_transactions=request.network_stats.get("total_transactions", 1000),
            avg_block_time=request.network_stats.get("avg_block_time", 10.0),
            network_congestion=request.network_stats.get("network_congestion", 0.5),
            cross_shard_ratio=request.network_stats.get("cross_shard_ratio", 0.2),
            storage_growth_rate=request.network_stats.get("storage_growth_rate", 0.1)
        )
        
        # Get recommendations
        recommendations = sharding_optimizer.recommend_sharding_changes(shard_metrics, network_stats)
        
        return recommendations
        
    except Exception as e:
        logger.error(f"Sharding optimization error: {e}")
        raise HTTPException(status_code=500, detail=f"Sharding optimization failed: {str(e)}")

# Block Validation Endpoints

@router.post("/block_validation")
async def validate_block(request: BlockValidationRequest):
    """AI-powered block validation"""
    try:
        logger.info(f"✅ Block validation request for block #{request.index}")
        
        # AI validation logic
        is_valid = True
        confidence = 0.9
        reasons = []
        
        # Check transaction count reasonableness
        if request.transaction_count > 10000:
            is_valid = False
            reasons.append("Unusually high transaction count")
            confidence = 0.95
        
        # Check gas fee reasonableness
        if request.gas_fee > 100 or request.gas_fee < 0.001:
            is_valid = False
            reasons.append("Gas fee outside reasonable range")
            confidence = 0.9
        
        # Check timestamp (not too far in future/past)
        import time
        current_time = int(time.time())
        if abs(request.timestamp - current_time) > 3600:  # 1 hour tolerance
            is_valid = False
            reasons.append("Block timestamp too far from current time")
            confidence = 0.85
        
        if is_valid:
            reasons.append("Block passes AI validation checks")
        
        return {
            "is_valid": is_valid,
            "confidence": confidence,
            "reasons": reasons,
            "recommendation": "accept" if is_valid else "reject"
        }
        
    except Exception as e:
        logger.error(f"Block validation error: {e}")
        raise HTTPException(status_code=500, detail=f"Block validation failed: {str(e)}")

# Network Optimization Endpoints

@router.post("/network_optimization")
async def optimize_network(request: NetworkOptimizationRequest):
    """Network performance optimization recommendations"""
    try:
        logger.info("🌐 Network optimization request")
        
        optimal_peer_count = min(50, max(8, request.peer_count))
        recommended_ttl = 300  # 5 minutes default TTL
        
        # Analyze current performance
        if request.latency > 1000:  # High latency
            priority = "reduce_latency"
            optimal_peer_count = min(20, request.peer_count)
        elif request.message_rate > 1000:  # High message rate
            priority = "optimize_bandwidth"
            recommended_ttl = 180
        else:
            priority = "maintain_performance"
        
        confidence = 0.8
        
        return {
            "optimal_peer_count": optimal_peer_count,
            "recommended_ttl": recommended_ttl,
            "priority": priority,
            "confidence": confidence,
            "recommendations": [
                f"Maintain {optimal_peer_count} optimal peer connections",
                f"Set message TTL to {recommended_ttl} seconds",
                f"Focus on {priority.replace('_', ' ')}"
            ]
        }
        
    except Exception as e:
        logger.error(f"Network optimization error: {e}")
        raise HTTPException(status_code=500, detail=f"Network optimization failed: {str(e)}")

@router.post("/network_anomaly")
async def detect_network_anomaly(network_data: Dict[str, Any]):
    """Detect network anomalies"""
    try:
        logger.info("🚨 Network anomaly detection")
        
        is_anomalous = False
        anomaly_score = 0.0
        detected_anomalies = []
        
        # Check for unusual patterns
        peer_count = network_data.get("peer_count", 0)
        message_rate = network_data.get("message_rate", 0)
        error_rate = network_data.get("error_rate", 0)
        
        if peer_count > 1000:  # Too many peers
            is_anomalous = True
            anomaly_score += 0.3
            detected_anomalies.append("Unusually high peer count")
        
        if message_rate > 10000:  # Message flooding
            is_anomalous = True
            anomaly_score += 0.4
            detected_anomalies.append("Potential message flooding attack")
        
        if error_rate > 0.1:  # High error rate
            is_anomalous = True
            anomaly_score += 0.5
            detected_anomalies.append("High network error rate")
        
        return {
            "is_anomalous": is_anomalous,
            "anomaly_score": min(1.0, anomaly_score),
            "detected_anomalies": detected_anomalies,
            "severity": "high" if anomaly_score > 0.7 else "medium" if anomaly_score > 0.3 else "low"
        }
        
    except Exception as e:
        logger.error(f"Network anomaly detection error: {e}")
        raise HTTPException(status_code=500, detail=f"Network anomaly detection failed: {str(e)}")

# Health and Status Endpoints

@router.get("/health")
async def health_check():
    """AI backend health check"""
    return {
        "status": "healthy",
        "models": {
            "gas_optimizer": gas_optimizer.is_trained,
            "fraud_detector": fraud_detector.is_trained,
            "validator_scorer": True,
            "sharding_optimizer": True
        },
        "timestamp": "2025-01-02T12:00:00Z"
    }

@router.get("/metrics")
async def get_metrics():
    """Get AI model performance metrics"""
    return {
        "gas_optimizer": {
            "trained": gas_optimizer.is_trained,
            "model_type": "RandomForestRegressor"
        },
        "fraud_detector": {
            "trained": fraud_detector.is_trained,
            "model_type": "IsolationForest",
            "suspicious_addresses": len(fraud_detector.suspicious_addresses)
        },
        "validator_scorer": {
            "active": True,
            "scoring_weights": validator_scorer.performance_weights
        },
        "sharding_optimizer": {
            "active": True,
            "max_shards": sharding_optimizer.max_shards,
            "min_shards": sharding_optimizer.min_shards
        }
    }
