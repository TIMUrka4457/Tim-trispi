import numpy as np
import logging
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import json

logger = logging.getLogger(__name__)

@dataclass
class ShardMetrics:
    shard_id: int
    transaction_count: int
    avg_transaction_size: float
    processing_time: float
    storage_usage: float
    network_latency: float
    error_rate: float
    capacity_utilization: float

@dataclass
class NetworkStats:
    total_transactions: int
    avg_block_time: float
    network_congestion: float
    cross_shard_ratio: float
    storage_growth_rate: float

class ShardingOptimizer:
    def __init__(self):
        self.optimal_shard_size = 1000  # Optimal transactions per shard
        self.max_shards = 64
        self.min_shards = 2
        self.split_threshold = 0.8  # Utilization threshold for splitting
        self.merge_threshold = 0.3  # Utilization threshold for merging
        self.historical_data = []
        
        # ML model weights for optimization
        self.optimization_weights = {
            'transaction_load': 0.3,
            'storage_efficiency': 0.25,
            'network_latency': 0.2,
            'cross_shard_overhead': 0.15,
            'maintenance_cost': 0.1
        }

    def analyze_current_sharding(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> Dict:
        """Analyze current sharding configuration and performance"""
        try:
            if not shard_metrics:
                return self._get_default_analysis()
            
            analysis = {
                'total_shards': len(shard_metrics),
                'total_transactions': sum(s.transaction_count for s in shard_metrics),
                'avg_utilization': np.mean([s.capacity_utilization for s in shard_metrics]),
                'utilization_variance': np.var([s.capacity_utilization for s in shard_metrics]),
                'bottlenecks': self._identify_bottlenecks(shard_metrics),
                'efficiency_score': self._calculate_efficiency_score(shard_metrics, network_stats),
                'performance_metrics': self._calculate_performance_metrics(shard_metrics)
            }
            
            # Identify problems
            analysis['issues'] = self._identify_issues(shard_metrics, network_stats)
            
            # Calculate optimization potential
            analysis['optimization_potential'] = self._calculate_optimization_potential(analysis)
            
            logger.info(f"📊 Sharding analysis: {analysis['total_shards']} shards, {analysis['efficiency_score']:.2f} efficiency")
            
            return analysis
            
        except Exception as e:
            logger.error(f"Sharding analysis error: {e}")
            return self._get_default_analysis()

    def recommend_sharding_changes(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> Dict:
        """Recommend optimal sharding configuration changes"""
        try:
            current_analysis = self.analyze_current_sharding(shard_metrics, network_stats)
            
            recommendations = {
                'action': 'maintain',
                'target_shards': len(shard_metrics),
                'changes': [],
                'expected_improvement': 0.0,
                'confidence': 0.8,
                'reasoning': []
            }
            
            # Analyze if we need more shards (splitting)
            split_recommendation = self._analyze_split_needs(shard_metrics, network_stats)
            if split_recommendation['should_split']:
                recommendations.update(split_recommendation)
            
            # Analyze if we can reduce shards (merging)
            elif self._should_merge_shards(shard_metrics, network_stats):
                merge_recommendation = self._analyze_merge_opportunities(shard_metrics, network_stats)
                recommendations.update(merge_recommendation)
            
            # Analyze rebalancing needs
            else:
                rebalance_recommendation = self._analyze_rebalance_needs(shard_metrics, network_stats)
                if rebalance_recommendation['should_rebalance']:
                    recommendations.update(rebalance_recommendation)
            
            # Add cost-benefit analysis
            recommendations['cost_benefit'] = self._calculate_cost_benefit(
                current_analysis, recommendations
            )
            
            logger.info(f"🎯 Sharding recommendation: {recommendations['action']} -> {recommendations['target_shards']} shards")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Sharding recommendation error: {e}")
            return self._get_default_recommendation()

    def _identify_bottlenecks(self, shard_metrics: List[ShardMetrics]) -> List[Dict]:
        """Identify performance bottlenecks in current sharding"""
        bottlenecks = []
        
        for shard in shard_metrics:
            issues = []
            
            if shard.capacity_utilization > self.split_threshold:
                issues.append("High capacity utilization")
            
            if shard.processing_time > 1000:  # ms
                issues.append("Slow processing time")
            
            if shard.error_rate > 0.01:  # 1%
                issues.append("High error rate")
            
            if shard.network_latency > 200:  # ms
                issues.append("High network latency")
            
            if issues:
                bottlenecks.append({
                    'shard_id': shard.shard_id,
                    'issues': issues,
                    'severity': len(issues)
                })
        
        return sorted(bottlenecks, key=lambda x: x['severity'], reverse=True)

    def _calculate_efficiency_score(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> float:
        """Calculate overall sharding efficiency score (0-1)"""
        if not shard_metrics:
            return 0.5
        
        # Utilization efficiency (balanced utilization is better)
        utilizations = [s.capacity_utilization for s in shard_metrics]
        utilization_score = 1 - np.var(utilizations)  # Lower variance is better
        utilization_score = max(0, min(1, utilization_score))
        
        # Performance efficiency
        avg_processing_time = np.mean([s.processing_time for s in shard_metrics])
        performance_score = max(0, min(1, (2000 - avg_processing_time) / 2000))
        
        # Error rate efficiency
        avg_error_rate = np.mean([s.error_rate for s in shard_metrics])
        error_score = max(0, min(1, 1 - avg_error_rate * 100))
        
        # Network efficiency
        avg_latency = np.mean([s.network_latency for s in shard_metrics])
        network_score = max(0, min(1, (500 - avg_latency) / 500))
        
        # Weighted combination
        efficiency = (
            utilization_score * 0.3 +
            performance_score * 0.3 +
            error_score * 0.2 +
            network_score * 0.2
        )
        
        return efficiency

    def _calculate_performance_metrics(self, shard_metrics: List[ShardMetrics]) -> Dict:
        """Calculate detailed performance metrics"""
        if not shard_metrics:
            return {}
        
        return {
            'avg_processing_time': np.mean([s.processing_time for s in shard_metrics]),
            'max_processing_time': np.max([s.processing_time for s in shard_metrics]),
            'avg_utilization': np.mean([s.capacity_utilization for s in shard_metrics]),
            'max_utilization': np.max([s.capacity_utilization for s in shard_metrics]),
            'avg_error_rate': np.mean([s.error_rate for s in shard_metrics]),
            'total_storage': sum(s.storage_usage for s in shard_metrics),
            'avg_latency': np.mean([s.network_latency for s in shard_metrics])
        }

    def _identify_issues(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> List[str]:
        """Identify current sharding issues"""
        issues = []
        
        if not shard_metrics:
            return ["No shard metrics available"]
        
        # Check for overloaded shards
        overloaded = [s for s in shard_metrics if s.capacity_utilization > self.split_threshold]
        if overloaded:
            issues.append(f"{len(overloaded)} shards are overloaded (>{self.split_threshold*100:.0f}% utilization)")
        
        # Check for underutilized shards
        underutilized = [s for s in shard_metrics if s.capacity_utilization < self.merge_threshold]
        if len(underutilized) > 1:
            issues.append(f"{len(underutilized)} shards are underutilized (<{self.merge_threshold*100:.0f}% utilization)")
        
        # Check for imbalanced load
        utilizations = [s.capacity_utilization for s in shard_metrics]
        if np.var(utilizations) > 0.1:
            issues.append("Significant load imbalance between shards")
        
        # Check for high error rates
        high_error_shards = [s for s in shard_metrics if s.error_rate > 0.01]
        if high_error_shards:
            issues.append(f"{len(high_error_shards)} shards have high error rates")
        
        # Check cross-shard transaction overhead
        if network_stats.cross_shard_ratio > 0.3:
            issues.append("High cross-shard transaction overhead")
        
        return issues

    def _calculate_optimization_potential(self, analysis: Dict) -> float:
        """Calculate potential for optimization (0-1)"""
        potential = 0.0
        
        # Utilization imbalance potential
        if analysis['utilization_variance'] > 0.1:
            potential += 0.3
        
        # Efficiency improvement potential
        if analysis['efficiency_score'] < 0.8:
            potential += (0.8 - analysis['efficiency_score']) * 0.5
        
        # Bottleneck resolution potential
        if analysis['bottlenecks']:
            potential += min(0.3, len(analysis['bottlenecks']) * 0.1)
        
        return min(1.0, potential)

    def _analyze_split_needs(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> Dict:
        """Analyze if shards need to be split"""
        overloaded_shards = [s for s in shard_metrics if s.capacity_utilization > self.split_threshold]
        
        if not overloaded_shards or len(shard_metrics) >= self.max_shards:
            return {'should_split': False}
        
        # Calculate optimal number of new shards needed
        total_load = sum(s.transaction_count for s in overloaded_shards)
        new_shards_needed = max(1, int(total_load / self.optimal_shard_size))
        new_shards_needed = min(new_shards_needed, self.max_shards - len(shard_metrics))
        
        target_shards = len(shard_metrics) + new_shards_needed
        
        return {
            'should_split': True,
            'action': 'split',
            'target_shards': target_shards,
            'changes': [f"Split {len(overloaded_shards)} overloaded shards"],
            'expected_improvement': self._estimate_split_improvement(overloaded_shards),
            'confidence': 0.85,
            'reasoning': [
                f"{len(overloaded_shards)} shards exceed {self.split_threshold*100:.0f}% utilization",
                f"Adding {new_shards_needed} shards will improve load distribution"
            ]
        }

    def _should_merge_shards(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> bool:
        """Check if shards should be merged"""
        if len(shard_metrics) <= self.min_shards:
            return False
        
        underutilized = [s for s in shard_metrics if s.capacity_utilization < self.merge_threshold]
        return len(underutilized) >= 2

    def _analyze_merge_opportunities(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> Dict:
        """Analyze opportunities to merge shards"""
        underutilized = [s for s in shard_metrics if s.capacity_utilization < self.merge_threshold]
        
        # Calculate how many shards can be merged
        total_underutilized_load = sum(s.transaction_count for s in underutilized)
        shards_after_merge = len(shard_metrics) - len(underutilized) + max(1, int(total_underutilized_load / self.optimal_shard_size))
        shards_after_merge = max(self.min_shards, shards_after_merge)
        
        return {
            'action': 'merge',
            'target_shards': shards_after_merge,
            'changes': [f"Merge {len(underutilized)} underutilized shards"],
            'expected_improvement': self._estimate_merge_improvement(underutilized),
            'confidence': 0.8,
            'reasoning': [
                f"{len(underutilized)} shards are under {self.merge_threshold*100:.0f}% utilization",
                "Merging will reduce overhead and improve resource utilization"
            ]
        }

    def _analyze_rebalance_needs(self, shard_metrics: List[ShardMetrics], network_stats: NetworkStats) -> Dict:
        """Analyze if shards need rebalancing"""
        utilizations = [s.capacity_utilization for s in shard_metrics]
        utilization_variance = np.var(utilizations)
        
        if utilization_variance < 0.05:  # Already well balanced
            return {'should_rebalance': False}
        
        return {
            'should_rebalance': True,
            'action': 'rebalance',
            'target_shards': len(shard_metrics),
            'changes': ["Redistribute transactions across existing shards"],
            'expected_improvement': utilization_variance * 0.3,
            'confidence': 0.75,
            'reasoning': [
                f"Load variance of {utilization_variance:.3f} indicates imbalance",
                "Rebalancing will improve overall efficiency"
            ]
        }

    def _estimate_split_improvement(self, overloaded_shards: List[ShardMetrics]) -> float:
        """Estimate improvement from splitting shards"""
        if not overloaded_shards:
            return 0.0
        
        avg_overload = np.mean([s.capacity_utilization - self.split_threshold for s in overloaded_shards])
        return min(0.5, avg_overload * 0.8)

    def _estimate_merge_improvement(self, underutilized_shards: List[ShardMetrics]) -> float:
        """Estimate improvement from merging shards"""
        if not underutilized_shards:
            return 0.0
        
        # Calculate resource savings
        return min(0.3, len(underutilized_shards) * 0.1)

    def _calculate_cost_benefit(self, current_analysis: Dict, recommendation: Dict) -> Dict:
        """Calculate cost-benefit analysis of recommendation"""
        if recommendation['action'] == 'maintain':
            return {'implementation_cost': 0, 'expected_benefit': 0, 'roi': 0}
        
        # Estimate implementation costs
        implementation_cost = {
            'split': 0.7,    # High cost due to data migration
            'merge': 0.5,    # Medium cost
            'rebalance': 0.3  # Lower cost
        }.get(recommendation['action'], 0.5)
        
        expected_benefit = recommendation.get('expected_improvement', 0)
        roi = (expected_benefit - implementation_cost) / max(0.1, implementation_cost)
        
        return {
            'implementation_cost': implementation_cost,
            'expected_benefit': expected_benefit,
            'roi': roi,
            'recommendation': 'proceed' if roi > 0.2 else 'defer'
        }

    def _get_default_analysis(self) -> Dict:
        """Default analysis when no data is available"""
        return {
            'total_shards': 1,
            'total_transactions': 0,
            'avg_utilization': 0.0,
            'utilization_variance': 0.0,
            'bottlenecks': [],
            'efficiency_score': 0.5,
            'performance_metrics': {},
            'issues': ['Insufficient data for analysis'],
            'optimization_potential': 0.0
        }

    def _get_default_recommendation(self) -> Dict:
        """Default recommendation when analysis fails"""
        return {
            'action': 'maintain',
            'target_shards': 1,
            'changes': [],
            'expected_improvement': 0.0,
            'confidence': 0.3,
            'reasoning': ['Insufficient data for recommendation'],
            'cost_benefit': {'implementation_cost': 0, 'expected_benefit': 0, 'roi': 0}
        }

    def get_optimal_shard_configuration(
        self, 
        total_transactions: int, 
        network_constraints: Dict
    ) -> Dict:
        """Calculate optimal shard configuration for given parameters"""
        try:
            # Calculate base number of shards needed
            base_shards = max(self.min_shards, int(total_transactions / self.optimal_shard_size))
            base_shards = min(base_shards, self.max_shards)
            
            # Adjust for network constraints
            if network_constraints.get('latency_sensitive', False):
                base_shards = min(base_shards, 16)  # Limit for latency
            
            if network_constraints.get('storage_limited', False):
                base_shards = max(base_shards, 4)   # Ensure distribution for storage
            
            # Calculate expected performance
            transactions_per_shard = total_transactions / base_shards
            expected_utilization = transactions_per_shard / self.optimal_shard_size
            
            return {
                'optimal_shards': base_shards,
                'transactions_per_shard': int(transactions_per_shard),
                'expected_utilization': expected_utilization,
                'estimated_performance': self._estimate_performance(base_shards, expected_utilization),
                'configuration_confidence': 0.9 if self.min_shards <= base_shards <= 32 else 0.7
            }
            
        except Exception as e:
            logger.error(f"Optimal configuration calculation error: {e}")
            return {
                'optimal_shards': self.min_shards,
                'transactions_per_shard': total_transactions // self.min_shards,
                'expected_utilization': 0.5,
                'estimated_performance': 0.5,
                'configuration_confidence': 0.3
            }

    def _estimate_performance(self, num_shards: int, avg_utilization: float) -> float:
        """Estimate performance score for given configuration"""
        # Penalize extreme utilization
        utilization_score = 1 - abs(0.6 - avg_utilization) * 2
        utilization_score = max(0, min(1, utilization_score))
        
        # Penalize too many or too few shards
        shard_efficiency = 1 - abs(num_shards - 8) / 32  # Optimal around 8 shards
        shard_efficiency = max(0.3, min(1, shard_efficiency))
        
        return (utilization_score * 0.7 + shard_efficiency * 0.3)
