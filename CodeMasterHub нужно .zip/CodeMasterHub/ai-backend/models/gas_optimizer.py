import numpy as np
import logging
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from typing import Dict, List, Optional
import joblib
import os

logger = logging.getLogger(__name__)

class GasFeeOptimizer:
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=15,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        self.model_path = "models/gas_fee_model.pkl"
        self.scaler_path = "models/gas_fee_scaler.pkl"
        
        # Load pre-trained model if available
        self._load_model()
        
        if not self.is_trained:
            self._initialize_with_synthetic_data()

    def _load_model(self):
        """Load pre-trained model and scaler"""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                self.is_trained = True
                logger.info("✅ Loaded pre-trained gas fee model")
        except Exception as e:
            logger.warning(f"Failed to load pre-trained model: {e}")

    def _save_model(self):
        """Save trained model and scaler"""
        try:
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)
            logger.info("✅ Saved gas fee model")
        except Exception as e:
            logger.error(f"Failed to save model: {e}")

    def _initialize_with_synthetic_data(self):
        """Initialize model with synthetic training data"""
        logger.info("🔄 Initializing gas fee model with synthetic data...")
        
        # Generate synthetic training data
        np.random.seed(42)
        n_samples = 10000
        
        # Features: network_load, tx_count, avg_tps, block_time, mempool_size
        network_load = np.random.uniform(0.1, 1.0, n_samples)
        tx_count = np.random.randint(10, 1000, n_samples)
        avg_tps = np.random.uniform(500, 3000, n_samples)
        block_time = np.random.randint(8, 15, n_samples)
        mempool_size = np.random.randint(0, 500, n_samples)
        
        X = np.column_stack([network_load, tx_count, avg_tps, block_time, mempool_size])
        
        # Target: gas fee (synthetic formula)
        base_fee = 1.0
        congestion_multiplier = 1 + (network_load * 3)
        demand_factor = np.log1p(tx_count / 100) * 0.5
        speed_factor = np.maximum(0, (2000 - avg_tps) / 1000) * 0.3
        time_penalty = np.maximum(0, (block_time - 10) / 5) * 0.2
        mempool_pressure = np.log1p(mempool_size / 50) * 0.4
        
        y = base_fee * congestion_multiplier + demand_factor + speed_factor + time_penalty + mempool_pressure
        y = np.maximum(y, 0.1)  # Minimum gas fee
        
        self.train(X, y)

    def train(self, X: np.ndarray, y: np.ndarray):
        """Train the gas fee optimization model"""
        try:
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Train model
            self.model.fit(X_scaled, y)
            self.is_trained = True
            
            # Save model
            self._save_model()
            
            logger.info(f"✅ Gas fee model trained with {len(X)} samples")
        except Exception as e:
            logger.error(f"Failed to train gas fee model: {e}")
            raise

    def predict_gas_fee(
        self, 
        network_load: float, 
        tx_count: int, 
        avg_tps: float, 
        block_time: int, 
        mempool_size: int
    ) -> float:
        """Predict optimal gas fee based on network conditions"""
        try:
            if not self.is_trained:
                logger.warning("Model not trained, using fallback calculation")
                return self._fallback_calculation(network_load, tx_count, avg_tps, block_time, mempool_size)
            
            # Prepare features
            features = np.array([[network_load, tx_count, avg_tps, block_time, mempool_size]])
            features_scaled = self.scaler.transform(features)
            
            # Predict
            predicted_fee = self.model.predict(features_scaled)[0]
            
            # Apply bounds and adjustments
            predicted_fee = max(predicted_fee, 0.001)  # Minimum fee
            predicted_fee = min(predicted_fee, 50.0)   # Maximum fee
            
            logger.info(f"🧠 AI predicted gas fee: {predicted_fee:.4f}")
            return predicted_fee
            
        except Exception as e:
            logger.error(f"Gas fee prediction error: {e}")
            return self._fallback_calculation(network_load, tx_count, avg_tps, block_time, mempool_size)

    def _fallback_calculation(self, network_load: float, tx_count: int, avg_tps: float, block_time: int, mempool_size: int) -> float:
        """Fallback gas fee calculation"""
        base_fee = 1.0
        congestion_factor = 1 + (network_load * 2)
        demand_factor = min(tx_count / 500, 2.0)
        
        calculated_fee = base_fee * congestion_factor * demand_factor
        return max(calculated_fee, 0.001)

    def get_fee_recommendations(self, network_stats: Dict) -> Dict[str, float]:
        """Get different fee recommendations (eco, standard, fast)"""
        base_fee = self.predict_gas_fee(
            network_stats.get("network_load", 0.5),
            network_stats.get("tx_count", 100),
            network_stats.get("avg_tps", 1000),
            network_stats.get("block_time", 10),
            network_stats.get("mempool_size", 50)
        )
        
        return {
            "eco": base_fee * 0.8,
            "standard": base_fee,
            "fast": base_fee * 1.5,
            "priority": base_fee * 2.0
        }

    def update_model(self, new_data: List[Dict]):
        """Update model with new real-world data"""
        if not new_data:
            return
        
        try:
            # Extract features and targets from new data
            features = []
            targets = []
            
            for data_point in new_data:
                features.append([
                    data_point["network_load"],
                    data_point["tx_count"],
                    data_point["avg_tps"],
                    data_point["block_time"],
                    data_point["mempool_size"]
                ])
                targets.append(data_point["actual_gas_fee"])
            
            X_new = np.array(features)
            y_new = np.array(targets)
            
            # Retrain with new data
            self.train(X_new, y_new)
            
            logger.info(f"✅ Model updated with {len(new_data)} new data points")
            
        except Exception as e:
            logger.error(f"Failed to update model: {e}")
