import numpy as np
import logging
from typing import Dict, List, Tuple
from dataclasses import dataclass
import time

logger = logging.getLogger(__name__)

@dataclass
class ValidatorMetrics:
    uptime: float              # Percentage uptime (0-1)
    response_time: float       # Average response time in ms
    missed_blocks: int         # Number of missed blocks
    slashing_events: int       # Number of slashing events
    reports: int              # Number of reports against validator
    stake_amount: float       # Total stake amount
    validator_age: int        # Days since validator started
    successful_proposals: int  # Number of successful block proposals
    total_proposals: int      # Total block proposals attempted

class ValidatorScorer:
    def __init__(self):
        self.historical_data = {}
        self.performance_weights = {
            'uptime': 0.25,
            'response_time': 0.15,
            'reliability': 0.20,
            'security': 0.15,
            'stake': 0.10,
            'experience': 0.10,
            'reputation': 0.05
        }
        
        # Scoring thresholds
        self.thresholds = {
            'excellent_uptime': 0.99,
            'good_uptime': 0.95,
            'poor_uptime': 0.90,
            'max_response_time': 1000,  # ms
            'max_missed_blocks': 5,
            'max_slashing_events': 0,
            'min_stake': 1000
        }

    def calculate_comprehensive_score(self, validator_metrics: ValidatorMetrics) -> Dict:
        """Calculate comprehensive validator score with detailed breakdown"""
        try:
            scores = {}
            
            # 1. Uptime Score (25%)
            scores['uptime'] = self._calculate_uptime_score(validator_metrics.uptime)
            
            # 2. Response Time Score (15%)
            scores['response_time'] = self._calculate_response_time_score(validator_metrics.response_time)
            
            # 3. Reliability Score (20%)
            scores['reliability'] = self._calculate_reliability_score(
                validator_metrics.missed_blocks,
                validator_metrics.successful_proposals,
                validator_metrics.total_proposals
            )
            
            # 4. Security Score (15%)
            scores['security'] = self._calculate_security_score(
                validator_metrics.slashing_events,
                validator_metrics.reports
            )
            
            # 5. Stake Score (10%)
            scores['stake'] = self._calculate_stake_score(validator_metrics.stake_amount)
            
            # 6. Experience Score (10%)
            scores['experience'] = self._calculate_experience_score(validator_metrics.validator_age)
            
            # 7. Reputation Score (5%)
            scores['reputation'] = self._calculate_reputation_score(validator_metrics)
            
            # Calculate weighted total score
            total_score = sum(
                scores[category] * self.performance_weights[category]
                for category in scores
            )
            
            # Apply penalties for critical issues
            total_score = self._apply_penalties(total_score, validator_metrics)
            
            # Ensure score is between 0 and 1
            total_score = max(0.0, min(1.0, total_score))
            
            result = {
                'total_score': total_score,
                'category_scores': scores,
                'grade': self._get_grade(total_score),
                'recommendations': self._get_recommendations(scores, validator_metrics),
                'risk_factors': self._identify_risk_factors(validator_metrics),
                'ai_confidence': self._calculate_confidence(validator_metrics)
            }
            
            logger.info(f"🎯 Validator score calculated: {total_score:.3f} ({result['grade']})")
            return result
            
        except Exception as e:
            logger.error(f"Validator scoring error: {e}")
            return self._fallback_score()

    def _calculate_uptime_score(self, uptime: float) -> float:
        """Calculate uptime score (0-1)"""
        if uptime >= self.thresholds['excellent_uptime']:
            return 1.0
        elif uptime >= self.thresholds['good_uptime']:
            return 0.8 + (uptime - self.thresholds['good_uptime']) * 4  # Linear interpolation
        elif uptime >= self.thresholds['poor_uptime']:
            return 0.5 + (uptime - self.thresholds['poor_uptime']) * 6
        else:
            return max(0.0, uptime * 0.5)

    def _calculate_response_time_score(self, response_time: float) -> float:
        """Calculate response time score (0-1)"""
        if response_time <= 100:  # Excellent response time
            return 1.0
        elif response_time <= 500:  # Good response time
            return 0.8 - (response_time - 100) / 400 * 0.3
        elif response_time <= self.thresholds['max_response_time']:  # Acceptable
            return 0.5 - (response_time - 500) / 500 * 0.3
        else:  # Poor response time
            return max(0.0, 0.2 - (response_time - 1000) / 1000 * 0.2)

    def _calculate_reliability_score(self, missed_blocks: int, successful: int, total: int) -> float:
        """Calculate reliability score based on block production"""
        if total == 0:
            return 0.5  # Neutral score for new validators
        
        success_rate = successful / total if total > 0 else 0
        
        # Penalty for missed blocks
        missed_penalty = min(0.5, missed_blocks * 0.1)
        
        # Success rate component
        success_component = success_rate * 0.8
        
        # Consistency bonus
        consistency_bonus = 0.2 if missed_blocks <= 2 else 0.1 if missed_blocks <= 5 else 0
        
        return max(0.0, success_component + consistency_bonus - missed_penalty)

    def _calculate_security_score(self, slashing_events: int, reports: int) -> float:
        """Calculate security score"""
        base_score = 1.0
        
        # Heavy penalty for slashing events
        if slashing_events > 0:
            base_score -= min(0.8, slashing_events * 0.4)
        
        # Penalty for reports
        if reports > 0:
            base_score -= min(0.3, reports * 0.1)
        
        return max(0.0, base_score)

    def _calculate_stake_score(self, stake_amount: float) -> float:
        """Calculate stake-based score"""
        if stake_amount >= 10000:
            return 1.0
        elif stake_amount >= 5000:
            return 0.8
        elif stake_amount >= self.thresholds['min_stake']:
            return 0.6
        else:
            return max(0.0, stake_amount / self.thresholds['min_stake'] * 0.5)

    def _calculate_experience_score(self, validator_age: int) -> float:
        """Calculate experience score based on validator age"""
        if validator_age >= 365:  # 1+ years
            return 1.0
        elif validator_age >= 180:  # 6+ months
            return 0.8
        elif validator_age >= 90:   # 3+ months
            return 0.6
        elif validator_age >= 30:   # 1+ month
            return 0.4
        else:
            return max(0.1, validator_age / 30 * 0.3)

    def _calculate_reputation_score(self, metrics: ValidatorMetrics) -> float:
        """Calculate reputation score based on overall performance"""
        # This could integrate with external reputation systems
        base_reputation = 0.8
        
        # Bonus for long-term good performance
        if metrics.validator_age > 180 and metrics.slashing_events == 0:
            base_reputation += 0.2
        
        return min(1.0, base_reputation)

    def _apply_penalties(self, score: float, metrics: ValidatorMetrics) -> float:
        """Apply penalties for critical issues"""
        # Critical penalty for slashing
        if metrics.slashing_events > 0:
            score *= (1 - min(0.5, metrics.slashing_events * 0.25))
        
        # Penalty for very low uptime
        if metrics.uptime < 0.8:
            score *= 0.7
        
        # Penalty for excessive missed blocks
        if metrics.missed_blocks > 10:
            score *= 0.8
        
        return score

    def _get_grade(self, score: float) -> str:
        """Convert numerical score to letter grade"""
        if score >= 0.9:
            return 'A+'
        elif score >= 0.8:
            return 'A'
        elif score >= 0.7:
            return 'B+'
        elif score >= 0.6:
            return 'B'
        elif score >= 0.5:
            return 'C'
        elif score >= 0.4:
            return 'D'
        else:
            return 'F'

    def _get_recommendations(self, scores: Dict, metrics: ValidatorMetrics) -> List[str]:
        """Generate improvement recommendations"""
        recommendations = []
        
        if scores['uptime'] < 0.8:
            recommendations.append("Improve server infrastructure and monitoring for better uptime")
        
        if scores['response_time'] < 0.6:
            recommendations.append("Optimize network configuration to reduce response times")
        
        if scores['reliability'] < 0.7:
            recommendations.append("Focus on consistent block production and reduce missed blocks")
        
        if scores['security'] < 0.9:
            recommendations.append("Review security practices and address any reported issues")
        
        if scores['stake'] < 0.6:
            recommendations.append("Consider increasing stake amount to improve network commitment")
        
        if not recommendations:
            recommendations.append("Excellent performance! Continue maintaining high standards")
        
        return recommendations

    def _identify_risk_factors(self, metrics: ValidatorMetrics) -> List[str]:
        """Identify potential risk factors"""
        risks = []
        
        if metrics.slashing_events > 0:
            risks.append("History of slashing events")
        
        if metrics.uptime < 0.9:
            risks.append("Below-average uptime")
        
        if metrics.missed_blocks > 5:
            risks.append("High number of missed blocks")
        
        if metrics.reports > 2:
            risks.append("Multiple community reports")
        
        if metrics.validator_age < 30:
            risks.append("New validator with limited track record")
        
        if metrics.response_time > 1000:
            risks.append("Poor network performance")
        
        return risks

    def _calculate_confidence(self, metrics: ValidatorMetrics) -> float:
        """Calculate AI confidence in the scoring"""
        confidence = 0.8  # Base confidence
        
        # Higher confidence for validators with more data
        if metrics.total_proposals > 100:
            confidence += 0.1
        elif metrics.total_proposals > 50:
            confidence += 0.05
        
        # Higher confidence for established validators
        if metrics.validator_age > 90:
            confidence += 0.1
        
        return min(1.0, confidence)

    def _fallback_score(self) -> Dict:
        """Fallback scoring method"""
        return {
            'total_score': 0.5,
            'category_scores': {},
            'grade': 'C',
            'recommendations': ["Unable to calculate comprehensive score, using default"],
            'risk_factors': ["Insufficient data for accurate assessment"],
            'ai_confidence': 0.3
        }

    def compare_validators(self, validators: List[Tuple[str, ValidatorMetrics]]) -> List[Dict]:
        """Compare multiple validators and rank them"""
        results = []
        
        for validator_id, metrics in validators:
            score_result = self.calculate_comprehensive_score(metrics)
            score_result['validator_id'] = validator_id
            results.append(score_result)
        
        # Sort by total score (descending)
        results.sort(key=lambda x: x['total_score'], reverse=True)
        
        # Add ranking
        for i, result in enumerate(results):
            result['rank'] = i + 1
        
        logger.info(f"🏆 Ranked {len(results)} validators")
        return results

    def get_validator_selection_recommendation(self, validators: List[Tuple[str, ValidatorMetrics]]) -> Dict:
        """Get AI recommendation for validator selection"""
        if not validators:
            return {'recommended_validator': None, 'reason': 'No validators available'}
        
        ranked_validators = self.compare_validators(validators)
        
        # Select top validator with additional criteria
        top_validator = ranked_validators[0]
        
        # Ensure minimum quality threshold
        if top_validator['total_score'] < 0.6:
            return {
                'recommended_validator': None,
                'reason': 'No validators meet minimum quality threshold',
                'top_score': top_validator['total_score']
            }
        
        return {
            'recommended_validator': top_validator['validator_id'],
            'score': top_validator['total_score'],
            'grade': top_validator['grade'],
            'confidence': top_validator['ai_confidence'],
            'reason': f"Highest scoring validator with grade {top_validator['grade']} and {top_validator['total_score']:.1%} performance score",
            'alternatives': [v['validator_id'] for v in ranked_validators[1:3]]  # Top 2 alternatives
        }
