import numpy as np
import logging
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from typing import Dict, List, Tuple
import joblib
import os
import hashlib

logger = logging.getLogger(__name__)

class TransactionFraudDetector:
    def __init__(self):
        self.model = IsolationForest(
            contamination=0.1,
            random_state=42,
            n_estimators=100
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        self.model_path = "models/fraud_detector_model.pkl"
        self.scaler_path = "models/fraud_detector_scaler.pkl"
        self.suspicious_addresses = set()
        self.transaction_patterns = {}
        
        # Load pre-trained model if available
        self._load_model()
        
        if not self.is_trained:
            self._initialize_with_synthetic_data()

    def _load_model(self):
        """Load pre-trained fraud detection model"""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                self.is_trained = True
                logger.info("✅ Loaded pre-trained fraud detection model")
        except Exception as e:
            logger.warning(f"Failed to load pre-trained fraud model: {e}")

    def _save_model(self):
        """Save trained model and scaler"""
        try:
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)
            logger.info("✅ Saved fraud detection model")
        except Exception as e:
            logger.error(f"Failed to save fraud model: {e}")

    def _initialize_with_synthetic_data(self):
        """Initialize with synthetic transaction data for training"""
        logger.info("🔄 Initializing fraud detector with synthetic data...")
        
        np.random.seed(42)
        n_samples = 10000
        
        # Generate normal transaction features
        normal_features = self._generate_normal_transactions(int(n_samples * 0.9))
        
        # Generate fraudulent transaction features
        fraud_features = self._generate_fraudulent_transactions(int(n_samples * 0.1))
        
        # Combine and train
        X = np.vstack([normal_features, fraud_features])
        self.train(X)

    def _generate_normal_transactions(self, n_samples: int) -> np.ndarray:
        """Generate features for normal transactions"""
        features = []
        
        for _ in range(n_samples):
            # Normal transaction patterns
            amount = np.random.lognormal(3, 1.5)  # Log-normal distribution for amounts
            frequency = np.random.poisson(5)      # Average 5 transactions per period
            time_variance = np.random.uniform(0, 24)  # Hours in a day
            recipient_diversity = np.random.randint(1, 10)  # Number of unique recipients
            amount_variance = np.random.uniform(0.1, 2.0)    # Variance in transaction amounts
            
            features.append([amount, frequency, time_variance, recipient_diversity, amount_variance])
        
        return np.array(features)

    def _generate_fraudulent_transactions(self, n_samples: int) -> np.ndarray:
        """Generate features for fraudulent transactions"""
        features = []
        
        for _ in range(n_samples):
            # Fraudulent patterns: large amounts, high frequency, unusual timing
            amount = np.random.uniform(1000, 100000)  # Unusually large amounts
            frequency = np.random.poisson(50)         # Very high frequency
            time_variance = np.random.uniform(0, 4)   # Concentrated timing
            recipient_diversity = np.random.randint(10, 100)  # Many recipients (money laundering)
            amount_variance = np.random.uniform(0.01, 0.1)    # Very consistent amounts
            
            features.append([amount, frequency, time_variance, recipient_diversity, amount_variance])
        
        return np.array(features)

    def train(self, X: np.ndarray):
        """Train the fraud detection model"""
        try:
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Train isolation forest
            self.model.fit(X_scaled)
            self.is_trained = True
            
            # Save model
            self._save_model()
            
            logger.info(f"✅ Fraud detection model trained with {len(X)} samples")
        except Exception as e:
            logger.error(f"Failed to train fraud detection model: {e}")
            raise

    def extract_transaction_features(self, transaction_data: str, sender_history: List[str]) -> np.ndarray:
        """Extract features from transaction data"""
        try:
            # Parse transaction data (simplified)
            # In reality, this would parse actual transaction format
            import json
            
            try:
                tx_data = json.loads(transaction_data)
            except:
                # Fallback if not JSON
                tx_data = {
                    "amount": 100,
                    "from": "unknown",
                    "to": "unknown",
                    "timestamp": 0
                }
            
            amount = float(tx_data.get("amount", 0))
            sender = tx_data.get("from", "")
            recipient = tx_data.get("to", "")
            
            # Calculate features
            frequency = len(sender_history)
            time_variance = self._calculate_time_variance(sender_history)
            recipient_diversity = len(set([tx.split("->")[1] if "->" in tx else "" for tx in sender_history]))
            amount_variance = self._calculate_amount_variance(sender_history)
            
            return np.array([[amount, frequency, time_variance, recipient_diversity, amount_variance]])
            
        except Exception as e:
            logger.error(f"Feature extraction error: {e}")
            # Return default features for safety
            return np.array([[100, 1, 12, 1, 1.0]])

    def _calculate_time_variance(self, history: List[str]) -> float:
        """Calculate variance in transaction timing"""
        if len(history) < 2:
            return 12.0  # Default variance
        
        # Simplified time variance calculation
        return min(24.0, len(history) * 0.5)

    def _calculate_amount_variance(self, history: List[str]) -> float:
        """Calculate variance in transaction amounts"""
        if not history:
            return 1.0
        
        amounts = []
        for tx in history:
            try:
                # Extract amount from history string (simplified)
                parts = tx.split(":")
                if len(parts) > 1:
                    amounts.append(float(parts[1]))
            except:
                continue
        
        if len(amounts) < 2:
            return 1.0
        
        return float(np.var(amounts)) if amounts else 1.0

    def is_transaction_suspicious(
        self, 
        transaction_data: str, 
        sender_history: List[str] = None
    ) -> Tuple[bool, float, List[str]]:
        """Check if a transaction is suspicious"""
        try:
            if not self.is_trained:
                logger.warning("Fraud model not trained, using basic rules")
                return self._basic_fraud_check(transaction_data)
            
            sender_history = sender_history or []
            
            # Extract features
            features = self.extract_transaction_features(transaction_data, sender_history)
            features_scaled = self.scaler.transform(features)
            
            # Predict anomaly
            anomaly_score = self.model.decision_function(features_scaled)[0]
            is_outlier = self.model.predict(features_scaled)[0] == -1
            
            # Additional rule-based checks
            rule_violations = self._check_fraud_rules(transaction_data, sender_history)
            
            # Combine ML and rule-based results
            is_suspicious = is_outlier or len(rule_violations) > 0
            risk_score = max(0, min(1, (0.5 - anomaly_score) * 2))  # Normalize to 0-1
            
            if rule_violations:
                risk_score = min(1.0, risk_score + 0.3)
            
            reasons = []
            if is_outlier:
                reasons.append("Anomalous transaction pattern detected by AI")
            reasons.extend(rule_violations)
            
            logger.info(f"🔍 Fraud check - Suspicious: {is_suspicious}, Risk: {risk_score:.3f}")
            
            return is_suspicious, risk_score, reasons
            
        except Exception as e:
            logger.error(f"Fraud detection error: {e}")
            return self._basic_fraud_check(transaction_data)

    def _basic_fraud_check(self, transaction_data: str) -> Tuple[bool, float, List[str]]:
        """Basic rule-based fraud check as fallback"""
        try:
            import json
            tx_data = json.loads(transaction_data)
            amount = float(tx_data.get("amount", 0))
            sender = tx_data.get("from", "")
            recipient = tx_data.get("to", "")
            
            reasons = []
            risk_score = 0.0
            
            # Large amount check
            if amount > 10000:
                reasons.append("Unusually large transaction amount")
                risk_score += 0.4
            
            # Known suspicious address check
            if sender in self.suspicious_addresses or recipient in self.suspicious_addresses:
                reasons.append("Transaction involves known suspicious address")
                risk_score += 0.6
            
            # Self-transfer check
            if sender == recipient:
                reasons.append("Self-transfer detected")
                risk_score += 0.2
            
            is_suspicious = risk_score > 0.5
            return is_suspicious, min(1.0, risk_score), reasons
            
        except Exception as e:
            logger.error(f"Basic fraud check error: {e}")
            return False, 0.0, []

    def _check_fraud_rules(self, transaction_data: str, sender_history: List[str]) -> List[str]:
        """Apply rule-based fraud detection"""
        violations = []
        
        try:
            import json
            tx_data = json.loads(transaction_data)
            amount = float(tx_data.get("amount", 0))
            sender = tx_data.get("from", "")
            
            # High-frequency trading detection
            if len(sender_history) > 100:  # More than 100 transactions in history
                violations.append("Extremely high transaction frequency")
            
            # Round number detection (common in fraud)
            if amount > 0 and amount == int(amount) and amount >= 1000:
                violations.append("Suspiciously round transaction amount")
            
            # Pattern matching for known fraud signatures
            if self._matches_known_fraud_pattern(tx_data, sender_history):
                violations.append("Matches known fraud pattern")
                
        except Exception as e:
            logger.error(f"Rule-based check error: {e}")
        
        return violations

    def _matches_known_fraud_pattern(self, tx_data: Dict, history: List[str]) -> bool:
        """Check if transaction matches known fraud patterns"""
        # This would contain more sophisticated pattern matching
        # For now, simplified checks
        
        amount = tx_data.get("amount", 0)
        
        # Micro-payment spam pattern
        if amount < 0.001 and len(history) > 50:
            return True
        
        # Consistent amount pattern (possible automation)
        if len(history) > 10:
            recent_amounts = []
            for tx in history[-10:]:
                try:
                    if ":" in tx:
                        recent_amounts.append(float(tx.split(":")[1]))
                except:
                    continue
            
            if len(set(recent_amounts)) == 1 and len(recent_amounts) > 5:
                return True
        
        return False

    def add_suspicious_address(self, address: str):
        """Add address to suspicious list"""
        self.suspicious_addresses.add(address)
        logger.info(f"⚠️ Added suspicious address: {address[:10]}...")

    def update_transaction_patterns(self, patterns: Dict):
        """Update known transaction patterns"""
        self.transaction_patterns.update(patterns)
        logger.info("✅ Updated transaction patterns database")
