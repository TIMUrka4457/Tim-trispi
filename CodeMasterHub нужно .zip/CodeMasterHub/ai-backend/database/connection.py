import os
import asyncio
import logging
from typing import Optional
import asyncpg
from asyncpg import Pool
import redis.asyncio as redis

logger = logging.getLogger(__name__)

# Database connection pools
pg_pool: Optional[Pool] = None
redis_client: Optional[redis.Redis] = None

async def init_database():
    """Initialize database connections"""
    global pg_pool, redis_client
    
    try:
        # PostgreSQL connection
        database_url = os.getenv("DATABASE_URL")
        if database_url:
            pg_pool = await asyncpg.create_pool(
                database_url,
                min_size=5,
                max_size=20,
                command_timeout=60
            )
            logger.info("✅ PostgreSQL connection pool initialized")
            
            # Create tables if they don't exist
            await create_tables()
        else:
            logger.warning("⚠️ No DATABASE_URL provided, PostgreSQL not initialized")
        
        # Redis connection
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        redis_client = redis.from_url(redis_url, decode_responses=True)
        
        # Test Redis connection
        await redis_client.ping()
        logger.info("✅ Redis connection initialized")
        
    except Exception as e:
        logger.error(f"❌ Database initialization failed: {e}")
        raise

async def create_tables():
    """Create necessary database tables"""
    if not pg_pool:
        return
    
    async with pg_pool.acquire() as conn:
        # AI Training Data Table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS ai_training_data (
                id SERIAL PRIMARY KEY,
                model_type VARCHAR(50) NOT NULL,
                features JSONB NOT NULL,
                target_value FLOAT,
                timestamp TIMESTAMP DEFAULT NOW(),
                network_conditions JSONB
            )
        """)
        
        # Gas Fee History Table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS gas_fee_history (
                id SERIAL PRIMARY KEY,
                network_load FLOAT NOT NULL,
                transaction_count INTEGER NOT NULL,
                avg_tps FLOAT NOT NULL,
                block_time INTEGER NOT NULL,
                mempool_size INTEGER NOT NULL,
                predicted_fee FLOAT NOT NULL,
                actual_fee FLOAT,
                timestamp TIMESTAMP DEFAULT NOW(),
                accuracy_score FLOAT
            )
        """)
        
        # Fraud Detection Logs Table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS fraud_detection_logs (
                id SERIAL PRIMARY KEY,
                transaction_hash VARCHAR(64) NOT NULL,
                sender_address VARCHAR(42) NOT NULL,
                recipient_address VARCHAR(42) NOT NULL,
                amount DECIMAL(20, 8) NOT NULL,
                is_suspicious BOOLEAN NOT NULL,
                risk_score FLOAT NOT NULL,
                detection_reasons TEXT[],
                timestamp TIMESTAMP DEFAULT NOW(),
                confirmed_fraud BOOLEAN DEFAULT NULL
            )
        """)
        
        # Validator Performance Table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS validator_performance (
                id SERIAL PRIMARY KEY,
                validator_address VARCHAR(42) NOT NULL UNIQUE,
                uptime FLOAT NOT NULL,
                response_time FLOAT NOT NULL,
                missed_blocks INTEGER DEFAULT 0,
                slashing_events INTEGER DEFAULT 0,
                reports INTEGER DEFAULT 0,
                stake_amount DECIMAL(20, 8) NOT NULL,
                total_score FLOAT NOT NULL,
                grade VARCHAR(10) NOT NULL,
                last_updated TIMESTAMP DEFAULT NOW()
            )
        """)
        
        # Network Metrics Table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS network_metrics (
                id SERIAL PRIMARY KEY,
                peer_count INTEGER NOT NULL,
                message_rate FLOAT NOT NULL,
                latency FLOAT NOT NULL,
                error_rate FLOAT NOT NULL,
                block_height BIGINT NOT NULL,
                tps FLOAT NOT NULL,
                timestamp TIMESTAMP DEFAULT NOW()
            )
        """)
        
        # Sharding Analytics Table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS sharding_analytics (
                id SERIAL PRIMARY KEY,
                shard_count INTEGER NOT NULL,
                total_transactions BIGINT NOT NULL,
                avg_utilization FLOAT NOT NULL,
                efficiency_score FLOAT NOT NULL,
                recommendation TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT NOW()
            )
        """)
        
        # Create indexes for better performance
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_gas_fee_timestamp ON gas_fee_history(timestamp)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_fraud_timestamp ON fraud_detection_logs(timestamp)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_fraud_sender ON fraud_detection_logs(sender_address)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_validator_address ON validator_performance(validator_address)")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_network_timestamp ON network_metrics(timestamp)")
        
        logger.info("✅ Database tables created/verified")

async def get_db_connection():
    """Get a database connection from the pool"""
    if not pg_pool:
        raise Exception("Database pool not initialized")
    return pg_pool.acquire()

async def get_redis_client():
    """Get Redis client instance"""
    if not redis_client:
        raise Exception("Redis client not initialized")
    return redis_client

# Data storage functions for AI models

async def store_gas_fee_prediction(
    network_load: float,
    tx_count: int,
    avg_tps: float,
    block_time: int,
    mempool_size: int,
    predicted_fee: float,
    actual_fee: Optional[float] = None
):
    """Store gas fee prediction for model improvement"""
    if not pg_pool:
        return
    
    try:
        async with pg_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO gas_fee_history 
                (network_load, transaction_count, avg_tps, block_time, mempool_size, predicted_fee, actual_fee)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """, network_load, tx_count, avg_tps, block_time, mempool_size, predicted_fee, actual_fee)
        
        logger.debug("Gas fee prediction stored")
    except Exception as e:
        logger.error(f"Failed to store gas fee prediction: {e}")

async def store_fraud_detection_result(
    tx_hash: str,
    sender: str,
    recipient: str,
    amount: float,
    is_suspicious: bool,
    risk_score: float,
    reasons: list
):
    """Store fraud detection result"""
    if not pg_pool:
        return
    
    try:
        async with pg_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO fraud_detection_logs 
                (transaction_hash, sender_address, recipient_address, amount, is_suspicious, risk_score, detection_reasons)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """, tx_hash, sender, recipient, amount, is_suspicious, risk_score, reasons)
        
        logger.debug("Fraud detection result stored")
    except Exception as e:
        logger.error(f"Failed to store fraud detection result: {e}")

async def update_validator_performance(
    validator_address: str,
    uptime: float,
    response_time: float,
    missed_blocks: int,
    slashing_events: int,
    reports: int,
    stake_amount: float,
    total_score: float,
    grade: str
):
    """Update validator performance metrics"""
    if not pg_pool:
        return
    
    try:
        async with pg_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO validator_performance 
                (validator_address, uptime, response_time, missed_blocks, slashing_events, 
                 reports, stake_amount, total_score, grade, last_updated)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
                ON CONFLICT (validator_address) 
                DO UPDATE SET
                    uptime = EXCLUDED.uptime,
                    response_time = EXCLUDED.response_time,
                    missed_blocks = EXCLUDED.missed_blocks,
                    slashing_events = EXCLUDED.slashing_events,
                    reports = EXCLUDED.reports,
                    stake_amount = EXCLUDED.stake_amount,
                    total_score = EXCLUDED.total_score,
                    grade = EXCLUDED.grade,
                    last_updated = NOW()
            """, validator_address, uptime, response_time, missed_blocks, slashing_events, 
                 reports, stake_amount, total_score, grade)
        
        logger.debug(f"Validator performance updated for {validator_address}")
    except Exception as e:
        logger.error(f"Failed to update validator performance: {e}")

async def store_network_metrics(
    peer_count: int,
    message_rate: float,
    latency: float,
    error_rate: float,
    block_height: int,
    tps: float
):
    """Store network performance metrics"""
    if not pg_pool:
        return
    
    try:
        async with pg_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO network_metrics 
                (peer_count, message_rate, latency, error_rate, block_height, tps)
                VALUES ($1, $2, $3, $4, $5, $6)
            """, peer_count, message_rate, latency, error_rate, block_height, tps)
        
        logger.debug("Network metrics stored")
    except Exception as e:
        logger.error(f"Failed to store network metrics: {e}")

# Cache management functions

async def cache_set(key: str, value: str, expire: int = 3600):
    """Set a value in Redis cache"""
    if not redis_client:
        return
    
    try:
        await redis_client.setex(key, expire, value)
    except Exception as e:
        logger.error(f"Failed to set cache: {e}")

async def cache_get(key: str) -> Optional[str]:
    """Get a value from Redis cache"""
    if not redis_client:
        return None
    
    try:
        return await redis_client.get(key)
    except Exception as e:
        logger.error(f"Failed to get cache: {e}")
        return None

async def cache_delete(key: str):
    """Delete a value from Redis cache"""
    if not redis_client:
        return
    
    try:
        await redis_client.delete(key)
    except Exception as e:
        logger.error(f"Failed to delete cache: {e}")

# Utility functions for data retrieval

async def get_recent_gas_fee_data(hours: int = 24):
    """Get recent gas fee data for model training"""
    if not pg_pool:
        return []
    
    try:
        async with pg_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT network_load, transaction_count, avg_tps, block_time, 
                       mempool_size, predicted_fee, actual_fee
                FROM gas_fee_history 
                WHERE timestamp > NOW() - INTERVAL '%s hours'
                AND actual_fee IS NOT NULL
                ORDER BY timestamp DESC
            """, hours)
        
        return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Failed to get gas fee data: {e}")
        return []

async def get_fraud_statistics(days: int = 7):
    """Get fraud detection statistics"""
    if not pg_pool:
        return {}
    
    try:
        async with pg_pool.acquire() as conn:
            result = await conn.fetchrow("""
                SELECT 
                    COUNT(*) as total_checks,
                    COUNT(*) FILTER (WHERE is_suspicious) as suspicious_count,
                    AVG(risk_score) as avg_risk_score,
                    COUNT(*) FILTER (WHERE confirmed_fraud = true) as confirmed_fraud
                FROM fraud_detection_logs 
                WHERE timestamp > NOW() - INTERVAL '%s days'
            """, days)
        
        return dict(result) if result else {}
    except Exception as e:
        logger.error(f"Failed to get fraud statistics: {e}")
        return {}

async def cleanup_old_data(days_to_keep: int = 30):
    """Clean up old data to manage database size"""
    if not pg_pool:
        return
    
    try:
        async with pg_pool.acquire() as conn:
            # Clean old gas fee history
            await conn.execute("""
                DELETE FROM gas_fee_history 
                WHERE timestamp < NOW() - INTERVAL '%s days'
            """, days_to_keep)
            
            # Clean old fraud detection logs
            await conn.execute("""
                DELETE FROM fraud_detection_logs 
                WHERE timestamp < NOW() - INTERVAL '%s days'
            """, days_to_keep)
            
            # Clean old network metrics
            await conn.execute("""
                DELETE FROM network_metrics 
                WHERE timestamp < NOW() - INTERVAL '%s days'
            """, days_to_keep)
        
        logger.info(f"Cleaned up data older than {days_to_keep} days")
    except Exception as e:
        logger.error(f"Failed to cleanup old data: {e}")

async def close_connections():
    """Close all database connections"""
    global pg_pool, redis_client
    
    if pg_pool:
        await pg_pool.close()
        logger.info("PostgreSQL connection pool closed")
    
    if redis_client:
        await redis_client.close()
        logger.info("Redis connection closed")
