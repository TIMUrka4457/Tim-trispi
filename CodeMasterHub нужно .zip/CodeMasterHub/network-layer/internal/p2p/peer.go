package p2p

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"go.uber.org/zap"
)

// Peer represents a network peer
type Peer struct {
	ID         string
	NodeID     string
	Version    string
	RemoteAddr string
	
	// Connection
	conn       *websocket.Conn
	connected  bool
	connMux    sync.RWMutex
	
	// Messaging
	sendCh     chan *Message
	logger     *zap.SugaredLogger
	
	// Statistics
	LastSeen      time.Time
	MessagesSent  int64
	MessagesRecv  int64
	BytesSent     int64
	BytesRecv     int64
	
	// Lifecycle
	ctx        context.Context
	cancel     context.CancelFunc
	wg         sync.WaitGroup
}

// NewPeer creates a new peer
func NewPeer(conn *websocket.Conn, logger *zap.SugaredLogger) *Peer {
	return &Peer{
		ID:         generatePeerID(),
		RemoteAddr: conn.RemoteAddr().String(),
		conn:       conn,
		connected:  true,
		sendCh:     make(chan *Message, 100),
		logger:     logger,
		LastSeen:   time.Now(),
	}
}

// Start starts the peer's message handling
func (p *Peer) Start(ctx context.Context, incomingMsgs chan<- *Message) error {
	p.ctx, p.cancel = context.WithCancel(ctx)
	defer p.cancel()

	// Start message sender
	p.wg.Add(1)
	go func() {
		defer p.wg.Done()
		p.messageSender()
	}()

	// Start message receiver
	p.wg.Add(1)
	go func() {
		defer p.wg.Done()
		p.messageReceiver(incomingMsgs)
	}()

	// Start ping sender
	p.wg.Add(1)
	go func() {
		defer p.wg.Done()
		p.pingSender()
	}()

	// Wait for all goroutines to finish
	p.wg.Wait()
	return nil
}

// Close closes the peer connection
func (p *Peer) Close() {
	p.connMux.Lock()
	defer p.connMux.Unlock()

	if p.connected {
		p.connected = false
		if p.conn != nil {
			p.conn.Close()
		}
		if p.cancel != nil {
			p.cancel()
		}
		close(p.sendCh)
	}
}

// IsConnected returns whether the peer is connected
func (p *Peer) IsConnected() bool {
	p.connMux.RLock()
	defer p.connMux.RUnlock()
	return p.connected
}

// SendMessage sends a message to the peer
func (p *Peer) SendMessage(msg *Message) error {
	if !p.IsConnected() {
		return fmt.Errorf("peer is not connected")
	}

	select {
	case p.sendCh <- msg:
		return nil
	case <-p.ctx.Done():
		return p.ctx.Err()
	default:
		return fmt.Errorf("send buffer full")
	}
}

// messageSender handles outgoing messages
func (p *Peer) messageSender() {
	defer p.logger.Debug("Message sender stopped")

	for {
		select {
		case <-p.ctx.Done():
			return
		case msg, ok := <-p.sendCh:
			if !ok {
				return
			}

			if err := p.sendMessageDirect(msg); err != nil {
				p.logger.Errorw("Failed to send message", "error", err)
				p.Close()
				return
			}
		}
	}
}

// messageReceiver handles incoming messages
func (p *Peer) messageReceiver(incomingMsgs chan<- *Message) {
	defer p.logger.Debug("Message receiver stopped")

	for {
		if !p.IsConnected() {
			return
		}

		// Set read deadline
		p.conn.SetReadDeadline(time.Now().Add(60 * time.Second))

		var rawMsg json.RawMessage
		if err := p.conn.ReadJSON(&rawMsg); err != nil {
			if p.ctx.Err() != nil {
				return
			}
			p.logger.Errorw("Failed to read message", "error", err)
			p.Close()
			return
		}

		// Parse message
		var msg Message
		if err := json.Unmarshal(rawMsg, &msg); err != nil {
			p.logger.Errorw("Failed to parse message", "error", err)
			continue
		}

		// Set message peer reference
		msg.Peer = p

		// Update statistics
		p.MessagesRecv++
		p.BytesRecv += int64(len(rawMsg))
		p.LastSeen = time.Now()

		// Forward to message processor
		select {
		case incomingMsgs <- &msg:
		case <-p.ctx.Done():
			return
		default:
			p.logger.Warnw("Incoming message queue full, dropping message")
		}
	}
}

// sendMessageDirect sends a message directly to the connection
func (p *Peer) sendMessageDirect(msg *Message) error {
	p.connMux.RLock()
	defer p.connMux.RUnlock()

	if !p.connected {
		return fmt.Errorf("peer is not connected")
	}

	// Set write deadline
	p.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))

	// Serialize message
	data, err := json.Marshal(msg)
	if err != nil {
		return fmt.Errorf("failed to marshal message: %w", err)
	}

	// Send message
	if err := p.conn.WriteJSON(msg); err != nil {
		return fmt.Errorf("failed to write message: %w", err)
	}

	// Update statistics
	p.MessagesSent++
	p.BytesSent += int64(len(data))

	return nil
}

// pingSender sends periodic ping messages
func (p *Peer) pingSender() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-p.ctx.Done():
			return
		case <-ticker.C:
			ping := &Message{
				Type: MessageTypePing,
				Data: map[string]interface{}{
					"timestamp": time.Now().Unix(),
				},
			}

			if err := p.SendMessage(ping); err != nil {
				p.logger.Errorw("Failed to send ping", "error", err)
				p.Close()
				return
			}
		}
	}
}

// GetStats returns peer statistics
func (p *Peer) GetStats() PeerStats {
	p.connMux.RLock()
	defer p.connMux.RUnlock()

	return PeerStats{
		ID:           p.ID,
		NodeID:       p.NodeID,
		RemoteAddr:   p.RemoteAddr,
		Connected:    p.connected,
		LastSeen:     p.LastSeen,
		MessagesSent: p.MessagesSent,
		MessagesRecv: p.MessagesRecv,
		BytesSent:    p.BytesSent,
		BytesRecv:    p.BytesRecv,
	}
}

// PeerStats represents peer statistics
type PeerStats struct {
	ID           string    `json:"id"`
	NodeID       string    `json:"node_id"`
	RemoteAddr   string    `json:"remote_addr"`
	Connected    bool      `json:"connected"`
	LastSeen     time.Time `json:"last_seen"`
	MessagesSent int64     `json:"messages_sent"`
	MessagesRecv int64     `json:"messages_recv"`
	BytesSent    int64     `json:"bytes_sent"`
	BytesRecv    int64     `json:"bytes_recv"`
}

// generatePeerID generates a unique peer ID
func generatePeerID() string {
	return fmt.Sprintf("peer-%d-%d", time.Now().UnixNano(), time.Now().Nanosecond())
}
