package p2p

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"github.com/trispi/network-layer/internal/ai_client"
	"github.com/trispi/network-layer/internal/config"
	"go.uber.org/zap"
	"golang.org/x/sync/errgroup"
)

// Node represents a P2P network node
type Node struct {
	config    *config.Config
	logger    *zap.SugaredLogger
	aiClient  *ai_client.Client
	
	// Network components
	listener  net.Listener
	peers     map[string]*Peer
	peersMux  sync.RWMutex
	
	// Message handling
	messageHandlers map[MessageType]MessageHandler
	incomingMsgs    chan *Message
	outgoingMsgs    chan *Message
	
	// Statistics
	stats     *NodeStats
	statsMux  sync.RWMutex
	
	// Lifecycle
	ctx       context.Context
	cancel    context.CancelFunc
	wg        sync.WaitGroup
}

// NodeStats holds statistics about the node
type NodeStats struct {
	ConnectedPeers    int   `json:"connected_peers"`
	MessagesSent      int64 `json:"messages_sent"`
	MessagesReceived  int64 `json:"messages_received"`
	BytesSent         int64 `json:"bytes_sent"`
	BytesReceived     int64 `json:"bytes_received"`
	StartTime         time.Time `json:"start_time"`
	LastActivity      time.Time `json:"last_activity"`
}

// MessageHandler defines the interface for handling messages
type MessageHandler func(msg *Message, peer *Peer) error

// NewNode creates a new P2P node
func NewNode(cfg *config.Config, logger *zap.SugaredLogger, aiClient *ai_client.Client) (*Node, error) {
	node := &Node{
		config:          cfg,
		logger:          logger,
		aiClient:        aiClient,
		peers:           make(map[string]*Peer),
		messageHandlers: make(map[MessageType]MessageHandler),
		incomingMsgs:    make(chan *Message, 1000),
		outgoingMsgs:    make(chan *Message, 1000),
		stats: &NodeStats{
			StartTime:    time.Now(),
			LastActivity: time.Now(),
		},
	}

	// Register message handlers
	node.registerMessageHandlers()

	return node, nil
}

// Start starts the P2P node
func (n *Node) Start(ctx context.Context) error {
	n.ctx, n.cancel = context.WithCancel(ctx)
	defer n.cancel()

	// Start TCP listener
	listener, err := net.Listen("tcp", n.config.Network.ListenAddress)
	if err != nil {
		return fmt.Errorf("failed to start listener: %w", err)
	}
	n.listener = listener

	n.logger.Infow("P2P node listening", "address", n.config.Network.ListenAddress)

	// Start background goroutines
	g, gCtx := errgroup.WithContext(n.ctx)

	// Message processor
	g.Go(func() error {
		return n.messageProcessor(gCtx)
	})

	// Outgoing message sender
	g.Go(func() error {
		return n.outgoingMessageSender(gCtx)
	})

	// Peer manager
	g.Go(func() error {
		return n.peerManager(gCtx)
	})

	// Connection acceptor
	g.Go(func() error {
		return n.acceptConnections(gCtx)
	})

	// Connect to bootstrap peers
	if len(n.config.Network.BootstrapPeers) > 0 {
		g.Go(func() error {
			return n.connectToBootstrapPeers(gCtx)
		})
	}

	return g.Wait()
}

// Stop stops the P2P node
func (n *Node) Stop(ctx context.Context) error {
	if n.cancel != nil {
		n.cancel()
	}

	if n.listener != nil {
		n.listener.Close()
	}

	// Close all peer connections
	n.peersMux.Lock()
	for _, peer := range n.peers {
		peer.Close()
	}
	n.peersMux.Unlock()

	return nil
}

// acceptConnections accepts incoming connections
func (n *Node) acceptConnections(ctx context.Context) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		conn, err := n.listener.Accept()
		if err != nil {
			if ctx.Err() != nil {
				return ctx.Err()
			}
			n.logger.Errorw("Failed to accept connection", "error", err)
			continue
		}

		n.wg.Add(1)
		go func(conn net.Conn) {
			defer n.wg.Done()
			if err := n.handleIncomingConnection(ctx, conn); err != nil {
				n.logger.Errorw("Failed to handle incoming connection", "error", err)
			}
		}(conn)
	}
}

// handleIncomingConnection handles a new incoming connection
func (n *Node) handleIncomingConnection(ctx context.Context, conn net.Conn) error {
	// Upgrade to WebSocket
	upgrader := websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool { return true },
	}

	// For TCP connections, we need to wrap in HTTP-like upgrade
	// This is a simplified approach - in production you might want a different protocol
	ws, err := upgrader.Upgrade(&httpResponseWriter{conn: conn}, &httpRequest{}, nil)
	if err != nil {
		return fmt.Errorf("failed to upgrade connection: %w", err)
	}

	peer := NewPeer(ws, n.logger.With("peer", conn.RemoteAddr().String()))
	
	// Add peer to our list
	n.addPeer(peer)
	defer n.removePeer(peer.ID)

	// Send handshake
	handshake := &Message{
		Type: MessageTypeHandshake,
		Data: map[string]interface{}{
			"node_id": n.getNodeID(),
			"version": "1.0.0",
			"timestamp": time.Now().Unix(),
		},
	}

	if err := peer.SendMessage(handshake); err != nil {
		return fmt.Errorf("failed to send handshake: %w", err)
	}

	// Start peer message handling
	return peer.Start(ctx, n.incomingMsgs)
}

// connectToBootstrapPeers connects to bootstrap peers
func (n *Node) connectToBootstrapPeers(ctx context.Context) error {
	for _, addr := range n.config.Network.BootstrapPeers {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		if err := n.connectToPeer(ctx, addr); err != nil {
			n.logger.Warnw("Failed to connect to bootstrap peer", "address", addr, "error", err)
		} else {
			n.logger.Infow("Connected to bootstrap peer", "address", addr)
		}
	}
	return nil
}

// connectToPeer connects to a specific peer
func (n *Node) connectToPeer(ctx context.Context, address string) error {
	dialer := websocket.Dialer{
		HandshakeTimeout: 10 * time.Second,
	}

	ws, _, err := dialer.DialContext(ctx, "ws://"+address, nil)
	if err != nil {
		return fmt.Errorf("failed to dial peer: %w", err)
	}

	peer := NewPeer(ws, n.logger.With("peer", address))
	
	// Add peer to our list
	n.addPeer(peer)

	// Send handshake
	handshake := &Message{
		Type: MessageTypeHandshake,
		Data: map[string]interface{}{
			"node_id": n.getNodeID(),
			"version": "1.0.0",
			"timestamp": time.Now().Unix(),
		},
	}

	if err := peer.SendMessage(handshake); err != nil {
		n.removePeer(peer.ID)
		return fmt.Errorf("failed to send handshake: %w", err)
	}

	// Start peer message handling
	n.wg.Add(1)
	go func() {
		defer n.wg.Done()
		defer n.removePeer(peer.ID)
		
		if err := peer.Start(ctx, n.incomingMsgs); err != nil && ctx.Err() == nil {
			n.logger.Errorw("Peer connection error", "peer", peer.ID, "error", err)
		}
	}()

	return nil
}

// messageProcessor processes incoming messages
func (n *Node) messageProcessor(ctx context.Context) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case msg := <-n.incomingMsgs:
			n.updateStats(func(stats *NodeStats) {
				stats.MessagesReceived++
				stats.LastActivity = time.Now()
			})

			if handler, exists := n.messageHandlers[msg.Type]; exists {
				if err := handler(msg, msg.Peer); err != nil {
					n.logger.Errorw("Failed to handle message", 
						"type", msg.Type, 
						"peer", msg.Peer.ID, 
						"error", err)
				}
			} else {
				n.logger.Warnw("No handler for message type", "type", msg.Type)
			}
		}
	}
}

// outgoingMessageSender sends outgoing messages
func (n *Node) outgoingMessageSender(ctx context.Context) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case msg := <-n.outgoingMsgs:
			if msg.Peer != nil {
				// Send to specific peer
				if err := msg.Peer.SendMessage(msg); err != nil {
					n.logger.Errorw("Failed to send message to peer", 
						"peer", msg.Peer.ID, 
						"error", err)
				}
			} else {
				// Broadcast to all peers
				n.broadcastMessage(msg)
			}

			n.updateStats(func(stats *NodeStats) {
				stats.MessagesSent++
				stats.LastActivity = time.Now()
			})
		}
	}
}

// peerManager manages peer connections
func (n *Node) peerManager(ctx context.Context) error {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
			n.managePeers()
		}
	}
}

// managePeers performs peer management tasks
func (n *Node) managePeers() {
	n.peersMux.Lock()
	defer n.peersMux.Unlock()

	// Remove disconnected peers
	for id, peer := range n.peers {
		if !peer.IsConnected() {
			delete(n.peers, id)
			n.logger.Debugw("Removed disconnected peer", "peer", id)
		}
	}

	// Update peer count in stats
	n.updateStats(func(stats *NodeStats) {
		stats.ConnectedPeers = len(n.peers)
	})

	n.logger.Debugw("Peer management completed", "connected_peers", len(n.peers))
}

// registerMessageHandlers registers message handlers
func (n *Node) registerMessageHandlers() {
	n.messageHandlers[MessageTypeHandshake] = n.handleHandshake
	n.messageHandlers[MessageTypePing] = n.handlePing
	n.messageHandlers[MessageTypePong] = n.handlePong
	n.messageHandlers[MessageTypeBlock] = n.handleBlock
	n.messageHandlers[MessageTypeTransaction] = n.handleTransaction
	n.messageHandlers[MessageTypePeerList] = n.handlePeerList
	n.messageHandlers[MessageTypeRequestPeers] = n.handleRequestPeers
}

// Message handlers
func (n *Node) handleHandshake(msg *Message, peer *Peer) error {
	data := msg.Data.(map[string]interface{})
	nodeID := data["node_id"].(string)
	version := data["version"].(string)

	peer.NodeID = nodeID
	peer.Version = version
	peer.LastSeen = time.Now()

	n.logger.Infow("Handshake completed", 
		"peer", peer.ID, 
		"node_id", nodeID, 
		"version", version)

	return nil
}

func (n *Node) handlePing(msg *Message, peer *Peer) error {
	pong := &Message{
		Type: MessageTypePong,
		Data: map[string]interface{}{
			"timestamp": time.Now().Unix(),
		},
		Peer: peer,
	}

	select {
	case n.outgoingMsgs <- pong:
	default:
		n.logger.Warnw("Outgoing message queue full, dropping pong")
	}

	return nil
}

func (n *Node) handlePong(msg *Message, peer *Peer) error {
	peer.LastSeen = time.Now()
	n.logger.Debugw("Received pong", "peer", peer.ID)
	return nil
}

func (n *Node) handleBlock(msg *Message, peer *Peer) error {
	// Forward to blockchain core
	blockData, _ := json.Marshal(msg.Data)
	n.logger.Infow("Received block", "peer", peer.ID, "size", len(blockData))
	
	// TODO: Forward to blockchain RPC endpoint
	return nil
}

func (n *Node) handleTransaction(msg *Message, peer *Peer) error {
	// Forward to blockchain core
	txData, _ := json.Marshal(msg.Data)
	n.logger.Infow("Received transaction", "peer", peer.ID, "size", len(txData))
	
	// TODO: Forward to blockchain RPC endpoint
	return nil
}

func (n *Node) handlePeerList(msg *Message, peer *Peer) error {
	peers := msg.Data.([]interface{})
	n.logger.Infow("Received peer list", "peer", peer.ID, "count", len(peers))
	
	// Try to connect to new peers
	for _, peerAddr := range peers {
		addr := peerAddr.(string)
		go func(addr string) {
			if err := n.connectToPeer(n.ctx, addr); err != nil {
				n.logger.Debugw("Failed to connect to discovered peer", "address", addr, "error", err)
			}
		}(addr)
	}
	
	return nil
}

func (n *Node) handleRequestPeers(msg *Message, peer *Peer) error {
	n.peersMux.RLock()
	peerAddresses := make([]string, 0, len(n.peers))
	for _, p := range n.peers {
		if p.ID != peer.ID && p.IsConnected() {
			peerAddresses = append(peerAddresses, p.RemoteAddr)
		}
	}
	n.peersMux.RUnlock()

	response := &Message{
		Type: MessageTypePeerList,
		Data: peerAddresses,
		Peer: peer,
	}

	select {
	case n.outgoingMsgs <- response:
	default:
		n.logger.Warnw("Outgoing message queue full, dropping peer list response")
	}

	return nil
}

// Utility methods
func (n *Node) addPeer(peer *Peer) {
	n.peersMux.Lock()
	defer n.peersMux.Unlock()
	n.peers[peer.ID] = peer
}

func (n *Node) removePeer(peerID string) {
	n.peersMux.Lock()
	defer n.peersMux.Unlock()
	if peer, exists := n.peers[peerID]; exists {
		peer.Close()
		delete(n.peers, peerID)
	}
}

func (n *Node) broadcastMessage(msg *Message) {
	n.peersMux.RLock()
	defer n.peersMux.RUnlock()

	for _, peer := range n.peers {
		if peer.IsConnected() {
			if err := peer.SendMessage(msg); err != nil {
				n.logger.Errorw("Failed to broadcast message to peer", 
					"peer", peer.ID, 
					"error", err)
			}
		}
	}
}

func (n *Node) updateStats(updater func(*NodeStats)) {
	n.statsMux.Lock()
	defer n.statsMux.Unlock()
	updater(n.stats)
}

func (n *Node) GetStats() NodeStats {
	n.statsMux.RLock()
	defer n.statsMux.RUnlock()
	return *n.stats
}

func (n *Node) getNodeID() string {
	// Generate or load persistent node ID
	return "node-" + fmt.Sprintf("%d", time.Now().Unix())
}

// Helper types for WebSocket over TCP
type httpResponseWriter struct {
	conn net.Conn
}

func (w *httpResponseWriter) Header() http.Header {
	return make(http.Header)
}

func (w *httpResponseWriter) Write(data []byte) (int, error) {
	return w.conn.Write(data)
}

func (w *httpResponseWriter) WriteHeader(statusCode int) {}

type httpRequest struct{}

func (r *httpRequest) Header() http.Header {
	return make(http.Header)
}
