package p2p

import (
	"encoding/json"
	"time"
)

// MessageType represents the type of P2P message
type MessageType string

const (
	MessageTypeHandshake     MessageType = "handshake"
	MessageTypePing          MessageType = "ping"
	MessageTypePong          MessageType = "pong"
	MessageTypeBlock         MessageType = "block"
	MessageTypeTransaction   MessageType = "transaction"
	MessageTypePeerList      MessageType = "peer_list"
	MessageTypeRequestPeers  MessageType = "request_peers"
	MessageTypeGetBlocks     MessageType = "get_blocks"
	MessageTypeBlocksResponse MessageType = "blocks_response"
	MessageTypeError         MessageType = "error"
	MessageTypeStatus        MessageType = "status"
)

// Message represents a P2P message
type Message struct {
	Type      MessageType     `json:"type"`
	Data      interface{}     `json:"data"`
	Timestamp time.Time       `json:"timestamp"`
	ID        string          `json:"id,omitempty"`
	Peer      *Peer           `json:"-"` // Not serialized
}

// BlockMessage represents a block message
type BlockMessage struct {
	Index        uint64                 `json:"index"`
	Hash         string                 `json:"hash"`
	PrevHash     string                 `json:"prev_hash"`
	Timestamp    time.Time              `json:"timestamp"`
	Validator    string                 `json:"validator"`
	Transactions []TransactionMessage   `json:"transactions"`
	MerkleRoot   string                 `json:"merkle_root"`
	GasFee       float64                `json:"gas_fee"`
}

// TransactionMessage represents a transaction message
type TransactionMessage struct {
	ID        string    `json:"id"`
	From      string    `json:"from"`
	To        string    `json:"to"`
	Amount    uint64    `json:"amount"`
	GasFee    float64   `json:"gas_fee"`
	Data      string    `json:"data,omitempty"`
	Signature string    `json:"signature"`
	Timestamp time.Time `json:"timestamp"`
}

// HandshakeMessage represents a handshake message
type HandshakeMessage struct {
	NodeID    string `json:"node_id"`
	Version   string `json:"version"`
	ChainID   string `json:"chain_id"`
	Timestamp int64  `json:"timestamp"`
}

// PeerListMessage represents a peer list message
type PeerListMessage struct {
	Peers []PeerInfo `json:"peers"`
}

// PeerInfo represents information about a peer
type PeerInfo struct {
	NodeID  string `json:"node_id"`
	Address string `json:"address"`
	Version string `json:"version"`
}

// GetBlocksMessage represents a get blocks request
type GetBlocksMessage struct {
	FromIndex uint64 `json:"from_index"`
	Count     uint32 `json:"count"`
}

// BlocksResponseMessage represents a blocks response
type BlocksResponseMessage struct {
	Blocks []BlockMessage `json:"blocks"`
}

// ErrorMessage represents an error message
type ErrorMessage struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Details string `json:"details,omitempty"`
}

// StatusMessage represents a status message
type StatusMessage struct {
	Height      uint64 `json:"height"`
	BestHash    string `json:"best_hash"`
	PeerCount   int    `json:"peer_count"`
	Syncing     bool   `json:"syncing"`
	NetworkLoad float64 `json:"network_load"`
}

// NewMessage creates a new message with timestamp and ID
func NewMessage(msgType MessageType, data interface{}) *Message {
	return &Message{
		Type:      msgType,
		Data:      data,
		Timestamp: time.Now(),
		ID:        generateMessageID(),
	}
}

// NewHandshakeMessage creates a new handshake message
func NewHandshakeMessage(nodeID, version, chainID string) *Message {
	return NewMessage(MessageTypeHandshake, HandshakeMessage{
		NodeID:    nodeID,
		Version:   version,
		ChainID:   chainID,
		Timestamp: time.Now().Unix(),
	})
}

// NewPingMessage creates a new ping message
func NewPingMessage() *Message {
	return NewMessage(MessageTypePing, map[string]interface{}{
		"timestamp": time.Now().Unix(),
	})
}

// NewPongMessage creates a new pong message
func NewPongMessage() *Message {
	return NewMessage(MessageTypePong, map[string]interface{}{
		"timestamp": time.Now().Unix(),
	})
}

// NewBlockMessage creates a new block message
func NewBlockMessage(block BlockMessage) *Message {
	return NewMessage(MessageTypeBlock, block)
}

// NewTransactionMessage creates a new transaction message
func NewTransactionMessage(tx TransactionMessage) *Message {
	return NewMessage(MessageTypeTransaction, tx)
}

// NewPeerListMessage creates a new peer list message
func NewPeerListMessage(peers []PeerInfo) *Message {
	return NewMessage(MessageTypePeerList, PeerListMessage{
		Peers: peers,
	})
}

// NewRequestPeersMessage creates a new request peers message
func NewRequestPeersMessage() *Message {
	return NewMessage(MessageTypeRequestPeers, nil)
}

// NewGetBlocksMessage creates a new get blocks message
func NewGetBlocksMessage(fromIndex uint64, count uint32) *Message {
	return NewMessage(MessageTypeGetBlocks, GetBlocksMessage{
		FromIndex: fromIndex,
		Count:     count,
	})
}

// NewBlocksResponseMessage creates a new blocks response message
func NewBlocksResponseMessage(blocks []BlockMessage) *Message {
	return NewMessage(MessageTypeBlocksResponse, BlocksResponseMessage{
		Blocks: blocks,
	})
}

// NewErrorMessage creates a new error message
func NewErrorMessage(code int, message, details string) *Message {
	return NewMessage(MessageTypeError, ErrorMessage{
		Code:    code,
		Message: message,
		Details: details,
	})
}

// NewStatusMessage creates a new status message
func NewStatusMessage(height uint64, bestHash string, peerCount int, syncing bool, networkLoad float64) *Message {
	return NewMessage(MessageTypeStatus, StatusMessage{
		Height:      height,
		BestHash:    bestHash,
		PeerCount:   peerCount,
		Syncing:     syncing,
		NetworkLoad: networkLoad,
	})
}

// Serialize serializes the message to JSON
func (m *Message) Serialize() ([]byte, error) {
	return json.Marshal(m)
}

// Deserialize deserializes a message from JSON
func Deserialize(data []byte) (*Message, error) {
	var msg Message
	if err := json.Unmarshal(data, &msg); err != nil {
		return nil, err
	}
	return &msg, nil
}

// IsValidType checks if the message type is valid
func (m *Message) IsValidType() bool {
	switch m.Type {
	case MessageTypeHandshake, MessageTypePing, MessageTypePong,
		 MessageTypeBlock, MessageTypeTransaction, MessageTypePeerList,
		 MessageTypeRequestPeers, MessageTypeGetBlocks, MessageTypeBlocksResponse,
		 MessageTypeError, MessageTypeStatus:
		return true
	default:
		return false
	}
}

// GetDataAs unmarshals the message data into the provided struct
func (m *Message) GetDataAs(v interface{}) error {
	data, err := json.Marshal(m.Data)
	if err != nil {
		return err
	}
	return json.Unmarshal(data, v)
}

// generateMessageID generates a unique message ID
func generateMessageID() string {
	return time.Now().Format("20060102150405") + "-" + randString(8)
}

// randString generates a random string of specified length
func randString(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = letters[time.Now().UnixNano()%int64(len(letters))]
	}
	return string(b)
}
