package ai_client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

// Client provides access to AI services
type Client struct {
	endpoint   string
	httpClient *http.Client
	timeout    time.Duration
}

// Request/Response types for AI services
type GasFeeRequest struct {
	NetworkLoad  float64 `json:"network_load"`
	TxCount      uint32  `json:"tx_count"`
	AvgTPS       float64 `json:"avg_tps"`
	BlockTime    uint32  `json:"block_time"`
	MempoolSize  uint32  `json:"mempool_size"`
}

type GasFeeResponse struct {
	RecommendedGasFee float64 `json:"recommended_gas_fee"`
}

type TxFraudRequest struct {
	TxFeatures []float64 `json:"tx_features"`
}

type TxFraudResponse struct {
	IsSuspicious bool `json:"is_suspicious"`
}

type ValidatorScoreRequest struct {
	Uptime         float64 `json:"uptime"`
	ResponseTime   float64 `json:"response_time"`
	MissedBlocks   uint32  `json:"missed_blocks"`
	SlashingEvents uint32  `json:"slashing_events"`
	Reports        uint32  `json:"reports"`
}

type ValidatorScoreResponse struct {
	Score float64 `json:"score"`
}

type ShardingRequest struct {
	NetworkStats map[string]float64 `json:"network_stats"`
	TxHeatmap    []float64          `json:"tx_heatmap"`
}

type ShardingResponse struct {
	Split        bool `json:"split"`
	TargetShards int  `json:"target_shards"`
}

// New creates a new AI client
func New(endpoint string, timeout time.Duration) *Client {
	return &Client{
		endpoint: endpoint,
		timeout:  timeout,
		httpClient: &http.Client{
			Timeout: timeout,
		},
	}
}

// GetRecommendedGasFee gets AI-recommended gas fee
func (c *Client) GetRecommendedGasFee(ctx context.Context, req GasFeeRequest) (float64, error) {
	url := fmt.Sprintf("%s/gas_fee", c.endpoint)
	
	var resp GasFeeResponse
	if err := c.makeRequest(ctx, "POST", url, req, &resp); err != nil {
		return 0, fmt.Errorf("gas fee request failed: %w", err)
	}
	
	return resp.RecommendedGasFee, nil
}

// IsTxFraudulent checks if a transaction is fraudulent
func (c *Client) IsTxFraudulent(ctx context.Context, req TxFraudRequest) (bool, error) {
	url := fmt.Sprintf("%s/tx_fraud", c.endpoint)
	
	var resp TxFraudResponse
	if err := c.makeRequest(ctx, "POST", url, req, &resp); err != nil {
		return false, fmt.Errorf("fraud check request failed: %w", err)
	}
	
	return resp.IsSuspicious, nil
}

// GetValidatorScore gets AI-calculated validator score
func (c *Client) GetValidatorScore(ctx context.Context, req ValidatorScoreRequest) (float64, error) {
	url := fmt.Sprintf("%s/validator_score", c.endpoint)
	
	var resp ValidatorScoreResponse
	if err := c.makeRequest(ctx, "POST", url, req, &resp); err != nil {
		return 0, fmt.Errorf("validator score request failed: %w", err)
	}
	
	return resp.Score, nil
}

// GetShardingRecommendation gets AI sharding recommendation
func (c *Client) GetShardingRecommendation(ctx context.Context, req ShardingRequest) (ShardingResponse, error) {
	url := fmt.Sprintf("%s/sharding", c.endpoint)
	
	var resp ShardingResponse
	if err := c.makeRequest(ctx, "POST", url, req, &resp); err != nil {
		return ShardingResponse{}, fmt.Errorf("sharding request failed: %w", err)
	}
	
	return resp, nil
}

// HealthCheck checks if the AI service is healthy
func (c *Client) HealthCheck(ctx context.Context) error {
	url := fmt.Sprintf("%s/../../health", c.endpoint)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return fmt.Errorf("failed to create health check request: %w", err)
	}
	
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("health check request failed: %w", err)
	}
	defer resp.Body.Close()
	
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("health check failed with status: %d", resp.StatusCode)
	}
	
	return nil
}

// makeRequest makes an HTTP request to the AI service
func (c *Client) makeRequest(ctx context.Context, method, url string, requestBody interface{}, responseBody interface{}) error {
	// Serialize request body
	var reqBody []byte
	var err error
	if requestBody != nil {
		reqBody, err = json.Marshal(requestBody)
		if err != nil {
			return fmt.Errorf("failed to marshal request: %w", err)
		}
	}
	
	// Create request
	req, err := http.NewRequestWithContext(ctx, method, url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}
	
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	
	// Make request
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()
	
	// Check status code
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("request failed with status: %d", resp.StatusCode)
	}
	
	// Parse response
	if responseBody != nil {
		if err := json.NewDecoder(resp.Body).Decode(responseBody); err != nil {
			return fmt.Errorf("failed to decode response: %w", err)
		}
	}
	
	return nil
}

// GetEndpoint returns the AI service endpoint
func (c *Client) GetEndpoint() string {
	return c.endpoint
}

// SetTimeout sets the request timeout
func (c *Client) SetTimeout(timeout time.Duration) {
	c.timeout = timeout
	c.httpClient.Timeout = timeout
}
