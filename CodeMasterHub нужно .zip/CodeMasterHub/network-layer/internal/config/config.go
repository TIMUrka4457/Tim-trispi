package config

import (
	"fmt"
	"time"

	"github.com/spf13/viper"
)

// Config represents the application configuration
type Config struct {
	Network    NetworkConfig    `mapstructure:"network"`
	Blockchain BlockchainConfig `mapstructure:"blockchain"`
	AI         AIConfig         `mapstructure:"ai"`
	Discovery  DiscoveryConfig  `mapstructure:"discovery"`
	Logging    LoggingConfig    `mapstructure:"logging"`
}

// NetworkConfig contains network-related configuration
type NetworkConfig struct {
	ListenAddress    string   `mapstructure:"listen_address"`
	BootstrapPeers   []string `mapstructure:"bootstrap_peers"`
	MaxPeers         int      `mapstructure:"max_peers"`
	EnableDiscovery  bool     `mapstructure:"enable_discovery"`
	ConnectionTimeout time.Duration `mapstructure:"connection_timeout"`
	ReadTimeout      time.Duration `mapstructure:"read_timeout"`
	WriteTimeout     time.Duration `mapstructure:"write_timeout"`
}

// BlockchainConfig contains blockchain-related configuration
type BlockchainConfig struct {
	RPCEndpoint     string        `mapstructure:"rpc_endpoint"`
	ChainID         string        `mapstructure:"chain_id"`
	SyncTimeout     time.Duration `mapstructure:"sync_timeout"`
	BlockTimeout    time.Duration `mapstructure:"block_timeout"`
	MaxBlockSize    int           `mapstructure:"max_block_size"`
	EnableValidation bool         `mapstructure:"enable_validation"`
}

// AIConfig contains AI service configuration
type AIConfig struct {
	Endpoint string        `mapstructure:"endpoint"`
	Timeout  time.Duration `mapstructure:"timeout"`
	Retries  int           `mapstructure:"retries"`
	Enabled  bool          `mapstructure:"enabled"`
}

// DiscoveryConfig contains peer discovery configuration
type DiscoveryConfig struct {
	EnableDHT          bool          `mapstructure:"enable_dht"`
	DiscoveryInterval  int           `mapstructure:"discovery_interval"`
	PeerTimeout        int           `mapstructure:"peer_timeout"`
	MaxRetries         int           `mapstructure:"max_retries"`
	MaxPeers           int           `mapstructure:"max_peers"`
}

// LoggingConfig contains logging configuration
type LoggingConfig struct {
	Level  string `mapstructure:"level"`
	Format string `mapstructure:"format"`
	Output string `mapstructure:"output"`
}

// Load loads configuration from file and environment variables
func Load(configFile string) (*Config, error) {
	// Set defaults
	setDefaults()
	
	// Set config file if provided
	if configFile != "" {
		viper.SetConfigFile(configFile)
	} else {
		viper.SetConfigName("config")
		viper.SetConfigType("yaml")
		viper.AddConfigPath(".")
		viper.AddConfigPath("./config")
		viper.AddConfigPath("/etc/trispi")
	}
	
	// Enable environment variable support
	viper.SetEnvPrefix("TRISPI")
	viper.AutomaticEnv()
	
	// Read config file (optional)
	if err := viper.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("failed to read config file: %w", err)
		}
	}
	
	// Unmarshal config
	var config Config
	if err := viper.Unmarshal(&config); err != nil {
		return nil, fmt.Errorf("failed to unmarshal config: %w", err)
	}
	
	// Validate config
	if err := validateConfig(&config); err != nil {
		return nil, fmt.Errorf("invalid config: %w", err)
	}
	
	return &config, nil
}

// setDefaults sets default configuration values
func setDefaults() {
	// Network defaults
	viper.SetDefault("network.listen_address", "0.0.0.0:9000")
	viper.SetDefault("network.bootstrap_peers", []string{})
	viper.SetDefault("network.max_peers", 50)
	viper.SetDefault("network.enable_discovery", true)
	viper.SetDefault("network.connection_timeout", "30s")
	viper.SetDefault("network.read_timeout", "60s")
	viper.SetDefault("network.write_timeout", "10s")
	
	// Blockchain defaults
	viper.SetDefault("blockchain.rpc_endpoint", "http://localhost:8080")
	viper.SetDefault("blockchain.chain_id", "trispi-mainnet")
	viper.SetDefault("blockchain.sync_timeout", "300s")
	viper.SetDefault("blockchain.block_timeout", "30s")
	viper.SetDefault("blockchain.max_block_size", 1048576) // 1MB
	viper.SetDefault("blockchain.enable_validation", true)
	
	// AI defaults
	viper.SetDefault("ai.endpoint", "http://localhost:8000/api/ai")
	viper.SetDefault("ai.timeout", "5s")
	viper.SetDefault("ai.retries", 3)
	viper.SetDefault("ai.enabled", true)
	
	// Discovery defaults
	viper.SetDefault("discovery.enable_dht", false)
	viper.SetDefault("discovery.discovery_interval", 30)
	viper.SetDefault("discovery.peer_timeout", 300)
	viper.SetDefault("discovery.max_retries", 3)
	viper.SetDefault("discovery.max_peers", 50)
	
	// Logging defaults
	viper.SetDefault("logging.level", "info")
	viper.SetDefault("logging.format", "json")
	viper.SetDefault("logging.output", "stdout")
}

// validateConfig validates the configuration
func validateConfig(config *Config) error {
	// Validate network config
	if config.Network.ListenAddress == "" {
		return fmt.Errorf("network.listen_address is required")
	}
	
	if config.Network.MaxPeers <= 0 {
		return fmt.Errorf("network.max_peers must be positive")
	}
	
	// Validate blockchain config
	if config.Blockchain.RPCEndpoint == "" {
		return fmt.Errorf("blockchain.rpc_endpoint is required")
	}
	
	if config.Blockchain.ChainID == "" {
		return fmt.Errorf("blockchain.chain_id is required")
	}
	
	// Validate AI config
	if config.AI.Enabled && config.AI.Endpoint == "" {
		return fmt.Errorf("ai.endpoint is required when AI is enabled")
	}
	
	if config.AI.Retries < 0 {
		return fmt.Errorf("ai.retries must be non-negative")
	}
	
	// Validate discovery config
	if config.Discovery.DiscoveryInterval <= 0 {
		return fmt.Errorf("discovery.discovery_interval must be positive")
	}
	
	if config.Discovery.PeerTimeout <= 0 {
		return fmt.Errorf("discovery.peer_timeout must be positive")
	}
	
	// Validate logging config
	validLevels := map[string]bool{
		"debug": true,
		"info":  true,
		"warn":  true,
		"error": true,
	}
	
	if !validLevels[config.Logging.Level] {
		return fmt.Errorf("invalid logging.level: %s", config.Logging.Level)
	}
	
	return nil
}

// GetString gets a string configuration value
func GetString(key string) string {
	return viper.GetString(key)
}

// GetInt gets an integer configuration value
func GetInt(key string) int {
	return viper.GetInt(key)
}

// GetBool gets a boolean configuration value
func GetBool(key string) bool {
	return viper.GetBool(key)
}

// GetDuration gets a duration configuration value
func GetDuration(key string) time.Duration {
	return viper.GetDuration(key)
}

// GetStringSlice gets a string slice configuration value
func GetStringSlice(key string) []string {
	return viper.GetStringSlice(key)
}
