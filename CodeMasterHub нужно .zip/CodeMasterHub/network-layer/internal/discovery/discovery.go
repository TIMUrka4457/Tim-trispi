package discovery

import (
	"context"
	"fmt"
	"math/rand"
	"sync"
	"time"

	"github.com/trispi/network-layer/internal/config"
	"github.com/trispi/network-layer/internal/p2p"
	"go.uber.org/zap"
)

// Service handles peer discovery
type Service struct {
	config   *config.DiscoveryConfig
	p2pNode  *p2p.Node
	logger   *zap.SugaredLogger
	
	// Known peers
	knownPeers map[string]*PeerRecord
	peersMux   sync.RWMutex
	
	// Discovery state
	running    bool
	ctx        context.Context
	cancel     context.CancelFunc
}

// PeerRecord represents a discovered peer
type PeerRecord struct {
	Address    string
	NodeID     string
	LastSeen   time.Time
	Reputation float64
	Attempts   int
	Connected  bool
}

// New creates a new discovery service
func New(p2pNode *p2p.Node, config *config.DiscoveryConfig, logger *zap.SugaredLogger) *Service {
	return &Service{
		config:     config,
		p2pNode:    p2pNode,
		logger:     logger.With("component", "discovery"),
		knownPeers: make(map[string]*PeerRecord),
	}
}

// Start starts the discovery service
func (s *Service) Start(ctx context.Context) error {
	s.ctx, s.cancel = context.WithCancel(ctx)
	s.running = true

	s.logger.Info("Starting peer discovery service")

	// Start discovery goroutines
	go s.periodicDiscovery()
	go s.peerMaintenance()

	<-s.ctx.Done()
	return s.ctx.Err()
}

// Stop stops the discovery service
func (s *Service) Stop(ctx context.Context) error {
	if s.cancel != nil {
		s.cancel()
	}
	s.running = false
	s.logger.Info("Peer discovery service stopped")
	return nil
}

// periodicDiscovery performs periodic peer discovery
func (s *Service) periodicDiscovery() {
	ticker := time.NewTicker(time.Duration(s.config.DiscoveryInterval) * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-s.ctx.Done():
			return
		case <-ticker.C:
			s.performDiscovery()
		}
	}
}

// peerMaintenance maintains the peer list
func (s *Service) peerMaintenance() {
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-s.ctx.Done():
			return
		case <-ticker.C:
			s.maintainPeers()
		}
	}
}

// performDiscovery performs peer discovery
func (s *Service) performDiscovery() {
	s.logger.Debug("Performing peer discovery")

	// Get current connected peers
	stats := s.p2pNode.GetStats()
	if stats.ConnectedPeers >= s.config.MaxPeers {
		s.logger.Debug("Max peers reached, skipping discovery")
		return
	}

	// Try different discovery methods
	s.discoverFromConnectedPeers()
	s.discoverFromKnownPeers()
	
	if s.config.EnableDHT {
		s.discoverFromDHT()
	}
}

// discoverFromConnectedPeers requests peer lists from connected peers
func (s *Service) discoverFromConnectedPeers() {
	// Request peer lists from connected peers
	requestMsg := p2p.NewRequestPeersMessage()
	
	// This would be sent through the P2P node's messaging system
	s.logger.Debug("Requesting peer lists from connected peers")
}

// discoverFromKnownPeers tries to connect to known peers
func (s *Service) discoverFromKnownPeers() {
	s.peersMux.RLock()
	defer s.peersMux.RUnlock()

	// Select random peers to try connecting to
	candidates := make([]*PeerRecord, 0)
	for _, peer := range s.knownPeers {
		if !peer.Connected && peer.Attempts < s.config.MaxRetries {
			candidates = append(candidates, peer)
		}
	}

	// Shuffle and try to connect to some candidates
	rand.Shuffle(len(candidates), func(i, j int) {
		candidates[i], candidates[j] = candidates[j], candidates[i]
	})

	maxTries := min(len(candidates), 5) // Try up to 5 peers
	for i := 0; i < maxTries; i++ {
		peer := candidates[i]
		go s.tryConnectToPeer(peer)
	}
}

// discoverFromDHT discovers peers using DHT (placeholder implementation)
func (s *Service) discoverFromDHT() {
	if !s.config.EnableDHT {
		return
	}

	s.logger.Debug("DHT discovery not implemented yet")
	// TODO: Implement DHT-based peer discovery
}

// tryConnectToPeer attempts to connect to a peer
func (s *Service) tryConnectToPeer(peer *PeerRecord) {
	s.logger.Debugw("Trying to connect to peer", "address", peer.Address)

	// This would use the P2P node's connection method
	// For now, we just update the attempt count
	s.peersMux.Lock()
	peer.Attempts++
	peer.LastSeen = time.Now()
	s.peersMux.Unlock()

	// TODO: Actual connection attempt through P2P node
}

// maintainPeers maintains the peer list by removing old entries
func (s *Service) maintainPeers() {
	s.peersMux.Lock()
	defer s.peersMux.Unlock()

	cutoff := time.Now().Add(-time.Duration(s.config.PeerTimeout) * time.Second)
	
	for address, peer := range s.knownPeers {
		// Remove peers that haven't been seen for too long and failed too many times
		if peer.LastSeen.Before(cutoff) && peer.Attempts >= s.config.MaxRetries {
			delete(s.knownPeers, address)
			s.logger.Debugw("Removed stale peer", "address", address)
		}
	}

	s.logger.Debugw("Peer maintenance completed", "known_peers", len(s.knownPeers))
}

// AddPeer adds a peer to the known peers list
func (s *Service) AddPeer(address, nodeID string) {
	s.peersMux.Lock()
	defer s.peersMux.Unlock()

	if existing, exists := s.knownPeers[address]; exists {
		existing.LastSeen = time.Now()
		existing.NodeID = nodeID
		return
	}

	s.knownPeers[address] = &PeerRecord{
		Address:    address,
		NodeID:     nodeID,
		LastSeen:   time.Now(),
		Reputation: 0.5, // Default neutral reputation
		Attempts:   0,
		Connected:  false,
	}

	s.logger.Debugw("Added new peer", "address", address, "node_id", nodeID)
}

// RemovePeer removes a peer from the known peers list
func (s *Service) RemovePeer(address string) {
	s.peersMux.Lock()
	defer s.peersMux.Unlock()

	delete(s.knownPeers, address)
	s.logger.Debugw("Removed peer", "address", address)
}

// UpdatePeerStatus updates the connection status of a peer
func (s *Service) UpdatePeerStatus(address string, connected bool) {
	s.peersMux.Lock()
	defer s.peersMux.Unlock()

	if peer, exists := s.knownPeers[address]; exists {
		peer.Connected = connected
		peer.LastSeen = time.Now()
		
		if connected {
			peer.Attempts = 0 // Reset attempts on successful connection
			peer.Reputation = min(peer.Reputation + 0.1, 1.0) // Increase reputation
		}
	}
}

// UpdatePeerReputation updates the reputation of a peer
func (s *Service) UpdatePeerReputation(address string, delta float64) {
	s.peersMux.Lock()
	defer s.peersMux.Unlock()

	if peer, exists := s.knownPeers[address]; exists {
		peer.Reputation = max(0.0, min(1.0, peer.Reputation + delta))
		s.logger.Debugw("Updated peer reputation", 
			"address", address, 
			"reputation", peer.Reputation,
			"delta", delta)
	}
}

// GetKnownPeers returns a list of known peers
func (s *Service) GetKnownPeers() map[string]*PeerRecord {
	s.peersMux.RLock()
	defer s.peersMux.RUnlock()

	peers := make(map[string]*PeerRecord)
	for k, v := range s.knownPeers {
		peers[k] = &PeerRecord{
			Address:    v.Address,
			NodeID:     v.NodeID,
			LastSeen:   v.LastSeen,
			Reputation: v.Reputation,
			Attempts:   v.Attempts,
			Connected:  v.Connected,
		}
	}
	return peers
}

// GetStats returns discovery service statistics
func (s *Service) GetStats() DiscoveryStats {
	s.peersMux.RLock()
	defer s.peersMux.RUnlock()

	connectedCount := 0
	for _, peer := range s.knownPeers {
		if peer.Connected {
			connectedCount++
		}
	}

	return DiscoveryStats{
		KnownPeers:     len(s.knownPeers),
		ConnectedPeers: connectedCount,
		Running:        s.running,
	}
}

// DiscoveryStats represents discovery service statistics
type DiscoveryStats struct {
	KnownPeers     int  `json:"known_peers"`
	ConnectedPeers int  `json:"connected_peers"`
	Running        bool `json:"running"`
}

// Helper functions
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func max(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}
