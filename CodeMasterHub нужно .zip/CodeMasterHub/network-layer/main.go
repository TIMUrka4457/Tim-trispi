package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"github.com/trispi/network-layer/internal/ai_client"
	"github.com/trispi/network-layer/internal/config"
	"github.com/trispi/network-layer/internal/discovery"
	"github.com/trispi/network-layer/internal/p2p"
	"go.uber.org/zap"
)

var (
	cfgFile   string
	logger    *zap.Logger
	sugarLogger *zap.SugaredLogger
)

func init() {
	// Initialize logger
	var err error
	logger, err = zap.NewProduction()
	if err != nil {
		logrus.Fatalf("Failed to initialize logger: %v", err)
	}
	sugarLogger = logger.Sugar()
}

func main() {
	defer logger.Sync()

	rootCmd := &cobra.Command{
		Use:   "trispi-network",
		Short: "TRISPI Blockchain Network Layer",
		Long:  "P2P networking layer for TRISPI blockchain with AI integration",
		Run:   runNetworkNode,
	}

	rootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file (default is config.yaml)")
	rootCmd.Flags().String("listen", "0.0.0.0:9000", "Listen address for P2P connections")
	rootCmd.Flags().String("blockchain-rpc", "http://localhost:8080", "Blockchain RPC endpoint")
	rootCmd.Flags().String("ai-endpoint", "http://localhost:8000/api/ai", "AI service endpoint")
	rootCmd.Flags().StringSlice("bootstrap-peers", []string{}, "Bootstrap peer addresses")
	rootCmd.Flags().Bool("discovery", true, "Enable peer discovery")
	rootCmd.Flags().String("log-level", "info", "Log level (debug, info, warn, error)")

	if err := rootCmd.Execute(); err != nil {
		sugarLogger.Fatalf("Failed to execute command: %v", err)
	}
}

func runNetworkNode(cmd *cobra.Command, args []string) {
	// Load configuration
	cfg, err := config.Load(cfgFile)
	if err != nil {
		sugarLogger.Fatalf("Failed to load config: %v", err)
	}

	// Override config with command line flags
	if cmd.Flags().Changed("listen") {
		cfg.Network.ListenAddress, _ = cmd.Flags().GetString("listen")
	}
	if cmd.Flags().Changed("blockchain-rpc") {
		cfg.Blockchain.RPCEndpoint, _ = cmd.Flags().GetString("blockchain-rpc")
	}
	if cmd.Flags().Changed("ai-endpoint") {
		cfg.AI.Endpoint, _ = cmd.Flags().GetString("ai-endpoint")
	}
	if cmd.Flags().Changed("bootstrap-peers") {
		cfg.Network.BootstrapPeers, _ = cmd.Flags().GetStringSlice("bootstrap-peers")
	}
	if cmd.Flags().Changed("discovery") {
		cfg.Network.EnableDiscovery, _ = cmd.Flags().GetBool("discovery")
	}

	// Set log level
	logLevel, _ := cmd.Flags().GetString("log-level")
	setLogLevel(logLevel)

	sugarLogger.Infow("Starting TRISPI Network Node",
		"listen_address", cfg.Network.ListenAddress,
		"blockchain_rpc", cfg.Blockchain.RPCEndpoint,
		"ai_endpoint", cfg.AI.Endpoint,
		"bootstrap_peers", cfg.Network.BootstrapPeers,
		"discovery_enabled", cfg.Network.EnableDiscovery,
	)

	// Create context with cancellation
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Initialize AI client
	aiClient := ai_client.New(cfg.AI.Endpoint, cfg.AI.Timeout)

	// Initialize P2P node
	p2pNode, err := p2p.NewNode(cfg, sugarLogger, aiClient)
	if err != nil {
		sugarLogger.Fatalf("Failed to create P2P node: %v", err)
	}

	// Initialize peer discovery service
	var discoveryService *discovery.Service
	if cfg.Network.EnableDiscovery {
		discoveryService = discovery.New(p2pNode, cfg.Discovery, sugarLogger)
	}

	// Start services
	errCh := make(chan error, 3)

	// Start P2P node
	go func() {
		sugarLogger.Info("Starting P2P node...")
		if err := p2pNode.Start(ctx); err != nil {
			errCh <- fmt.Errorf("P2P node error: %w", err)
		}
	}()

	// Start discovery service
	if discoveryService != nil {
		go func() {
			sugarLogger.Info("Starting peer discovery...")
			if err := discoveryService.Start(ctx); err != nil {
				errCh <- fmt.Errorf("discovery service error: %w", err)
			}
		}()
	}

	// Start health monitoring
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()

		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				// Log node statistics
				stats := p2pNode.GetStats()
				sugarLogger.Infow("Node statistics",
					"connected_peers", stats.ConnectedPeers,
					"messages_sent", stats.MessagesSent,
					"messages_received", stats.MessagesReceived,
					"bytes_sent", stats.BytesSent,
					"bytes_received", stats.BytesReceived,
				)

				// Health check AI service
				if err := aiClient.HealthCheck(ctx); err != nil {
					sugarLogger.Warnw("AI service health check failed", "error", err)
				}
			}
		}
	}()

	// Wait for shutdown signal
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	select {
	case err := <-errCh:
		sugarLogger.Errorw("Service error", "error", err)
	case sig := <-sigCh:
		sugarLogger.Infow("Received shutdown signal", "signal", sig)
	}

	// Graceful shutdown
	sugarLogger.Info("Shutting down...")
	cancel()

	// Give services time to shut down gracefully
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutdownCancel()

	if err := p2pNode.Stop(shutdownCtx); err != nil {
		sugarLogger.Errorw("Error stopping P2P node", "error", err)
	}

	if discoveryService != nil {
		if err := discoveryService.Stop(shutdownCtx); err != nil {
			sugarLogger.Errorw("Error stopping discovery service", "error", err)
		}
	}

	sugarLogger.Info("Shutdown complete")
}

func setLogLevel(level string) {
	var zapLevel zap.AtomicLevel
	switch level {
	case "debug":
		zapLevel = zap.NewAtomicLevelAt(zap.DebugLevel)
	case "info":
		zapLevel = zap.NewAtomicLevelAt(zap.InfoLevel)
	case "warn":
		zapLevel = zap.NewAtomicLevelAt(zap.WarnLevel)
	case "error":
		zapLevel = zap.NewAtomicLevelAt(zap.ErrorLevel)
	default:
		zapLevel = zap.NewAtomicLevelAt(zap.InfoLevel)
	}

	config := zap.NewProductionConfig()
	config.Level = zapLevel
	newLogger, _ := config.Build()
	logger = newLogger
	sugarLogger = logger.Sugar()
}
